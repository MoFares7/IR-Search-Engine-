import React from 'react';
import { Button, CircularProgress } from '@mui/material';
import colors from '../../../assets/theme/base/colors';

const MainButton = ({ isLoading, title, colorTitle, backgroundColor, hoverBackgroundColor, onClick, height, width }) => {
        return (
                <Button
                        disabled={isLoading} 
                        sx={{
                                m: 1,
                                height: height,
                                width: width,
                                backgroundColor: backgroundColor,
                                hoverBackgroundColor: backgroundColor,
                                color: colorTitle,
                                "&:hover": {
                                        backgroundColor: hoverBackgroundColor,
                                        color: colorTitle
                                },
                        }}
                        onClick={isLoading ? null : onClick} 
                >
                        {isLoading ? (
                                <CircularProgress size={24} sx={{ color: colors.white.main }} />
                        ) : (
                                title
                        )}
                </Button>
        );
};

export default MainButton;
