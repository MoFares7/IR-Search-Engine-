import React, { useState } from 'react';
import Avatar from '@mui/material/Avatar';
import IconButton from '@mui/material/IconButton';
import { AddAPhotoOutlined } from '@mui/icons-material';
import colors from '../../../assets/theme/base/colors';

export default function MainBadgeItem({ avatarImage, handleSelectImage }) {
     
        return (
                <div style={{ position: 'relative', display: 'inline-block' }}>
                        <Avatar
                                alt="Avatar"
                                src={avatarImage}
                                sx={{
                                        width: {
                                                xs: 120,
                                                sm: 120,
                                                md: 150,
                                                xs: 150
                                        },
                                        height: {
                                                xs: 120,
                                                sm: 120,
                                                md: 150,
                                                xs: 150
                                        },
                                        transform: 'revert'
                                }}
                        />
                        <label htmlFor="avatar-input" style={{ position: 'absolute', bottom: 0, right: 0 }}>
                                <IconButton
                                        color="primary"
                                        aria-label="upload picture"
                                        component="span"
                                        sx={{
                                                backgroundColor: colors.white.main,
                                                color: 'white'
                                        }}
                                >
                                        <AddAPhotoOutlined />
                                </IconButton>
                        </label>
                        <input
                                accept="image/*"
                                style={{ display: 'none' }}
                                id="avatar-input"
                                type="file"
                                onChange={handleSelectImage}
                        />
                </div>
        );
}
