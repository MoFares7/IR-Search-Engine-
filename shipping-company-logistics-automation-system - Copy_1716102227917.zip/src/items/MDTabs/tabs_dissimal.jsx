import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { DriveEtaRounded, FireTruckRounded, PendingActionsRounded, Person4Outlined, PersonOffOutlined, ReceiptLongRounded, WarehouseRounded } from '@mui/icons-material';
import Box from '@mui/material/Box';
import colors from '../../assets/theme/base/colors';

export default function TabsOptionDissimal({ value, handleChangeStatus }) {
        return (
                <>
                        <Tabs
                                value={value}
                                onChange={handleChangeStatus}
                                aria-label="icon label tabs example"
                                indicatorColor="primary"
                                sx={{ color: colors.info.main }}
                        >
                                <Tab icon={<Person4Outlined />} label="Employees Manager" />
                                <Tab icon={<PersonOffOutlined />} label="Dissimal Manager" />
                        </Tabs>
                </>
        );
}
