import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { DriveEtaRounded, FireTruckRounded, PendingActionsRounded, ReceiptLongRounded, WarehouseRounded } from '@mui/icons-material';
import Box from '@mui/material/Box';
import colors from '../../assets/theme/base/colors';

export default function TabsOption({ value, handleChangeStatus, isEmployee }) {
        return (
                <>
                        {
                                isEmployee ? (
                                        <Tabs
                                                value={value}
                                                onChange={handleChangeStatus}
                                                aria-label="icon label tabs example"
                                                indicatorColor="primary"
                                                sx={{ color: colors.info.main }}
                                        >
                                                <Tab icon={<ReceiptLongRounded />} label="Reception Employees" />
                                                <Tab icon={<WarehouseRounded />} label="Warehosue Employees" />
                                                <Tab icon={<DriveEtaRounded />} label="Driver Employees" />
                                        </Tabs>

                                ) : (
                                        <Tabs
                                                value={value}
                                                onChange={handleChangeStatus}
                                                aria-label="icon label tabs example"
                                                indicatorColor="primary"
                                                sx={{ color: colors.info.main }}
                                        >
                                                <Tab icon={<FireTruckRounded />} label="Efficient" />
                                                <Tab icon={<PendingActionsRounded />} label="Pending Approval" />
                                        </Tabs>

                                )
                        }
                </>
        );
}
