import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { FireTruckOutlined, Person3Outlined, ReceiptOutlined } from '@mui/icons-material';
import Box from '@mui/material/Box';
import colors from '../../assets/theme/base/colors';

export default function TabsOptionShipment({ value, handleChangeStatus }) {
        return (

                <Tabs
                        value={value}
                        onChange={handleChangeStatus}
                        aria-label="icon label tabs example"
                        indicatorColor="primary"
                        sx={{ color: colors.info.main }}
                >
                        <Tab icon={<FireTruckOutlined />} label="Shipment information" />
                        <Tab icon={<Person3Outlined />} label="Sender Information" />
                        <Tab icon={<ReceiptOutlined />} label="Receiver Information" />
                </Tabs>

        );
}
