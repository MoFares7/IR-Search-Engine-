import React, { useState } from 'react'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar'
import TabsOptionShipment from '../../../../../../items/MDTabs/tabs_option_shipment'
import MDBox from '../../../../../../items/MDBox/MDBox'
import colors from '../../../../../../assets/theme-dark/base/colors'
import { Box, Divider, IconButton } from '@mui/material'
import MDTypography from '../../../../../../items/MDTypography'
import typography from './../../../../../../assets/theme-dark/base/typography';
import MainButton from '../../../../../../components/Items/MainButton/main_button'
import { DownloadOutlined } from '@mui/icons-material'
import ShipmentInfoCard from '../components/shipment_info_card'

const ComingOfShipmentsPage = () => {
        const [caseStatus, setCaseStatus] = useState(0);

        const handleChangeCaseStatus = (event, newstStatus) => {
                setCaseStatus(newstStatus);
        };

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <MDBox sx={{
                                backgroundColor: colors.white.main,
                                borderRadius: 2,
                                m: 1.5
                        }}>
                                <TabsOptionShipment
                                        value={caseStatus}
                                        handleChangeStatus={handleChangeCaseStatus}
                                />
                                <MDBox display="flex">
                                        {caseStatus === 0 ? (
                                                <MDBox display="flex" justifyContent='space-between' sx={{ width: '60%' }}>
                                                        <ShipmentInfoCard
                                                                rowOne={'Shipment Name'}
                                                                rowOneValue={"Test"}
                                                                rowTwo={"Shipment Identifier"}
                                                                rowTwoValue={"1232323"}
                                                                rowThree={"Shipment Capacity"}
                                                                rowThreeValue={"2050"}
                                                                rowFour={"Shipment Cost"}
                                                                rowFourValue={"2000"}
                                                                rowFive={"Who'll Paid"}
                                                                rowFiveValue={"Sender"}
                                                                rowSix={"Shipment Document"}
                                                                rowSixValueClick={() => { }}
                                                        />
                                                </MDBox>
                                        ) : caseStatus === 1 ? (
                                                <MDBox display="flex" justifyContent='space-between' sx={{ width: '60%' }}>
                                                        <ShipmentInfoCard
                                                                rowOne={'Sender Name'}
                                                                rowOneValue={"Fares Dabbas"}
                                                                rowTwo={"Father Name"}
                                                                rowTwoValue={"1232323"}
                                                                rowThree={"Mother Name"}
                                                                rowThreeValue={"2050"}
                                                                rowFour={"Phone Number"}
                                                                rowFourValue={"2000"}
                                                                rowFive={"National Number"}
                                                                rowFiveValue={"2546467867"}

                                                        />
                                                </MDBox>
                                        ) : (
                                                <MDBox display="flex" justifyContent='space-between' sx={{ width: '60%' }}>
                                                        <ShipmentInfoCard
                                                                rowOne={'Receiver Name'}
                                                                rowOneValue={"Fares Dabbas"}
                                                                rowTwo={"Father Name"}
                                                                rowTwoValue={"1232323"}
                                                                rowThree={"Mother Name"}
                                                                rowThreeValue={"2050"}
                                                                rowFour={"Phone Number"}
                                                                rowFourValue={"2000"}
                                                                rowFive={"National Number"}
                                                                rowFiveValue={"2546467867"}
                                                        />
                                                </MDBox>
                                        )}
                                        <Box></Box>
                                </MDBox>

                        </MDBox>


                        <MDBox sx={{
                                backgroundColor: colors.white.main,
                                borderRadius: 2, m: 1.5
                        }}>
                                <TabsOptionShipment
                                        value={caseStatus}
                                        handleChangeStatus={handleChangeCaseStatus}
                                />
                                <MDBox display="flex">
                                        {caseStatus === 0 ? (
                                                <MDBox display="flex" justifyContent='space-between' sx={{ width: '60%' }}>
                                                        <ShipmentInfoCard
                                                                rowOne={'Shipment Name'}
                                                                rowOneValue={"Test"}
                                                                rowTwo={"Shipment Identifier"}
                                                                rowTwoValue={"1232323"}
                                                                rowThree={"Shipment Capacity"}
                                                                rowThreeValue={"2050"}
                                                                rowFour={"Shipment Cost"}
                                                                rowFourValue={"2000"}
                                                                rowFive={"Who'll Paid"}
                                                                rowFiveValue={"Sender"}
                                                                rowSix={"Shipment Document"}
                                                                rowSixValueClick={() => { }}
                                                        />
                                                </MDBox>
                                        ) : caseStatus === 1 ? (
                                                <MDBox display="flex" justifyContent='space-between' sx={{ width: '60%' }}>
                                                        <ShipmentInfoCard
                                                                rowOne={'Sender Name'}
                                                                rowOneValue={"Fares Dabbas"}
                                                                rowTwo={"Father Name"}
                                                                rowTwoValue={"1232323"}
                                                                rowThree={"Mother Name"}
                                                                rowThreeValue={"2050"}
                                                                rowFour={"Phone Number"}
                                                                rowFourValue={"2000"}
                                                                rowFive={"National Number"}
                                                                rowFiveValue={"2546467867"}

                                                        />
                                                </MDBox>
                                        ) : (
                                                <MDBox display="flex" justifyContent='space-between' sx={{ width: '60%' }}>
                                                        <ShipmentInfoCard
                                                                rowOne={'Receiver Name'}
                                                                rowOneValue={"Fares Dabbas"}
                                                                rowTwo={"Father Name"}
                                                                rowTwoValue={"1232323"}
                                                                rowThree={"Mother Name"}
                                                                rowThreeValue={"2050"}
                                                                rowFour={"Phone Number"}
                                                                rowFourValue={"2000"}
                                                                rowFive={"National Number"}
                                                                rowFiveValue={"2546467867"}
                                                        />
                                                </MDBox>
                                        )}
                                        <Box></Box>
                                </MDBox>

                        </MDBox>
                </DashboardLayout>
        )
}

export default ComingOfShipmentsPage
