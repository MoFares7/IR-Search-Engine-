import React, { useState } from 'react'
import MDBox from '../../../../../../items/MDBox/MDBox'
import colors from '../../../../../../assets/theme-dark/base/colors'
import { IconButton } from '@mui/material'
import MDTypography from '../../../../../../items/MDTypography'
import typography from './../../../../../../assets/theme-dark/base/typography';
import { DownloadOutlined } from '@mui/icons-material'

const ShipmentInfoCard = ({ rowOne, rowOneValue, rowTwo, rowTwoValue, rowThree, rowThreeValue,
        rowFour, rowFourValue, rowFive, rowFiveValue, rowSix, rowSixValueClick
}) => {
        return (
                <>
                        <MDBox justifyContent='space-between' p={2}>
                                <MDBox display="flex" justifyContent='space-between' alignItems='center' >
                                        <MDTypography typography={typography.body1} pr={2}>{rowOne}</MDTypography>
                                        <MDTypography typography={typography.body2}>{rowOneValue}</MDTypography>
                                </MDBox>
                                <MDBox display="flex" justifyContent='space-between' alignItems='center' >
                                        <MDTypography typography={typography.body1} pr={2}>{rowTwo}</MDTypography>
                                        <MDTypography typography={typography.body2}>{rowTwoValue}</MDTypography>
                                </MDBox>
                                <MDBox display="flex" justifyContent='space-between' alignItems='center'>
                                        <MDTypography typography={typography.body1} pr={2}>{rowThree}</MDTypography>
                                        <MDTypography typography={typography.body2}>{rowThreeValue}</MDTypography>
                                </MDBox>
                        </MDBox>

                        <MDBox justifyContent='space-between' p={2} ml={3}>
                                <MDBox display="flex" justifyContent='space-between' alignItems='center' >
                                        <MDTypography typography={typography.body1} pr={2}>{rowFour}</MDTypography>
                                        <MDTypography typography={typography.body2}>{rowFourValue} AED</MDTypography>
                                </MDBox>
                                <MDBox display="flex" justifyContent='space-between' alignItems='center' >
                                        <MDTypography typography={typography.body1} pr={2}>{rowFive}</MDTypography>
                                        <MDTypography typography={typography.body2}>{rowFiveValue}</MDTypography>
                                </MDBox>
                                <MDBox display="flex" justifyContent='space-between' alignItems='center'>
                                        <MDTypography typography={typography.body1} pr={2}>{rowSix}</MDTypography>
                                        {rowSixValueClick === '' ?
                                                <MDBox />
                                                :
                                                <IconButton onClick={rowSixValueClick}>
                                                        <DownloadOutlined sx={{ color: colors.gradients.info.main }}
                                                        />
                                                </IconButton>
                                        }

                                </MDBox>
                        </MDBox>
                </>
        )
}

export default ShipmentInfoCard
// <>
//                 <MDBox justifyContent='space-between' p={2}>
//                         <MDBox display="flex" justifyContent='space-between' alignItems='center' >
//                                 <MDTypography typography={typography.body1} pr={2}>Shipment Name</MDTypography>
//                                 <MDTypography typography={typography.body2}>test</MDTypography>
//                         </MDBox>
//                         <MDBox display="flex" justifyContent='space-between' alignItems='center' >
//                                 <MDTypography typography={typography.body1} pr={2}>Shipment Identifier</MDTypography>
//                                 <MDTypography typography={typography.body2}>54687854</MDTypography>
//                         </MDBox>
//                         <MDBox display="flex" justifyContent='space-between' alignItems='center'>
//                                 <MDTypography typography={typography.body1} pr={2}>Shipment Capacity</MDTypography>
//                                 <MDTypography typography={typography.body2}>200</MDTypography>
//                         </MDBox>
//                 </MDBox>

//                 <MDBox justifyContent='space-between' p={2} ml={3}>
//                         <MDBox display="flex" justifyContent='space-between' alignItems='center' >
//                                 <MDTypography typography={typography.body1} pr={2}>Shipment Cost</MDTypography>
//                                 <MDTypography typography={typography.body2}>200 AED</MDTypography>
//                         </MDBox>
//                         <MDBox display="flex" justifyContent='space-between' alignItems='center' >
//                                 <MDTypography typography={typography.body1} pr={2}>Who'll Paid</MDTypography>
//                                 <MDTypography typography={typography.body2}>Sender</MDTypography>
//                         </MDBox>
//                         <MDBox display="flex" justifyContent='space-between' alignItems='center'>
//                                 <MDTypography typography={typography.body1} pr={2}>Shipment Document</MDTypography>
//                                 <IconButton>
//                                         <DownloadOutlined sx={{ color: colors.gradients.info.main }} />
//                                 </IconButton>
//                         </MDBox>
//                 </MDBox>
//         </>