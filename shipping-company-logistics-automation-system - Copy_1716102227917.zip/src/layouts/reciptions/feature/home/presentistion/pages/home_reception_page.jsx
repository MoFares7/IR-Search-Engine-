import React, { useEffect } from 'react'
import MDBox from '../../../../../../items/MDBox/MDBox'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import { Box, Divider, Grid } from '@mui/material'
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar'
import ComplexStatisticsCard from '../../../../../../components/Cards/StatisticsCards'
import ReportsBarChart from '../../../../../../components/Charts/BarCharts/ReportsBarChart'
import ReportsLineChart from '../../../../../../components/Charts/LineCharts/ReportsLineChart'
import reportsLineChartData from '../../../../../others/dashboard/data/reportsLineChartData'
import { BuildRounded, BuildTwoTone, LocationCityRounded, ShoppingBagRounded, SupervisedUserCircleRounded, VerifiedUser } from '@mui/icons-material'
import MDTypography from '../../../../../../items/MDTypography'
import typography from '../../../../../../assets/theme-dark/base/typography';
import LoaderCard from '../../../../../../components/handleState/loader_card'
import ErrorCard from '../../../../../../components/handleState/error_card'
import EmptyCard from '../../../../../../components/handleState/empty_card'
import WarehouseCard from '../../../../../branch/feature/warehouse_managment/presentition/components/warehouse_card'
import { useDispatch, useSelector } from 'react-redux'
import { getWarehousesBranch } from '../../../../../branch/feature/warehouse_managment/services/get_warehouses_service'
import colors from '../../../../../../assets/theme-dark/base/colors'
import DataTable from '../../../../../../components/Tables'
import warehouseTableData from '../components/warehouses_table'

const HomePageReception = () => {
        const dispatch = useDispatch();
        const { data, loading, error } = useSelector(state => state.getWarehousesBranch);

        useEffect(() => {
                dispatch(getWarehousesBranch());
        }, [dispatch]);

        const { columns, rows } = warehouseTableData(data);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <MDBox py={3}>
                                <MDTypography typography={typography.h4} sx={{ pb: 4 }}>
                                        Last Statistic
                                </MDTypography>
                                <Grid container spacing={3}>
                                        <Grid item xs={12} md={6} lg={3}>
                                                <MDBox mb={1.5}>
                                                        <ComplexStatisticsCard
                                                                color="dark"
                                                                icon=<SupervisedUserCircleRounded />
                                                                title="Number of Employees"
                                                                count={281}
                                                                percentage={{
                                                                        color: "success",
                                                                        amount: "+1%",
                                                                        label: "than lask week",
                                                                }}
                                                        />
                                                </MDBox>
                                        </Grid>
                                        <Grid item xs={12} md={6} lg={3}>
                                                <MDBox mb={1.5}>
                                                        <ComplexStatisticsCard
                                                                icon=<LocationCityRounded />
                                                                title="Number of Branches"
                                                                count="5"
                                                                percentage={{
                                                                        color: "dark",
                                                                        amount: "0%",
                                                                        label: "than last month",
                                                                }}
                                                        />
                                                </MDBox>
                                        </Grid>
                                        <Grid item xs={12} md={6} lg={3}>
                                                <MDBox mb={1.5}>
                                                        <ComplexStatisticsCard
                                                                color="success"
                                                                icon=<ShoppingBagRounded />
                                                                title="Number of shipments"
                                                                count="4k"
                                                                percentage={{
                                                                        color: "success",
                                                                        amount: "+32%",
                                                                        label: "than yesterday",
                                                                }}
                                                        />
                                                </MDBox>
                                        </Grid>
                                        <Grid item xs={12} md={6} lg={3}>
                                                <MDBox mb={1.5}>
                                                        <ComplexStatisticsCard
                                                                color="primary"
                                                                icon="person_add"
                                                                title="Followers"
                                                                count="+91"
                                                                percentage={{
                                                                        color: "success",
                                                                        amount: "",
                                                                        label: "Just updated",
                                                                }}
                                                        />
                                                </MDBox>
                                        </Grid>
                                </Grid>

                                <MDTypography typography={typography.h4} sx={{ py: 4 }}>Branch warehouses</MDTypography>

                                <MDBox sx={{ backgroundColor: colors.white.main, borderRadius: 2, alignItems: 'center' }}>
                                        {loading ?
                                                <LoaderCard />
                                                :
                                                error ? <ErrorCard /> :
                                                        data.length === 0 ? <EmptyCard /> : (
                                                                <DataTable
                                                                        table={{ columns, rows }}
                                                                        isSorted={false}
                                                                        entriesPerPage={false}
                                                                        showTotalEntries={false}
                                                                        noEndBorder
                                                                />
                                                        )}
                                </MDBox>

                        </MDBox>
                </DashboardLayout>
        );
}

export default HomePageReception
