import React, { useState } from 'react';
import MDAvatar from "../../../../../../items/MDAvatar";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import { useDispatch } from 'react-redux';
import colors from '../../../../../../assets/theme-dark/base/colors';

export default function warehouseTableData(data) {
   
        data = Array.isArray(data) ? data : [];

        const Warehouse = ({ image, name, Property }) => (
                <MDBox display="flex" alignItems="center" lineHeight={1}>
                        <MDAvatar src={image} name={name} size="sm" />
                        <MDBox ml={2} lineHeight={1}>
                                <MDTypography display="block" variant="button" fontWeight="medium">
                                        {name}
                                </MDTypography>
                                <MDTypography variant="caption">{Property}</MDTypography>
                        </MDBox>
                </MDBox>
        );

        const rows = data.map(warehouse => ({
                WarehouseName: (
                        <Warehouse
                                image={`https://prime-shippa-api.point-dev.net/storage/${warehouse.image.replace('public/', '')}`}
                                name={warehouse.name}
                                Property={warehouse.Property}
                        />
                ),
                phone_number: <MDTypography variant="caption" >{warehouse.phone_number}</MDTypography>,
                Email: <MDTypography variant="caption">{warehouse.email}</MDTypography>,
                Address: <MDTypography variant="caption">{warehouse.address}</MDTypography>,
                Capacity: <MDTypography variant="caption">{warehouse.capacity}</MDTypography>,
                empty: <MDTypography variant="caption">{warehouse.empty}</MDTypography>,
                Status: <MDTypography variant="caption" sx={{
                        color: warehouse.status === 'active' ? colors.success.main : colors.error.main
                }} > {warehouse.status}</MDTypography >,
                managerName: <MDTypography variant="caption">{warehouse.warehouse_manager != null ?
                        warehouse.warehouse_manager.user.username  : 'Not Found'
                }</MDTypography>,
        }));

        return {
                columns: [
                        { Header: 'Warehouse', accessor: 'WarehouseName', align: 'left', backgroundColor: colors.info.main },
                        { Header: 'phone_number', accessor: 'phone_number', align: 'center' },
                        { Header: 'Email', accessor: 'Email', align: 'center' },
                        { Header: 'Address', accessor: 'Address', align: 'center' },
                        { Header: 'Capacity', accessor: 'Capacity', align: 'center' },
                        { Header: 'Empty Space', accessor: 'empty', align: 'center' },
                        { Header: 'Status', accessor: 'Status', align: 'center' },
                        { Header: 'Manager Name', accessor: 'managerName', align: 'center' },

                ],
                rows: rows,
        };
}
