import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const getShipmentWillEnterService = createAsyncThunk(
        'shipment/getAll',
        async () => {
                const response = await api.get(`shipment/getAll`);
                console.log("shipment will enter : " + JSON.stringify(response.data));
                return response.data;
        }
);
const getShipmentWillEnterServiceSlice = createSlice({
        name: 'getShipmentWillEnterService',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getShipmentWillEnterService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getShipmentWillEnterService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(getShipmentWillEnterService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});
export default getShipmentWillEnterServiceSlice.reducer;
