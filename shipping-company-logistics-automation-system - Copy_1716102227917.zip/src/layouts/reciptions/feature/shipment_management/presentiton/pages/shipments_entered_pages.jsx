import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import MainShipmentCard from '../components/main_shipment_card';
import { getShipmentWillEnterService } from '../../services/get_shipment_will_enter_service';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import ErrorCard from '../../../../../../components/handleState/error_card';
import EmptyCard from '../../../../../../components/handleState/empty_card';

const ShipmentsEnteredPage = () => {
        const dispatch = useDispatch();
        const { data, loading, error } = useSelector((state) => state.getShipmentWillEnterService);

        useEffect(() => {
                dispatch(getShipmentWillEnterService());
        }, [dispatch]);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        {loading ? (
                                <LoaderCard />
                        ) : error ? (
                                <ErrorCard />
                        ) : data.length === 0 ? (
                                <EmptyCard message={"Not Found Any Shipment"} />
                        ) : (
                                data &&
                                Array.isArray(data) &&
                                data.length > 0 && (
                                        data.map((shipment, index) => (
                                                <MainShipmentCard key={index} shipmentData={shipment} shipmentId={shipment.shipment.id} />
                                        ))
                                )
                        )}
                </DashboardLayout>
        );
};

export default ShipmentsEnteredPage;
