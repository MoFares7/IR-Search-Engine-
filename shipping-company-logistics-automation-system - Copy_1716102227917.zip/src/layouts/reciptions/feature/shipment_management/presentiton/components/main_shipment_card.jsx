import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ShipmentInfoCard from './shimpent_info_card';
import colors from '../../../../../../assets/theme/base/colors';
import { Menu } from '@mui/material';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import { DeleteOutline, MoreVertRounded, UpdateOutlined } from '@mui/icons-material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import { useDispatch, useSelector } from 'react-redux';
import { deleteShipmentWillEnterService } from '../../services/delete_shipment_will_enter_service';
import { getShipmentWillEnterService } from '../../services/get_shipment_will_enter_service';

const ExpandMore = styled((props) => {
        const { expand, ...other } = props;
        return <IconButton {...other} />;
})(({ theme, expand }) => ({
        transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
        marginLeft: 'auto',
        transition: theme.transitions.create('transform', {
                duration: theme.transitions.duration.shortest,
        }),
}));

const MainShipmentCard = ({ shipmentData, shipmentId }) => {
        const disptach = useDispatch();
        const [expanded, setExpanded] = React.useState(false);
        const [openMenu, setOpenMenu] = useState(null);

        const loadingDelete = useSelector(state => state.deleteShipmentWillEnterService.loading);

        const handleExpandClick = () => {
                setExpanded(!expanded);
        };

        const receiverBranchId = shipmentData.shipment["receiver_branch_id "];
        const senderCustomerId = shipmentData.shipment["sender_customer_id "];
        const receiverCustomerId = shipmentData.shipment["receiver_customer_id "];
        const categoryId = shipmentData.shipment["category_id "];

        const handleUpdateShipment = () => {
                console.log(shipmentId);
                // const res = disptach(deleteShipmentWillEnterService({ Id: shipmentId }));
                // if (res.payload.success) {
                //         disptach(getShipmentWillEnterService());
                // }
        }

        const handleDeleteShipment = () => {
                console.log(shipmentId);
                disptach(deleteShipmentWillEnterService({ Id: shipmentId }));
                disptach(getShipmentWillEnterService());

        }

        const renderMenu = (
                <Menu
                        anchorEl={openMenu}
                        anchorReference="anchorEl"
                        anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'left',
                        }}
                        open={Boolean(openMenu)}
                        onClose={() => {
                                setOpenMenu(null);
                        }}
                        sx={{ mt: 1 }}
                >
                        <MenuOptionItem icon={<UpdateOutlined />} title={"Update Shipment"} onClick={handleUpdateShipment} />
                        <MenuOptionItem icon={<DeleteOutline />} title={!loadingDelete ? "Delete Shipment" : "Deleteting..."} onClick={handleDeleteShipment} />
                </Menu>
        );

        return (
                <Card sx={{
                        backgroundColor: colors.white.main,
                        p: 1,
                        mx: 1,
                        my: 3,
                        borderRadius: 2
                }}>
                        <MDBox textAlign="End">
                                <IconButton
                                        size="small"
                                        disableRipple
                                        color="inherit"
                                        aria-controls="notification-menu"
                                        aria-haspopup="true"
                                        variant="contained"
                                        onClick={(event) => {
                                                setOpenMenu(event.currentTarget);
                                        }}
                                >
                                        <MoreVertRounded />
                                </IconButton>
                        </MDBox>
                        {renderMenu}
                        <CardContent>
                                {shipmentData && shipmentData.shipment ? (
                                        <>
                                                <ShipmentInfoCard
                                                        shipmentSectionTitle={"Shipment Information"}
                                                        rowOne={"Shipment Name"}
                                                        rowOneValue={shipmentData.shipment.name}
                                                        rowTwo={"Shipment Status"}
                                                        rowTwoValue={shipmentData.shipment.status}
                                                        rowThree={"Shipment Cost"}
                                                        rowThreeValue={shipmentData.shipment.shipment_cost}
                                                        rowFour={"Shipment Capacity"}
                                                        rowFourValue={shipmentData.shipment.capacity}
                                                        rowFive={"Paid By"}
                                                        rowFiveValue={shipmentData.shipment.paid_by}
                                                        rowSix={"Shipment Identifier"}
                                                        rowSixValue={shipmentData.shipment.identifier}
                                                        rowSeven={"When Will Store"}
                                                        rowSevenValue={shipmentData.warehouse_name}
                                                        rowAit={"Category Name"}
                                                // rowAitValue={shipmentData.shipment.categoryId.name}
                                                />
                                                <CardActions disableSpacing>
                                                        <ExpandMore
                                                                expand={expanded}
                                                                onClick={handleExpandClick}
                                                                aria-expanded={expanded}
                                                                aria-label="show more"
                                                        >
                                                                <ExpandMoreIcon />
                                                        </ExpandMore>
                                                </CardActions>
                                                <Collapse in={expanded} timeout="auto" unmountOnExit>
                                                        <CardContent>
                                                                <>
                                                                        {receiverBranchId && (
                                                                                <ShipmentInfoCard
                                                                                        shipmentSectionTitle={"Receiver Branch Information"}
                                                                                        rowOne={"Branch Name"}
                                                                                        rowOneValue={receiverBranchId.name}
                                                                                        rowTwo={"Branch Status"}
                                                                                        rowTwoValue={receiverBranchId.status}
                                                                                        rowThree={"Branch Phone Number"}
                                                                                        rowThreeValue={receiverBranchId.phone_number}
                                                                                        rowFour={"Branch Address"}
                                                                                        rowFourValue={receiverBranchId.address}
                                                                                        rowFive={"Branch Email"}
                                                                                        rowFiveValue={receiverBranchId.email}
                                                                                        rowSix={"Branch City"}
                                                                                        rowSixValue={receiverBranchId.districts}
                                                                                />
                                                                        )}

                                                                        {senderCustomerId && (
                                                                                <ShipmentInfoCard
                                                                                        shipmentSectionTitle={"Sender Information"}
                                                                                        rowOne={"Sender Name"}
                                                                                        rowOneValue={senderCustomerId.full_name}
                                                                                        rowTwo={"Sender Father Name"}
                                                                                        rowTwoValue={senderCustomerId.father}
                                                                                        rowThree={"Sender Mother Name"}
                                                                                        rowThreeValue={senderCustomerId.mother}
                                                                                        rowFour={"Sender Mobile Number"}
                                                                                        rowFourValue={senderCustomerId.mobile}
                                                                                        rowFive={"Sender National Number"}
                                                                                        rowFiveValue={senderCustomerId.id_number}
                                                                                />
                                                                        )}

                                                                        {receiverCustomerId && (
                                                                                <ShipmentInfoCard
                                                                                        shipmentSectionTitle={"Receiver Information"}
                                                                                        rowOne={"Receiver Name"}
                                                                                        rowOneValue={receiverCustomerId.full_name}
                                                                                        rowTwo={"Receiver Father Name"}
                                                                                        rowTwoValue={receiverCustomerId.father}
                                                                                        rowThree={"Receiver Mother Name"}
                                                                                        rowThreeValue={receiverCustomerId.mother}
                                                                                        rowFour={"Receiver Mobile Number"}
                                                                                        rowFourValue={receiverCustomerId.mobile}
                                                                                        rowFive={"Receiver National Number"}
                                                                                        rowFiveValue={receiverCustomerId.id_number}
                                                                                />
                                                                        )}
                                                                </>

                                                        </CardContent>
                                                </Collapse>
                                        </>
                                ) : (
                                        <p>Shipment data is missing or incomplete</p>
                                )}
                        </CardContent>
                </Card>
        );
}

export default MainShipmentCard;
