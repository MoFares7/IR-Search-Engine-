import React, { useEffect } from 'react';
import { Box } from '@mui/material';
import colors from '../../../../../../assets/theme/base/colors';
import MDTypography from '../../../../../../items/MDTypography';
import typography from '../../../../../../assets/theme/base/typography';

const ShipmentInfoCard = ({
        shipmentSectionTitle,
        rowOne, rowOneValue, rowTwo, rowTwoValue, rowThree, rowThreeValue,
        rowFour, rowFourValue, rowFive, rowFiveValue, rowSix, rowSixValue,
        rowSeven, rowSevenValue, rowAit, rowAitValue
}) => {
        return (
                <Box sx={{
                        display: 'block',
                        alignItems: 'center',
                        border: '1px solid #dee2e6',
                        borderRadius: 2,
                        p: 2,
                        mt: 2,
                        textAlign: 'start'

                }}>
                        <MDTypography typography={typography.body1} fontWeight="bold">{shipmentSectionTitle}</MDTypography>

                        <Box sx={{ display: 'flex', p: 1, justifyContent: 'space-around', textAlign: 'start' }}>

                                <Box m={2}>
                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowOne}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowOneValue}</MDTypography>

                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowThree}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowThreeValue}</MDTypography>

                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowFive}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowFiveValue}</MDTypography>

                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowSeven}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowSevenValue}</MDTypography>

                                </Box>

                                <Box m={2}>
                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowTwo}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowTwoValue}</MDTypography>

                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowFour}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowFourValue}</MDTypography>

                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowSix}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowSixValue}</MDTypography>

                                        <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>{rowAit}</MDTypography>
                                        <MDTypography typography={typography.body2} >{rowAitValue}</MDTypography>

                                </Box>
                        </Box>
                </Box >
        )
}

export default ShipmentInfoCard
