import React, { useRef, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import MDBox from '../../../../../../items/MDBox/MDBox';
import OptionsStepper from '../components/stepper_options';
import FormReceptShipment from '../components/form_recept_shipment';
import { Box } from '@mui/material';
import colors from '../../../../../../assets/theme/base/colors';
import borders from '../../../../../../assets/theme/base/borders';
import breakpoints from './../../../../../../assets/theme/base/breakpoints';
import { DoneOutlineRounded, ErrorOutlineOutlined } from '@mui/icons-material';
import MDTypography from '../../../../../../items/MDTypography';
import typography from './../../../../../../assets/theme-dark/base/typography';
import { useDispatch, useSelector } from 'react-redux';
import { calaculateCostTranslator } from '../../services/calaculate_cost_service';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import { fastShipmentService } from '../../services/fast_shipment_service';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import Lottie from 'lottie-react';
import added_shipment from '../../../../assets/lottie/added_shipment.json';
import not_added_shipment from '../../../../assets/lottie/not_added_shipment.json';
import { normalShipmentService } from '../../services/normal_shipment_service';

const ReceiptOfShipmentPage = () => {
        const [activeStep, setActiveStep] = useState(0);
        const [senderFullName, setSenderFullName] = useState('');
        const [senderFatherName, setSenderFatherName] = useState('');
        const [senderMotherName, setSenderMotherName] = useState('');
        const [senderPhoneNumber, setSenderPhoneNumer] = useState('');
        const [senderIdentifier, setSenderIdentifier] = useState('');
        const [reciverFullName, setReciverFullName] = useState('');
        const [reciverFatherName, setReciverFatherName] = useState('');
        const [reciverMotherName, setReciverMotherName] = useState('');
        const [reciverPhoneNumber, setReciverPhoneNumer] = useState('');
        const [reciverIdentifier, setReciverIdentifier] = useState('');
        const [capacity, setCapacity] = useState('');
        const [receiverBranchID, setReceiverBranchID] = useState('');
        const [receiverBranchName, setReceiverBranchName] = useState('');
        const [categoryID, setCategoryID] = useState('');
        const [categoryName, setCategoryName] = useState('');
        const [shipmentNumber, setShipmentNumber] = useState('');
        const [typeShipment, setTypeShipment] = useState(false);
        const [documentShipment, setDocumentShipment] = useState('');
        const [documentName, setDocumentName] = useState('');
        const [paidBy, setPaidBy] = useState('');
        const [shipmentName, setShipmentName] = useState('');
        const [shipmentCost, setShipmentCost] = useState('');
        const [isSuccessAddShipment, setIsSuccessAddShipment] = useState(false);
        const fileInputRef = useRef(null);
        const [validationErrors, setValidationErrors] = useState({
                capacity: '',
                receiverBranchID: '',
                categoryID: '',
        });
        const dispatch = useDispatch();
        const dataCalaculate = useSelector(state => state.calaculateCostTranslator.data);
        const isLoadingCalaculate = useSelector(state => state.calaculateCostTranslator.loading);
        const isLoadingFastOrder = useSelector(state => state.fastShipmentService.loading);
        const isLoadingNormal = useSelector(state => state.normalShipmentService.loading);

        const handleNext = () => {
                let isValid = true;

                if (activeStep === 0) {
                        if (receiverBranchID === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        receiverBranchID: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (categoryID === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        categoryID: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (capacity === '' || capacity > 1000000) {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        capacity: 'This field is required and The capacity must not be greater than 1000000',
                                }));
                                isValid = false;
                        }

                }
                if (activeStep === 2) {
                        if (senderFullName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        senderFullName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (senderFatherName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        senderFatherName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (senderMotherName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        senderMotherName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (senderIdentifier === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        senderIdentifier: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (senderPhoneNumber === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        senderPhoneNumber: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (reciverFullName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        reciverFullName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (reciverFatherName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        reciverFatherName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (reciverMotherName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        reciverMotherName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (reciverIdentifier === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        reciverIdentifier: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (reciverPhoneNumber === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        reciverPhoneNumber: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (shipmentName === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        shipmentName: 'This field is required',
                                }));
                                isValid = false;
                        }
                        if (documentShipment === '') {
                                setValidationErrors((prevErrors) => ({
                                        ...prevErrors,
                                        documentShipment: 'This field is required',
                                }));
                                isValid = false;
                        }
                }

                if (isValid) {
                        if (activeStep === 0) {
                                handleCheckAndCalculateCost();
                        }
                        if (activeStep === 2 && typeShipment) {
                                handleFastShipmentOrder();
                        }
                        if (activeStep === 2 && !typeShipment) {
                                handleNormalShipmentOrder();
                        }
                        setActiveStep((prevActiveStep) => prevActiveStep + 1);
                }
        };

        const handleBack = () => {
                setActiveStep((prevActiveStep) => prevActiveStep - 1);
                if (activeStep === 1) {
                        setReceiverBranchID('')
                        setCategoryName('')
                        setCapacity('')
                        setCategoryID('')
                        setCategoryName('')
                }
        };

        const handleReset = () => {
                setActiveStep(0);
        };

        const handleFileChange = (e) => {
                const file = e.target.files[0];
                console.log("Selected file:", file);
                if (file) {
                        setDocumentShipment(file);
                        setDocumentName(file.name);
                        setValidationErrors({ ...validationErrors, documentShipment: '' });
                }
        };

        const handleShipmentDocumentSelected = () => {
                if (fileInputRef.current) {
                        fileInputRef.current.click();
                }
        };

        const handleCheckAndCalculateCost = async () => {
                try {
                        const res = await dispatch(calaculateCostTranslator({
                                payload: {
                                        capacity: capacity,
                                        receiver_branch_id: receiverBranchID,
                                        category_id: categoryID,
                                        isFastOrder: typeShipment
                                }
                        }));
                        console.log('API response:', res);
                        const shipmentCost = res.payload.data;
                        setShipmentCost(shipmentCost);
                        console.log("sh cost:", shipmentCost);
                } catch (error) {
                        console.error('Error occurred while calculating cost:', error);
                }
        };

        const handleNormalShipmentOrder = async () => {
                try {
                        const res = await dispatch(
                                normalShipmentService({
                                        payload: {
                                                name: shipmentName,
                                                receiver_branch_id: receiverBranchID,
                                                capacity,
                                                category_id: categoryID,
                                                'customers[0][full_name]': senderFullName,
                                                'customers[0][father]': senderFatherName,
                                                'customers[0][mother]': senderMotherName,
                                                'customers[0][mobile]': senderPhoneNumber,
                                                'customers[0][id_number]': senderIdentifier,
                                                'customers[1][full_name]': reciverFullName,
                                                'customers[1][father]': reciverFatherName,
                                                'customers[1][mother]': reciverMotherName,
                                                'customers[1][mobile]': reciverPhoneNumber,
                                                'customers[1][id_number]': reciverIdentifier,
                                                shipment_cost: shipmentCost,
                                                paid_by: paidBy,
                                                identifier: shipmentNumber,
                                                document: documentShipment,
                                                // isFastOrder: typeShipment
                                        },
                                })
                        );
                        if (res.payload.status === 'success') {
                                setIsSuccessAddShipment(true);
                        } else {
                                setIsSuccessAddShipment(false);
                        }

                        console.log("res.payload.status: " + res.payload.status);
                } catch (error) {
                        console.error('Error handling fast shipment:', error);
                }
        };

        const handleFastShipmentOrder = async () => {
                try {
                        const res = await dispatch(
                                fastShipmentService({
                                        payload: {
                                                name: shipmentName,
                                                receiver_branch_id: receiverBranchID,
                                                capacity,
                                                category_id: categoryID,
                                                'customers[0][full_name]': senderFullName,
                                                'customers[0][father]': senderFatherName,
                                                'customers[0][mother]': senderMotherName,
                                                'customers[0][mobile]': senderPhoneNumber,
                                                'customers[0][id_number]': senderIdentifier,
                                                'customers[1][full_name]': reciverFullName,
                                                'customers[1][father]': reciverFatherName,
                                                'customers[1][mother]': reciverMotherName,
                                                'customers[1][mobile]': reciverPhoneNumber,
                                                'customers[1][id_number]': reciverIdentifier,
                                                shipment_cost: shipmentCost,
                                                paid_by: paidBy,
                                                identifier: shipmentNumber,
                                                document: documentShipment,
                                                // isFastOrder: typeShipment
                                        },
                                })
                        );
                        if (res.payload.status === 'success') {
                                setIsSuccessAddShipment(true);
                        } else {
                                setIsSuccessAddShipment(false);
                        }

                        console.log("res.payload.status: " + res.payload.status);
                } catch (error) {
                        console.error('Error handling fast shipment:', error);
                }
        };

        const renderFormComponent = () => {
                if (isLoadingCalaculate) {
                        return <LoaderCard />;
                } else
                        if (activeStep === 0) {
                                return (
                                        <FormReceptShipment
                                                capacity={capacity}
                                                setCapacity={setCapacity}
                                                receiverBranchID={receiverBranchID}
                                                setReceiverBranchID={setReceiverBranchID}
                                                categoryID={categoryID}
                                                setCategoryID={setCategoryID}
                                                typeShipment={typeShipment}
                                                setTypeShipment={setTypeShipment}
                                                validationErrors={validationErrors}
                                                setValidationErrors={setValidationErrors}
                                        />
                                );
                        } else if (activeStep === 1) {
                                return (
                                        dataCalaculate && dataCalaculate.status === 'success' ? (
                                                <Box sx={{
                                                        backgroundColor: colors.gradients.success.main,
                                                        width: { breakpoints },
                                                        p: 1,
                                                        borderRadius: borders.borderRadius.md
                                                }}>
                                                        <Box sx={{ display: 'flex' }}>
                                                                <Box sx={{
                                                                        backgroundColor: colors.white.main,
                                                                        borderRadius: borders.borderRadius.md,
                                                                        px: 4,
                                                                        py: 2,
                                                                        alignContent: 'center'
                                                                }}>
                                                                        <DoneOutlineRounded
                                                                                sx={{
                                                                                        color: colors.success.main
                                                                                }} />
                                                                </Box>
                                                                <Box>
                                                                        <MDTypography typography={typography.body2}
                                                                                sx={{
                                                                                        px: 2,
                                                                                        py: 1,
                                                                                        color: colors.white.main
                                                                                }}>
                                                                                {`The total cost of completing this shipment from the current branch to the destination branch at the prices set globally is AED ${dataCalaculate.data}`}
                                                                        </MDTypography>
                                                                </Box>
                                                        </Box>
                                                </Box>
                                        ) : (
                                                <Box sx={{
                                                        backgroundColor: colors.gradients.error.main,
                                                        width: { breakpoints },
                                                        p: 1,
                                                        borderRadius: borders.borderRadius.md
                                                }}>
                                                        <Box sx={{ display: 'flex' }}>
                                                                <Box sx={{
                                                                        backgroundColor: colors.white.main,
                                                                        borderRadius: borders.borderRadius.md,
                                                                        px: 4,
                                                                        py: 2,
                                                                        alignContent: 'center'
                                                                }}>
                                                                        <ErrorOutlineOutlined
                                                                                sx={{
                                                                                        color: colors.error.main
                                                                                }} />
                                                                </Box>
                                                                <Box>
                                                                        <MDTypography typography={typography.body2}
                                                                                sx={{
                                                                                        px: 2,
                                                                                        py: 1,
                                                                                        color: colors.white.main
                                                                                }}>
                                                                                There is not enough space in the warehouse
                                                                        </MDTypography>
                                                                </Box>
                                                        </Box>
                                                </Box>
                                        )
                                );
                        }
                        else if (dataCalaculate && dataCalaculate.status === 'success' && activeStep === 2) {
                                return (
                                        <FormReceptShipment
                                                isFirstStep={true}
                                                senderFullName={senderFullName}
                                                setSenderFullName={setSenderFullName}
                                                senderFatherName={senderFatherName}
                                                setSenderFatherName={setSenderFatherName}
                                                senderMotherName={senderMotherName}
                                                setSenderMotherName={setSenderMotherName}
                                                senderPhoneNumber={senderPhoneNumber}
                                                setSenderPhoneNumer={setSenderPhoneNumer}
                                                senderIdentifier={senderIdentifier}
                                                setSenderIdentifier={setSenderIdentifier}
                                                reciverFullName={reciverFullName}
                                                setReciverFullName={setReciverFullName}
                                                reciverFatherName={reciverFatherName}
                                                setReciverFatherName={setReciverFatherName}
                                                reciverMotherName={reciverMotherName}
                                                setReciverMotherName={setReciverMotherName}
                                                reciverIdentifier={reciverIdentifier}
                                                setReciverIdentifier={setReciverIdentifier}
                                                reciverPhoneNumber={reciverPhoneNumber}
                                                setReciverPhoneNumer={setReciverPhoneNumer}
                                                capacity={capacity}
                                                setCapacity={setCapacity}
                                                receiverBranchID={receiverBranchID}
                                                setReceiverBranchID={setReceiverBranchID}
                                                receiverBranchName={receiverBranchName}
                                                setReceiverBranchName={setReceiverBranchName}
                                                categoryID={categoryID}
                                                categoryName={categoryName}
                                                setCategoryName={setCategoryName}
                                                setCategoryID={setCategoryID}
                                                shipmentName={shipmentName}
                                                setShipmentName={setShipmentName}
                                                shipmentNumber={shipmentNumber}
                                                setShipmentNumber={setShipmentNumber}
                                                documentShipment={documentShipment}
                                                setDocumentShipment={setDocumentShipment}
                                                documentName={documentName}
                                                setDocumentName={setDocumentName}
                                                paidBy={paidBy}
                                                setPaidBy={setPaidBy}
                                                fileInputRef={fileInputRef}
                                                handleFileChange={handleFileChange}
                                                handleShipmentDocumentSelected={handleShipmentDocumentSelected}
                                                validationErrors={validationErrors}
                                                setValidationErrors={setValidationErrors}
                                        />
                                );
                        } else {
                                <EmptyCard
                                        message={"Sorry you can't complete these stages. "}
                                />
                        }

                if (activeStep === 3 && isLoadingFastOrder || activeStep === 3 && isLoadingNormal) {
                        return (
                                <LoaderCard />
                        );
                } else {
                        if (activeStep === 3 && isSuccessAddShipment) {
                                return (
                                        <MDBox textAlign='center' >
                                                <Box sx={{ display: 'flex', textAlign: 'center', justifyContent: 'center' }}>
                                                        <Lottie animationData={added_shipment} autoplay loop style={{ alignItems: 'center', width: 270, height: 270 }} />
                                                </Box>
                                                <MDTypography typography={typography.body2}>The shipment has been successfully entered</MDTypography>
                                        </MDBox>
                                );
                        } else {
                                return (
                                        <MDBox textAlign='center' >
                                                <Box sx={{ display: 'flex', textAlign: 'center', justifyContent: 'center' }}>
                                                        <Lottie animationData={not_added_shipment} autoplay loop style={{ alignItems: 'center', width: 270, height: 270 }} />
                                                </Box>
                                                <MDTypography typography={typography.body2}>Sorry there was a mistake when creating the shipment please make sure the information entered is correct</MDTypography>
                                        </MDBox>
                                );
                        }
                }
        };

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <MDBox>
                                <OptionsStepper activeStep={activeStep} handleNext={handleNext} handleBack={handleBack} handleReset={handleReset} />
                                {renderFormComponent()}
                        </MDBox>
                </DashboardLayout>
        );
};

export default ReceiptOfShipmentPage;
