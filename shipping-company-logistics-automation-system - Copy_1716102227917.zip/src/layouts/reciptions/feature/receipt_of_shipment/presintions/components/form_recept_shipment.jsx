import React, { useEffect, useRef, useState } from 'react'
import MDBox from '../../../../../../items/MDBox/MDBox';
import TextFeildForm from '../../../../../../components/Items/Form_TextFeild/text_feild_form';
import DropdownTextField from '../../../../../manager/feature/branchs/presentitons/components/drop_down_textFiled';
import colors from '../../../../../../assets/theme/base/colors';
import MDTypography from '../../../../../../items/MDTypography';
import typography from './../../../../../../assets/theme-dark/base/typography';
import { useDispatch, useSelector } from 'react-redux';
import { fetchBranches } from '../../../../../manager/feature/branchs/services/apis/get_branches_api';
import { getPricingManagement } from '../../../../../manager/feature/Pricing/service/get_pricing_service';
import MainButton from '../../../../../../components/Items/MainButton/main_button';
import { Box } from '@mui/material';
import Lottie from 'lottie-react';
import qr_code from '../../../../assets/lottie/qr_code.json';
import world from '../../../../assets/lottie/world.json';
import QRCode from 'qrcode.react';

const FormReceptShipment = ({
        isFirstStep,
        senderFullName, setSenderFullName,
        senderFatherName, setSenderFatherName,
        senderMotherName, setSenderMotherName,
        senderPhoneNumber, setSenderPhoneNumer,
        senderIdentifier, setSenderIdentifier,
        reciverFullName, setReciverFullName,
        reciverFatherName, setReciverFatherName,
        reciverMotherName, setReciverMotherName,
        reciverPhoneNumber, setReciverPhoneNumer,
        reciverIdentifier, setReciverIdentifier,
        paidBy, setPaidBy,
        receiverBranchName, setReceiverBranchName,
        receiverBranchID, setReceiverBranchID,
        shipmentName, setShipmentName,
        categoryName, setCategoryName,
        categoryID, setCategoryID,
        capacity, setCapacity,
        typeShipment, setTypeShipment,
        shipmentNumber, setShipmentNumber,
        documentShipment, setDocumentShipment,
        documentName, setDocumentName,
        fileInputRef, handleFileChange,
        handleShipmentDocumentSelected,
        validationErrors, setValidationErrors,

}) => {

        const dispatch = useDispatch();
        const [typeShipmentOperation, setTypeShipmentOperation] = useState(false);

        useEffect(() => {
                dispatch(fetchBranches());
                dispatch(getPricingManagement());
        }, [dispatch]);

        const branches = useSelector(state => state.branches.branches);
        const loadingBranch = useSelector(state => state.branches.loading);
        const errorBranch = useSelector(state => state.branches.error);
        const category = useSelector(state => state.getPricingManagement.data);
        const loadingCategory = useSelector(state => state.getPricingManagement.loading);

        const [showQRCode, setShowQRCode] = useState(false);

        const generateRandomNumber = () => {
                const randomNumber = Math.floor(10000000 + Math.random() * 90000000);
                setShipmentNumber(randomNumber.toString());
                setShowQRCode(true);
        };
        return (
                <>
                        {isFirstStep ?
                                <>
                                        {/* //! sender info */}
                                        <MDTypography typography={typography.body1} sx={{ py: 1 }}>Information Sender</MDTypography>

                                        <MDBox display="flex" justifyContent="space-between" >
                                                <TextFeildForm
                                                        value={senderFullName}
                                                        placeholder={validationErrors.senderFullName ? validationErrors.capacity : "Full Name"}
                                                        label={'Full Name'}
                                                        validationColor={validationErrors.senderFullName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.senderFullName}
                                                        onChange={(e) => {
                                                                setSenderFullName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, senderFullName: '' });
                                                        }}
                                                />
                                                <TextFeildForm
                                                        value={senderFatherName}
                                                        placeholder={validationErrors.senderFatherName ? validationErrors.senderFatherName : "Father Name"}
                                                        label={'Father Name'}
                                                        validationColor={validationErrors.senderFatherName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.senderFatherName}
                                                        onChange={(e) => {
                                                                setSenderFatherName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, senderFatherName: '' });
                                                        }}
                                                />
                                        </MDBox>

                                        <MDBox display="flex" justifyContent="center"  >
                                                <TextFeildForm
                                                        isNumaric={true}
                                                        value={senderIdentifier}
                                                        placeholder={validationErrors.senderIdentifier ? validationErrors.senderIdentifier : "National Number"}
                                                        label={'National Number'}
                                                        validationColor={validationErrors.senderIdentifier ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.senderIdentifier}
                                                        onChange={(e) => {
                                                                setSenderIdentifier(e.target.value);
                                                                setValidationErrors({ ...validationErrors, senderIdentifier: '' });
                                                        }}
                                                />
                                        </MDBox>

                                        <MDBox display="flex" justifyContent="space-between" >
                                                <TextFeildForm
                                                        value={senderMotherName}
                                                        placeholder={validationErrors.senderMotherName ? validationErrors.v : "Mother Name"}
                                                        label={'Mother Name'}
                                                        validationColor={validationErrors.senderMotherName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.senderMotherName}
                                                        onChange={(e) => {
                                                                setSenderMotherName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, senderMotherName: '' });
                                                        }}
                                                />
                                                <TextFeildForm
                                                        isNumaric={true}
                                                        value={senderPhoneNumber}
                                                        placeholder={validationErrors.senderPhoneNumber ? validationErrors.senderPhoneNumber : "Phone Number"}
                                                        label={'Phone Number'}
                                                        validationColor={validationErrors.senderPhoneNumber ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.senderPhoneNumber}
                                                        onChange={(e) => {
                                                                setSenderPhoneNumer(e.target.value);
                                                                setValidationErrors({ ...validationErrors, senderPhoneNumber: '' });
                                                        }}
                                                />
                                        </MDBox>


                                        {/* //! reciver info */}
                                        <MDTypography typography={typography.body1} sx={{ py: 1 }}>Information Received</MDTypography>

                                        <MDBox display="flex" justifyContent="space-between" >
                                                <TextFeildForm
                                                        value={reciverFullName}
                                                        placeholder={validationErrors.reciverFullName ? validationErrors.reciverFullName : "Full Name"}
                                                        label={'Full Name'}
                                                        validationColor={validationErrors.reciverFullName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.reciverFullName}
                                                        onChange={(e) => {
                                                                setReciverFullName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, reciverFullName: '' });
                                                        }}
                                                />
                                                <TextFeildForm
                                                        value={reciverFatherName}
                                                        placeholder={validationErrors.reciverFatherName ? validationErrors.reciverFatherName : "Father Name"}
                                                        label={'Father Name'}
                                                        validationColor={validationErrors.reciverFatherName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.reciverFatherName}
                                                        onChange={(e) => {
                                                                setReciverFatherName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, reciverFatherName: '' });
                                                        }}
                                                />
                                        </MDBox>

                                        <MDBox display="flex" justifyContent="center"  >
                                                <TextFeildForm
                                                        isNumaric={true}
                                                        value={reciverIdentifier}
                                                        placeholder={validationErrors.reciverIdentifier ? validationErrors.reciverIdentifier : "National Number"}
                                                        label={'National Number'}
                                                        validationColor={validationErrors.reciverIdentifier ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.reciverIdentifier}
                                                        onChange={(e) => {
                                                                setReciverIdentifier(e.target.value);
                                                                setValidationErrors({ ...validationErrors, reciverIdentifier: '' });
                                                        }}
                                                />
                                        </MDBox>

                                        <MDBox display="flex" justifyContent="space-between" >
                                                <TextFeildForm
                                                        value={reciverMotherName}
                                                        placeholder={validationErrors.reciverMotherName ? validationErrors.reciverMotherName : "Mother Name"}
                                                        label={'Mother Name'}
                                                        validationColor={validationErrors.reciverMotherName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.reciverMotherName}
                                                        onChange={(e) => {
                                                                setReciverMotherName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, reciverMotherName: '' });
                                                        }}
                                                />
                                                <TextFeildForm
                                                        isNumaric={true}
                                                        value={reciverPhoneNumber}
                                                        placeholder={validationErrors.reciverPhoneNumber ? validationErrors.reciverPhoneNumber : "Phone Number"}
                                                        label={'Phone Number'}
                                                        validationColor={validationErrors.reciverPhoneNumber ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.reciverPhoneNumber}
                                                        onChange={(e) => {
                                                                setReciverPhoneNumer(e.target.value);
                                                                setValidationErrors({ ...validationErrors, reciverPhoneNumber: '' });
                                                        }}
                                                />
                                        </MDBox>

                                        {/* //! detect how buy  */}
                                        <MDTypography typography={typography.body1} sx={{ py: 1 }}>Completion of shipment information</MDTypography>

                                        <MDBox display="flex" justifyContent="space-between" >
                                                <TextFeildForm
                                                        value={shipmentName}
                                                        placeholder={validationErrors.shipmentName ? validationErrors.shipmentName : "Shipment Name"}
                                                        label={'Shipment Name'}
                                                        validationColor={validationErrors.shipmentName ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.shipmentName}
                                                        onChange={(e) => {
                                                                setShipmentName(e.target.value);
                                                                setValidationErrors({ ...validationErrors, shipmentName: '' });
                                                        }}
                                                />

                                                <DropdownTextField
                                                        value={paidBy}
                                                        options={["sender", "recipient"]}
                                                        validationErrors={validationErrors.paidBy}
                                                        validationColor={validationErrors.paidBy ? colors.gradients.error.main : colors.white}
                                                        placholder={"Who'll Pay"}
                                                        label={"Who'll Pay"}
                                                        onChange={(newValue) => setPaidBy(newValue)}
                                                />
                                        </MDBox>

                                        {/* //! shipment info */}

                                        <MDBox sx={{
                                                display: {
                                                        xs: 'block',
                                                        md: 'flex',
                                                        xl: 'flex'
                                                }
                                        }}  >
                                                <MDBox
                                                        sx={{
                                                                fontSize: '1rem',
                                                                width: {
                                                                        xl: '50%',
                                                                },
                                                                borderRadius: '0.5rem',
                                                        }}
                                                        onClick={handleShipmentDocumentSelected}
                                                >
                                                        <label>
                                                                <input
                                                                        type="file"
                                                                        style={{ display: 'none' }}
                                                                        onChange={handleFileChange}
                                                                        accept=".pdf, .doc, .docx"
                                                                        disabled={documentShipment !== ''}
                                                                        ref={fileInputRef}
                                                                />
                                                                <TextFeildForm
                                                                        isFulWidth={true}
                                                                        value={documentName || ''}
                                                                        placeholder={validationErrors.documentShipment ? validationErrors.documentShipment : 'Shipment Document'}
                                                                        label={'Shipment Document'}
                                                                        validationColor={validationErrors.documentShipment ? colors.gradients.error.main : colors.white}
                                                                        validationErrors={validationErrors.documentShipment}
                                                                        readOnly
                                                                />
                                                        </label>
                                                </MDBox>
                                                <Box sx={{
                                                        fontSize: '1rem',
                                                        borderRadius: '0.5rem',
                                                        textAlign: 'center',
                                                        alignItems: 'center',
                                                        justifyItems: 'center',
                                                        justifyContent: 'center',
                                                        width: {
                                                                xl: '50%',
                                                        }
                                                }}>

                                                        <MainButton
                                                                title="Generate unique shipment number"
                                                                colorTitle={colors.white.main}
                                                                backgroundColor={colors.warning.main}
                                                                hoverBackgroundColor={colors.warning.focus}
                                                                onClick={generateRandomNumber}
                                                                height="55px"
                                                        />
                                                </Box>

                                        </MDBox>
                                        {shipmentNumber &&
                                                <MDBox sx={{
                                                        display: {
                                                                xs: 'block',
                                                                md: 'flex',
                                                                xl: 'flex'
                                                        },
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        backgroundColor: colors.white.main,
                                                        borderRadius: 2,
                                                        mx: 2,
                                                        my: 1,
                                                        boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)'
                                                }}>
                                                        <MDBox display="flex">
                                                                <MDTypography typography={typography.body1} sx={{color:colors.black.main}}>The shipment Number is</MDTypography>
                                                                <MDTypography typography={typography.body1} sx={{ color: colors.black.main }} pl={1} fontWeight="bold">{shipmentNumber}</MDTypography>
                                                        </MDBox>
                                                        <MDBox p={2}>
                                                                {showQRCode && shipmentNumber && (
                                                                        <QRCode value={shipmentNumber} />
                                                                )}                                                        </MDBox>
                                                </MDBox>
                                        }
                                </>
                                :
                                <>
                                        {/* //! here is first steps */}

                                        <MDBox sx={{ display: 'flex', justifyContent: 'center' }}>
                                                <Lottie animationData={world} autoplay loop style={{ alignItems: 'center', width: 180, height: 180 }} />
                                        </MDBox>

                                        {/* //? option fast or normal shipments */}
                                        <MDTypography typography={typography.body1} fontWeight="bold">Shipment Type</MDTypography>
                                        <MDBox display={{
                                                xs: 'block',
                                                md: 'flex'
                                        }}
                                                justifyContent={{
                                                        xs: 'center',
                                                        md: 'space-around',
                                                        xl: 'space-around'
                                                }}
                                                textAlign="center"
                                                pt={3} >
                                                <MainButton
                                                        title={'Fast Shipping'}
                                                        colorTitle={colors.white.main}
                                                        backgroundColor={colors.gradients.warning.main}
                                                        hoverBackgroundColor={colors.gradients.warning.state}
                                                        onClick={() => {
                                                                setTypeShipmentOperation(true);
                                                                setTypeShipment(true)
                                                        }}
                                                        width={{
                                                                xs: '200px',
                                                                md: '320px',
                                                                xl: '350px'
                                                        }}
                                                />
                                                <MainButton
                                                        title={'Normal Shipping'}
                                                        colorTitle={colors.white.main}
                                                        backgroundColor={colors.gradients.info.state}
                                                        hoverBackgroundColor={colors.gradients.info.main}
                                                        onClick={() => {
                                                                setTypeShipmentOperation(true);
                                                                setTypeShipment(false)
                                                        }}
                                                        width={{
                                                                xs: '200px',
                                                                md: '320px',
                                                                xl: '350px'
                                                        }}
                                                />
                                        </MDBox>

                                        {typeShipmentOperation ?
                                                <>
                                                        <MDBox display="flex" justifyContent="space-between" >
                                                                <DropdownTextField
                                                                        value={receiverBranchName}
                                                                        options={branches.map(branch => branch.branch.name)}
                                                                        branchManagersLoading={loadingBranch}
                                                                        validationErrors={validationErrors.receiverBranchID}
                                                                        validationColor={validationErrors.receiverBranchID ? colors.gradients.error.main : colors.white}
                                                                        placeholder={"Receiver Branch"}
                                                                        label={'Receiver Branch'}
                                                                        onChange={(newValue) => {
                                                                                const selectedBranch = branches.find(branch => branch.branch.name === newValue);
                                                                                if (selectedBranch) {
                                                                                        console.log("selectedBranch.id: " + selectedBranch.branch.id);
                                                                                        setReceiverBranchID(selectedBranch.branch.id);
                                                                                } else {
                                                                                        setReceiverBranchID('');
                                                                                }
                                                                        }}
                                                                />

                                                                <DropdownTextField
                                                                        value={categoryName}
                                                                        validationErrors={validationErrors.categoryID}
                                                                        validationColor={validationErrors.categoryID ? colors.gradients.error.main : colors.white}
                                                                        placholder={"Category Type"}
                                                                        label={'Category Type'}
                                                                        options={category.map(category => category.name)}
                                                                        branchManagersLoading={loadingCategory}
                                                                        onChange={(newValue) => {
                                                                                const selectedCategory = category.find(category => category.name === newValue);
                                                                                if (selectedCategory) {
                                                                                        console.log("selectedCategory.id: " + selectedCategory.id);
                                                                                        setCategoryID(selectedCategory.id);
                                                                                } else {
                                                                                        setCategoryID('');
                                                                                }
                                                                        }}
                                                                />
                                                        </MDBox>

                                                        <MDBox display="flex" justifyContent="center"  >
                                                                <TextFeildForm
                                                                        isNumaric={true}
                                                                        value={capacity}
                                                                        // isFulWidth={true}
                                                                        placeholder={validationErrors.capacity ? validationErrors.capacity : "Capacity Shipment"}
                                                                        label={'Capacity Shipment'}
                                                                        validationColor={validationErrors.capacity ? colors.gradients.error.main : colors.white}
                                                                        validationErrors={validationErrors.capacity}
                                                                        onChange={(e) => {
                                                                                setCapacity(e.target.value);
                                                                                setValidationErrors({ ...validationErrors, capacity: '' });
                                                                        }}
                                                                />
                                                        </MDBox>
                                                </> :
                                                <MDBox />
                                        }
                                </>
                        }
                </>
        )
}

export default FormReceptShipment
