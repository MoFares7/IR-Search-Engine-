import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const fastShipmentService = createAsyncThunk(
        'shipment/checkSpace',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`shipment/fastOrder`, payload);
                        console.log("fastShipmentService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const fastShipmentServiceSlice = createSlice({
        name: 'fastShipmentService',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(fastShipmentService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(fastShipmentService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(fastShipmentService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default fastShipmentServiceSlice.reducer;
