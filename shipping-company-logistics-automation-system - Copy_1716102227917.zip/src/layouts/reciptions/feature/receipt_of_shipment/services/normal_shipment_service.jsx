import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const normalShipmentService = createAsyncThunk(
        'shipment/store',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`shipment/store`, payload);
                        console.log("normalShipmentService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const normalShipmentServiceSlice = createSlice({
        name: 'normalShipmentService',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(normalShipmentService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(normalShipmentService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(normalShipmentService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default normalShipmentServiceSlice.reducer;
