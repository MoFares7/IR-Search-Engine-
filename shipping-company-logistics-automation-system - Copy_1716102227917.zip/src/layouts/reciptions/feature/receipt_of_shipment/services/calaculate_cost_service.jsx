import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const calaculateCostTranslator = createAsyncThunk(
        'shipment/checkSpace',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`shipment/checkSpace`, payload);
                        console.log("calaculateCostTranslator success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const calaculateCostTranslatorSlice = createSlice({
        name: 'calaculateCostTranslator',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(calaculateCostTranslator.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(calaculateCostTranslator.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload;
                        })
                        .addCase(calaculateCostTranslator.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default calaculateCostTranslatorSlice.reducer;
