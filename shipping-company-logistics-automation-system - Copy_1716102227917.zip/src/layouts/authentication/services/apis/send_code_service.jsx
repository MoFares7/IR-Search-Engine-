import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../core/network/api.jsx';

export const sendCodeVerificationService = createAsyncThunk(
        'auth/sendCode',
        async () => {
                const response = await api.get(`auth/sendCode`);
                console.log("response auth code verfication: " + response.data);
                return response.data;
        }
);

const sendCodeVerificationServiceSlice = createSlice({
        name: 'sendCodeVerificationService',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(sendCodeVerificationService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(sendCodeVerificationService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(sendCodeVerificationService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default sendCodeVerificationServiceSlice.reducer;
