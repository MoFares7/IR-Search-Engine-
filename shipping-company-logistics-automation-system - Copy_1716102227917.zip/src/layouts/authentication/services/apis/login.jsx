// loginSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { setValue } from '../../../../core/storage/storage';
import api from '../../../../core/network/api';

// const BASE_URL = 'https://prime-shippa-api.point-dev.net/api/';

export const login = createAsyncThunk(
        'auth/login',
        async ({ email, password }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`auth/login`, { email, password });

                        console.log("Response data:", response.data);

                        // Store user info
                        setValue('token', response.data.data.token);
                        setValue('email', response.data.data.user.email);
                        setValue('type', response.data.data.user.type);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                const errorMessage = error.response.data.message;
                                return rejectWithValue(errorMessage);
                        } else if (error.request) {
                                return rejectWithValue("Can't connect with the server. Please check your network connection.");
                        } else {
                                return rejectWithValue('Error setting up the request.');
                        }
                }
        }
);

const authSlice = createSlice({
        name: 'auth',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(login.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(login.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(login.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload;
                        });

        },
});

export default authSlice.reducer;
