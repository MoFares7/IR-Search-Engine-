import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../core/network/api';

export const verifyCodeService = createAsyncThunk(
        'auth/verify',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`auth/verify`, payload);
                        console.log("Response:", response);
                        if (response.data.status === 'success') {
                                return { status: 'success', data: response.data };
                        } else {
                                return { status: 'error', error: response.data.error };
                        }
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);


const verifyCodeServiceSlice = createSlice({
        name: 'verifyCodeService',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(verifyCodeService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(verifyCodeService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(verifyCodeService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default verifyCodeServiceSlice.reducer;
