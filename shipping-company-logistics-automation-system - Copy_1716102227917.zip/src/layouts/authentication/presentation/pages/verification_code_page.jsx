import React, { useState } from 'react';
import DashboardLayout from '../../../../components/LayoutContainers/DashboardLayout';
import { Box } from '@mui/material';
import VerificationCard from '../components/verification_card';
import ResetPasswordCard from '../components/reset_password_card';

const VerificationCodePage = () => {
        const [isVerification, setIsVerification] = useState(false);

        return (
                <DashboardLayout>
                        <Box
                                sx={{
                                        display: 'flex',
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        height: '100%',
                                }}
                        >
                                {!isVerification
                                        ?
                                        <VerificationCard
                                                isVerificated={isVerification}
                                                setIsVerificated={setIsVerification}
                                        />

                                        : <ResetPasswordCard />
                                }
                        </Box>
                </DashboardLayout>
        );
}

export default VerificationCodePage;
