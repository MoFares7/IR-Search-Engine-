import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Card from '@mui/material/Card';
import MDButton from '../../../../items/MDButton';
import BasicLayout from '../components/BasicLayout';
import bgImage from '../../../../assets/images/login_shipping.jpg';
import MDBox from '../../../../items/MDBox/MDBox';
import MDTypography from '../../../../items/MDTypography';
import MDInput from '../../../../items/MDInput';
import CircularProgress from '@mui/material/CircularProgress';
import Snackbar from '@mui/material/Snackbar';
import { colors } from '@mui/material';
import { login } from '../../services/apis/login';
import { json } from 'react-router-dom';
import { getValue } from '../../../../core/storage/storage';

function Basic() {
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorSnackbarOpen, setErrorSnackbarOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const isLoading = useSelector(state => state.auth.loading);
  const error = useSelector(state => state.auth.error);

  const handleLogin = async () => {
    try {
      const response = await dispatch(login({ email, password }));
      const newToken = getValue("token");
      if (newToken) {
        window.location.href = '/home';

      } else {
        setErrorMessage('An error occurred during login');
        setErrorSnackbarOpen(true);
      }
    } catch (error) {
      console.error("Error occurred during login:", error);
      setErrorMessage('An error occurred during login');
      setErrorSnackbarOpen(true);
    }
  };

  const handleSnackbarClose = () => {
    setErrorSnackbarOpen(false);
  };

  return (
    <BasicLayout image={bgImage}>
      <Card
        sx={{
          transition: 'transform 0.4s ease',
          '&:hover': {
            transform: 'scale(0.97)',
          },
        }}
      >
        <MDBox
          variant="gradient"
          bgColor="info"
          borderRadius="lg"
          coloredShadow="info"
          mx={2}
          mt={-4}
          p={2}
          mb={1}
          textAlign="center"
        >
          <MDTypography variant="h4" fontWeight="medium" color="white" mt={1}>
            Login
          </MDTypography>
        </MDBox>
        <MDBox pt={4} pb={3} px={3}>
          <MDBox component="form" role="form">
            <MDBox mb={2}>
              <MDInput
                type="email"
                label="Email"
                fullWidth
                variant="outlined"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </MDBox>
            <MDBox mb={2}>
              <MDInput
                type="password"
                label="Password"
                fullWidth
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </MDBox>
            <MDBox mt={4} mb={1}>
              <MDButton
                variant="gradient"
                color="info"
                fullWidth
                onClick={handleLogin}
                disabled={isLoading}
              >
                {isLoading ? (
                  <CircularProgress size={24} sx={{ color: colors.indigo[100] }} />
                ) : (
                  'Login'
                )}
              </MDButton>
            </MDBox>
          </MDBox>
        </MDBox>
      </Card>

      <Snackbar
        open={errorSnackbarOpen}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        message={error || errorMessage}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />

    </BasicLayout>
  );
}

export default Basic;
