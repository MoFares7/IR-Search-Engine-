import React, { useState } from 'react';
import OTPInput from 'react-otp-input';
import verification from '../../../../assets/lottie/verification.json';
import Lottie from 'lottie-react';
import MDBox from '../../../../items/MDBox/MDBox';
import colors from '../../../../assets/theme/base/colors';
import MDTypography from '../../../../items/MDTypography';
import typography from './../../../../assets/theme/base/typography';
import MainButton from '../../../../components/Items/MainButton/main_button';
import { getValue } from '../../../../core/storage/storage';
import { useDispatch, useSelector } from 'react-redux';
import { verifyCodeService } from '../../services/apis/verfiy_code_service';

const VerificationCard = ({ isVerificated, setIsVerificated }) => {
        const dispatch = useDispatch();
        const [otp, setOtp] = useState('');
        const [error, setError] = useState('');

        const loadingVerifyCode = useSelector(state => state.verifyCodeService.loading);

        const handleSubmitVerifcationCode = async () => {
                if (otp.length !== 6) {
                        setError('The Code must be Exactly 6 Digits');
                        return;
                } else {
                        setError('');

                        const res = await dispatch(verifyCodeService({
                                payload: {
                                        verification_code: otp
                                }
                        }));

                        if (res.payload.status === 'success') {
                                setIsVerificated(true);
                        }
                }
                console.log('Submitted OTP:', otp);
        };

        const handleReSendVerifcationCode = () => {
                if (otp.length !== 6) {
                        setError('The Code must be Exactly 6 Digits');
                        return;
                } else {
                        setError('');
                        setIsVerificated(true);
                }
                console.log('Submitted OTP:', otp);
        };
        return (
                <MDBox
                        sx={{
                                backgroundColor: colors.white.main,
                                p: 1,
                                borderRadius: 2,
                                width: '100%',
                                justifyContent: 'center',
                                textAlign: 'center'
                        }}
                >
                        <MDBox
                                sx={{
                                        display: 'block',
                                        alignItems: 'center',
                                        borderRadius: 2,
                                        p: 2,
                                        mt: 2,
                                }}
                        >
                                <MDTypography typography={typography.h5}> Verification Code Sent</MDTypography>
                                <Lottie
                                        animationData={verification}
                                        autoPlay
                                        style={{
                                                width: 320,
                                                height: 320,
                                                margin: 'auto',
                                        }}
                                />
                                <MDTypography typography={typography.body2} pb={4}>{`Code is Sent on Your Email ${getValue('email')}`}</MDTypography>
                                <OTPInput
                                        value={otp}
                                        onChange={setOtp}
                                        numInputs={6}
                                        containerStyle={{
                                                marginBottom: '20px',
                                                justifyContent: 'center',
                                        }}
                                        inputStyle={{
                                                width: '70px', height: '70px',
                                                fontSize: '24px', marginRight: '10px',
                                                border: error ? '2px solid red' : '2px solid #dee2e6',
                                        }}
                                        focusStyle={{ borderColor: colors.gradients.info.state }}
                                        isInputNum
                                        separator={<span>-</span>}
                                        renderInput={(props) => <input {...props} />}
                                />
                                {error &&
                                        <MDTypography style={{ color: 'red' }}>{error}</MDTypography>
                                }
                                <MainButton
                                        title={"Send Code"}
                                        colorTitle={colors.white.main}
                                        backgroundColor={colors.gradients.info.state}
                                        hoverBackgroundColor={colors.gradients.info.main}
                                        width={'auto'}
                                        isLoading={loadingVerifyCode}
                                        onClick={handleSubmitVerifcationCode}
                                />
                                <MainButton
                                        title={"Resend Code"}
                                        colorTitle={colors.grey[700]}
                                        width={'auto'}
                                        onClick={handleReSendVerifcationCode}
                                />
                        </MDBox>
                </MDBox>
        )
}

export default VerificationCard
