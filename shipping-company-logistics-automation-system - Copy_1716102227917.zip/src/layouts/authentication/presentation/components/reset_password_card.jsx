import React, { useState } from 'react'
import MDBox from '../../../../items/MDBox/MDBox'
import TextFeildForm from '../../../../components/Items/Form_TextFeild/text_feild_form';
import colors from '../../../../assets/theme/base/colors';
import MDTypography from '../../../../items/MDTypography';
import typography from '../../../../assets/theme-dark/base/typography';
import reset_password from '../../../../assets/lottie/reset_password.json';
import Lottie from 'lottie-react';
import MainButton from '../../../../components/Items/MainButton/main_button';
import { useDispatch, useSelector } from 'react-redux';
import { resetPasswordService } from '../../services/apis/reset_password_service';
import { Snackbar } from '@mui/material';

const ResetPasswordCard = () => {
        const dispatch = useDispatch();
        const [password, setPassword] = useState('');
        const [confirmPassword, setConfirmPassword] = useState('');
        const [errorSnackbarOpen, setErrorSnackbarOpen] = useState(false);
        const [errorMessage, setErrorMessage] = useState('');
        const [validationErrors, setValidationErrors] = useState({
                password: '',
                confirmPassword: ''
        });
        const resetPasswordLoading = useSelector(state => state.resetPasswordService.loading);

        const handleSetNewPassword = async () => {
                const errors = {};

                if (password.trim() === '' || password.length < 8) {
                        errors.password = 'The New Password is required and must to be greater than 7 letters';
                }
                if (confirmPassword.trim() === '') {
                        errors.confirmPassword = 'The Confirm Password is required';
                }

                if (password != confirmPassword) {
                        errors.confirmPassword = "The Password and Confirm Password isn't Matching";
                }

                setValidationErrors(errors);

                if (Object.keys(errors).length === 0) {
                        const res = await dispatch(resetPasswordService({
                                payload: {
                                        password: password
                                }
                        }));
                        if (res.payload.status === 'success') {
                                setErrorMessage('The Password is Changed');
                                setErrorSnackbarOpen(true);
                        } else {
                                setErrorMessage('Error Occurred When Change Password, Please Try Again');
                                setErrorSnackbarOpen(true);
                        }
                }
        }

        const handleSnackbarClose = () => {
                setErrorSnackbarOpen(false);
        };

        return (
                <MDBox
                        sx={{
                                backgroundColor: colors.white.main,
                                p: 1,
                                borderRadius: 2,
                                width: '100%',
                                justifyContent: 'center',
                                textAlign: 'center'
                        }}
                >

                        <MDBox
                                sx={{
                                        display: {
                                                xs: 'block',
                                                md: 'flex',
                                                xl: 'flex'
                                        },
                                        alignItems: 'center',
                                        justifyContent: 'space-around',
                                        borderRadius: 2,
                                        p: 2,

                                }}
                        > <MDBox
                                sx={{

                                        alignItems: 'center',
                                        borderRadius: 2,
                                        p: 2,
                                        mt: 2,
                                }}
                        >
                                        <MDTypography typography={typography.h5} mt={3}>Enter Your New Password</MDTypography>
                                        <MDTypography typography={typography.body2} mb={2}>Your new password is must be different to previous passwords</MDTypography>

                                        <TextFeildForm
                                                isFulWidth={true}
                                                value={password}
                                                placeholder={validationErrors.password ? validationErrors.password : "New Password"}
                                                label={"New Password"}
                                                validationColor={validationErrors.password ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.password}
                                                onChange={(e) => {
                                                        setPassword(e.target.value);
                                                        setValidationErrors({ ...validationErrors, password: '' });
                                                }}
                                        />

                                        <TextFeildForm
                                                isFulWidth={true}
                                                value={confirmPassword}
                                                placeholder={validationErrors.confirmPassword ? validationErrors.confirmPassword : "Confirm Password"}
                                                label={"Confirm Password"}
                                                validationColor={validationErrors.confirmPassword ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.confirmPassword}
                                                onChange={(e) => {
                                                        setConfirmPassword(e.target.value);
                                                        setValidationErrors({ ...validationErrors, confirmPassword: '' });
                                                }}
                                        />
                                        {/* <MDBox sx={{ my: 2 }} /> */}
                                        <MainButton
                                                title={"Confirm Password"}
                                                colorTitle={colors.white.main}
                                                backgroundColor={colors.gradients.info.state}
                                                hoverBackgroundColor={colors.gradients.info.main}
                                                width={'auto'}
                                                isLoading={resetPasswordLoading}
                                                onClick={handleSetNewPassword}
                                        />

                                </MDBox>
                                <MDBox>
                                        <Lottie
                                                animationData={reset_password}
                                                autoPlay
                                                style={{
                                                        width: 320,
                                                        height: 320,
                                                        margin: 'auto',
                                                }}
                                        />
                                </MDBox>

                        </MDBox>
                        <Snackbar
                                open={errorSnackbarOpen}
                                autoHideDuration={4000}
                                onClose={handleSnackbarClose}
                                message={errorMessage}
                                anchorOrigin={{
                                        vertical: 'bottom', horizontal: 'center', backgroundColor: errorMessage ?
                                                colors.error.main : colors.success.main
                                }}
                        />
                </MDBox>
        );
}

export default ResetPasswordCard
