import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../core/network/api.jsx';

export const getProfileService = createAsyncThunk(
        'auth/profile',
        async () => {
                try {
                        const response = await api.get(`auth/profile`);
                        console.log("Response:", response.data);
                        return response.data;
                } catch (error) {
                        throw Error(error.response.data.message);
                }
        }
);

const getProfileServiceSlice = createSlice({
        name: 'getProfileService',
        initialState: {
                profileData: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getProfileService.pending, (state) => {
                                state.loading = true;
                                state.error = null;
                        })
                        .addCase(getProfileService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.profileData = action.payload.data;
                        })
                        .addCase(getProfileService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getProfileServiceSlice.reducer;
