import React from 'react'
import { Box } from '@mui/material'
import MDTypography from '../../../../items/MDTypography'
import typography from './../../../../assets/theme/base/typography';
import colors from '../../../../assets/theme/base/colors';

const PersonalInfoProfileCard = ({ name, fatherName, motherName, salary, brithDate, address, phoneNumber, nationalNumber, nationalty, degree, gender, email }) => {
  return (
    <Box sx={{
      display: 'block',
      alignItems: 'center',
      border: '1px solid #dee2e6',
      borderRadius: 2,
      p: 2,
      mt: 2,
      textAlign: 'start'

    }}>

      <MDTypography typography={typography.body1} fontWeight="bold">Personal Information</MDTypography>

      <Box sx={{ display: 'flex', p: 1, justifyContent: 'space-around', textAlign: 'start' }}>

        <Box m={2}>
          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500] }}>My Name</MDTypography>
          <MDTypography typography={typography.body2} >{name}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Mother Name</MDTypography>
          <MDTypography typography={typography.body2}>{motherName}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Email</MDTypography>
          <MDTypography typography={typography.body2}>{email}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Nationality</MDTypography>
          <MDTypography typography={typography.body2}>{nationalty}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Brith Date</MDTypography>
          <MDTypography typography={typography.body2}>{brithDate}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Salary</MDTypography>
          <MDTypography typography={typography.body2}>{salary} AED</MDTypography>
        </Box>


        <Box m={2}>
          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Father Name</MDTypography>
          <MDTypography typography={typography.body2} >{fatherName}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Gender</MDTypography>
          <MDTypography typography={typography.body2}>{gender}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Phone Number</MDTypography>
          <MDTypography typography={typography.body2}>{phoneNumber}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>National Number</MDTypography>
          <MDTypography typography={typography.body2}>{nationalNumber}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Address</MDTypography>
          <MDTypography typography={typography.body2}>{address}</MDTypography>

          <MDTypography typography={typography.body2} sx={{ color: colors.grey[500], pt: 1 }}>Degree</MDTypography>
          <MDTypography typography={typography.body2}>{degree}</MDTypography>
        </Box>

      </Box>
    </Box>
  )
}

export default PersonalInfoProfileCard

