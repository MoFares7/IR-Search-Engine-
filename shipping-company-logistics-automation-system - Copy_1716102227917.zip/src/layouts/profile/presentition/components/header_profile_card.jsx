import React from 'react'
import { Box } from '@mui/material'
import profile from '../../../../assets/lottie/profile.json';
import Lottie from 'lottie-react'
import MDTypography from '../../../../items/MDTypography'
import typography from './../../../../assets/theme/base/typography';
import activeState from '../../../../assets/lottie/anactive_state.json';
import anActiveState from '../../../../assets/lottie/active_state.json';

const HeaderProfileCard = ({ userName, userPosition, stateProfile }) => {
        return (
                <Box sx={{
                        display: 'flex',
                        alignItems: 'center',
                        border: '1px solid #dee2e6',
                        borderRadius: 2,
                        p: 2,
                        justifyContent: 'space-between'
                }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', }}>
                                <Lottie animationData={profile} autoplay loop style={{ alignItems: 'center', width: 150, height: 150 }} />
                                <Box px={3} >
                                        <MDTypography typography={typography.body2} fontWeight="bold">{userName}</MDTypography>
                                        <MDTypography typography={typography.body2}>{userPosition}</MDTypography>
                                </Box>
                        </Box>

                        <Lottie animationData={stateProfile ? activeState : anActiveState} autoplay loop style={{ alignItems: 'center', width: 150, height: 150 }} />

                </Box>
        )
}

export default HeaderProfileCard
