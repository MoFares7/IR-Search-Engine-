import React from 'react'
import { Box } from '@mui/material'
import MainButton from './../../../../components/Items/MainButton/main_button';
import colors from '../../../../assets/theme/base/colors';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { sendCodeVerificationService } from '../../../authentication/services/apis/send_code_service';

const ConfigProfileCard = () => {
        const dispatch = useDispatch();
        const navigate = useNavigate();

        const handleSendCodeVerification = () => {
                dispatch(sendCodeVerificationService());
                navigate('/verification-code');
        }

        return (
                <Box sx={{
                        display: 'flex',
                        alignItems: 'center',
                        border: '1px solid #dee2e6',
                        borderRadius: 2,
                        p: 2,
                        my: 2,
                        justifyContent: 'space-around'
                }}>

                        <MainButton
                                title={'Change Password'}
                                colorTitle={colors.white.main}
                                backgroundColor={colors.gradients.error.state}
                                hoverBackgroundColor={colors.gradients.error.main}
                                onClick={handleSendCodeVerification}
                        />
                        <MainButton
                                title={'Download CV'}
                                colorTitle={colors.white.main}
                                backgroundColor={colors.gradients.info.state}
                                hoverBackgroundColor={colors.gradients.info.main}

                        />

                </Box>
        )
}

export default ConfigProfileCard
