import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DashboardLayout from '../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../components/Navbars/DashboardNavbar';
import { Box } from '@mui/material';
import colors from '../../../../assets/theme/base/colors';
import HeaderProfileCard from '../components/header_profile_card';
import PersonalInfoProfileCard from '../components/personal_info_profile_card';
import ConfigProfileCard from '../components/config_profile_card';
import { getProfileService } from '../../services/get_profile_service';
import LoaderCard from './../../../../components/handleState/loader_card';

const ProfilePage = () => {
        const dispatch = useDispatch();
        const profileData = useSelector((state) => state.getProfileService.profileData);
        const profileLoading = useSelector((state) => state.getProfileService.loading);

        useEffect(() => {
                dispatch(getProfileService());
        }, [dispatch]);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <Box sx={{
                                backgroundColor: colors.white.main,
                                p: 1,
                                borderRadius: 2
                        }}>
                                {profileLoading ?
                                        <LoaderCard />
                                        :
                                        <>
                                                <HeaderProfileCard
                                                        userName={profileData.username}
                                                        userPosition={profileData.type} 
                                                        stateProfile={true}
                                                />

                                                <PersonalInfoProfileCard
                                                        name={profileData.username} 
                                                        fatherName={profileData.father_name}
                                                        motherName={profileData.mother_name}
                                                        brithDate={profileData.bitrh_date} 
                                                        degree={profileData.degree}
                                                        gender={profileData.gender}
                                                        address={profileData.address}
                                                        email={profileData.email}
                                                        salary={profileData.salary}
                                                        phoneNumber={profileData.phone_number}
                                                        nationalNumber={profileData.id_number} 
                                                        nationalty={profileData.nationality}
                                                />

                                                <ConfigProfileCard />
                                        </>
                                }
                              
                        </Box>
                </DashboardLayout>
        );
}

export default ProfilePage;
