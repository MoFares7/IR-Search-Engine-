import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const updateEquivDiscountService = createAsyncThunk(
        'employee/UpdatePercentType',
        async ({ operationID }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`employee/UpdatePercentType/${operationID}`);
                        console.log("updateEquivDiscountService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const updateEquivDiscountServiceSlice = createSlice({
        name: 'updateEquivDiscountService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(updateEquivDiscountService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(updateEquivDiscountService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(updateEquivDiscountService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default updateEquivDiscountServiceSlice.reducer;
