import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const getEquivalentDiscontBranchService = createAsyncThunk(
        'employee/getBonusForBranchManager',
        async () => {
                try {
                        const response = await api.get(`employee/getBonusForEmployee`);
                        return response.data;
                } catch (error) {
                        throw Error(error.response.message);
                }
        }
);

const getEquivalentDiscontBranchServiceSlice = createSlice({
        name: 'getEquivalentDiscontBranchService',
        initialState: {
                data: [],
                error: null,
                loading: false,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getEquivalentDiscontBranchService.pending, (state) => {
                                state.loading = true;
                                state.error = null;
                        })
                        .addCase(getEquivalentDiscontBranchService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.data = action.payload.data;
                        })
                        .addCase(getEquivalentDiscontBranchService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getEquivalentDiscontBranchServiceSlice.reducer;