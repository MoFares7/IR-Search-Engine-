import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const getEquivalentDiscontManagerService = createAsyncThunk(
        'employee/getBonusForBranchManager',
        async () => {
                try {
                        const response = await api.get(`employee/getBonusForBranchManager`);
                        return response.data;
                } catch (error) {
                        throw Error(error.response.message);
                }
        }
);

const getEquivalentDiscontManagerServiceSlice = createSlice({
        name: 'getEquivalentDiscontManagerService',
        initialState: {
                data: [],
                error: null,
                loading: false,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getEquivalentDiscontManagerService.pending, (state) => {
                                state.loading = true;
                                state.error = null;
                        })
                        .addCase(getEquivalentDiscontManagerService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.data = action.payload.data;
                        })
                        .addCase(getEquivalentDiscontManagerService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getEquivalentDiscontManagerServiceSlice.reducer;