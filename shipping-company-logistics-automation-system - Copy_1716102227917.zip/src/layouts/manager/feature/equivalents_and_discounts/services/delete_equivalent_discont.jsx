import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const deleteEquivDiscountService = createAsyncThunk(
        'employee/deletePercentType',
        async ({ operationID }, { rejectWithValue }) => {
                try {
                        const response = await api.get(`employee/deletePercentType/${operationID}`);
                        console.log("deleteEquivDiscountService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const deleteEquivDiscountServiceSlice = createSlice({
        name: 'deleteEquivDiscountService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(deleteEquivDiscountService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(deleteEquivDiscountService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(deleteEquivDiscountService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default deleteEquivDiscountServiceSlice.reducer;
