import React from 'react';
import colors from '../../../../../../assets/theme/base/colors';
import { Box, Icon } from '@mui/material';
import MDTypography from '../../../../../../items/MDTypography';
import typography from './../../../../../../assets/theme/base/typography';

const InfoEmployeeCard = ({ icon, title, titleValue,backgroundColor }) => {
        return (
                <Box display="flex"
                        sx={{
                                border: '1px solid #fff',
                                p: 1,
                                m: 1,
                                borderRadius: 2,
                                alignItems: 'center',
                                backgroundColor: backgroundColor,
                                justifyContent: "space-between",
                                alignItems:'center'
                        }}>
                        <Box display="flex" alignItems='center' >
                                <Icon>{icon}</Icon>
                                <MDTypography typography={typography.body2} sx={{ color: colors.white.main, pl: 1 }}>{title} </MDTypography>
                        </Box>
                        <Box display="flex" alignItems='center' >
                                <MDTypography typography={typography.body2} sx={{ color: colors.white.main }}>{titleValue}</MDTypography>
                        </Box>

                </Box>
        )
}

export default InfoEmployeeCard
