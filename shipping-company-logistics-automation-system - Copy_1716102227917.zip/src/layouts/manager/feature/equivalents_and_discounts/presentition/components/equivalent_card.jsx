import React, { useState } from 'react';
import colors from '../../../../../../assets/theme/base/colors';
import { Box, IconButton, Menu } from '@mui/material';
import MDTypography from '../../../../../../items/MDTypography';
import typography from './../../../../../../assets/theme/base/typography';
import { DeleteOutlineOutlined, LanOutlined, MoneyOutlined, MoreVertRounded, Person3Outlined, PhoneOutlined, UpdateOutlined } from '@mui/icons-material';
import InfoEmployeeCard from '../components/info_card';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import { useDispatch, useSelector } from 'react-redux';
import { deleteEquivDiscountService } from '../../services/delete_equivalent_discont';
import { getEquivalentDiscontBranchService } from '../../services/get_equivalents_discont_branch_service';
import { getEquivalentDiscontManagerService } from '../../services/get_equivalents_discont_manager_service';
import { getValue } from '../../../../../../core/storage/storage';

const EquivalentCard = ({ operationID, percentType, percent, username, nationality, phone_number, salary, backgroundColor }) => {
        const dispatch = useDispatch();
        const [openMenu, setOpenMenu] = useState(null);

        const deleteLoading = useSelector(state => state.deleteEquivDiscountService.loading);

        const handleUpdateOperation = () => {
                console.log("t1t: " + operationID);
        }

        const handleDeleteOperation = () => {
                console.log("t2t: " + operationID);
                dispatch(deleteEquivDiscountService({ operationID })).then(() => {
                        getValue('type') === 'branch_admin'
                                ? dispatch(getEquivalentDiscontBranchService())
                                : dispatch(getEquivalentDiscontManagerService());
                });
        }

        const renderMenu = (
                <Menu
                        anchorEl={openMenu}
                        anchorReference="anchorEl"
                        anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'left',
                        }}
                        open={Boolean(openMenu)}
                        onClose={() => setOpenMenu(null)}
                        sx={{ mt: 1 }}
                >
                        <MenuOptionItem icon={<UpdateOutlined />} title="Update Operation" onClick={handleUpdateOperation} />
                        <MenuOptionItem icon={<DeleteOutlineOutlined />} title={deleteLoading ? "Deleting..." : "Delete Operation"} onClick={handleDeleteOperation} />
                </Menu>
        );

        return (
                <Box sx={{
                        backgroundColor: percentType === 'bonus' ? colors.success.main : colors.error.focus,
                        borderRadius: 2,
                        marginTop: 2,
                        padding: 2,
                        textAlign: 'center',
                        transition: 'transform 0.4s ease',
                        '&:hover': {
                                transform: 'scale(0.99)',
                        },
                }}>
                        <MDBox display="flex" justifyContent="space-between" color="black">
                                <MDTypography typography={typography.h5} sx={{ color: colors.white.main }}> {percentType}</MDTypography>
                                <IconButton
                                        size="medium"
                                        disableRipple
                                        color="inherit"
                                        aria-controls="notification-menu"
                                        aria-haspopup="true"
                                        variant="contained"
                                        onClick={(event) => setOpenMenu(event.currentTarget)}
                                >
                                        <MoreVertRounded sx={{ color: colors.white.main }} />
                                </IconButton>
                        </MDBox>
                        {renderMenu}
                        <MDTypography typography={typography.h2} sx={{ color: colors.white.main }}>{percent}%</MDTypography>

                        <InfoEmployeeCard
                                icon={<Person3Outlined sx={{ color: colors.white.main }} />}
                                title={'Employee Name'}
                                titleValue={username}
                                backgroundColor={backgroundColor}
                        />
                        <InfoEmployeeCard
                                icon={<LanOutlined sx={{ color: colors.white.main }} />}
                                title={'Employee Nationality'}
                                titleValue={nationality}
                                backgroundColor={backgroundColor}
                        />
                        <InfoEmployeeCard
                                icon={<PhoneOutlined sx={{ color: colors.white.main }} />}
                                title={'Employee Phone Number'}
                                titleValue={phone_number}
                                backgroundColor={backgroundColor}
                        />
                        <InfoEmployeeCard
                                icon={<MoneyOutlined sx={{ color: colors.white.main }} />}
                                title={'Employee Salary'}
                                titleValue={salary}
                                backgroundColor={backgroundColor}
                        />
                </Box>
        );
}

export default EquivalentCard;
