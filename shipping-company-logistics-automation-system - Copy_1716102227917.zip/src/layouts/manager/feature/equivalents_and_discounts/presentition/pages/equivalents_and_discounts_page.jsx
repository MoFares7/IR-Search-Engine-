import React, { useEffect } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import MDBox from '../../../../../../items/MDBox/MDBox';
import colors from '../../../../../../assets/theme/base/colors';
import Lottie from 'lottie-react';
import budget from '../../../../assets/lottie/budget.json';
import { Grid } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { getEquivalentDiscontManagerService } from '../../services/get_equivalents_discont_manager_service';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import EquivalentCard from '../components/equivalent_card';
import { getValue } from '../../../../../../core/storage/storage';
import { getEquivalentDiscontBranchService } from '../../services/get_equivalents_discont_branch_service';
import EmptyCard from '../../../../../../components/handleState/empty_card';

const EquivalentsAndDiscountsPage = () => {
        const dispatch = useDispatch();
        const typeEmployee = getValue('type');
        const equivalentsDiscounts = typeEmployee === 'branch_admin' ?
                useSelector(state => state.getEquivalentDiscontBranchService.data)
                :
                useSelector(state => state.getEquivalentDiscontManagerService.data);
        const equivalentsDiscountsLoading = typeEmployee === 'branch_admin' ?
                useSelector(state => state.getEquivalentDiscontBranchService.loading)
                :
                useSelector(state => state.getEquivalentDiscontManagerService.loading);

        useEffect(() => {
                typeEmployee === 'branch_admin'
                        ?
                        dispatch(getEquivalentDiscontBranchService())
                        :
                        dispatch(getEquivalentDiscontManagerService());
        }, [dispatch]);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <MDBox sx={{ display: 'flex', textAlign: 'center', justifyContent: 'center' }}>
                                <Lottie animationData={budget} autoplay style={{
                                        width: 320,
                                        height: 320,
                                        textAlign: 'center',
                                        alignItems: 'center',
                                }}
                                />
                        </MDBox>

                        {equivalentsDiscountsLoading ? (
                                <LoaderCard />
                        ) : (
                                <>
                                        {equivalentsDiscounts.length === 0 ? (
                                                <EmptyCard
                                                        message={"Not Found Any Operation"} />
                                        ) : (
                                                <Grid container spacing={2}>
                                                        {equivalentsDiscounts.map((equivalentDiscount, index) => (
                                                                <React.Fragment key={index}>
                                                                        {equivalentDiscount.percent_type !== 'deduction' && (
                                                                                <Grid item xs={12} sm={6}>
                                                                                        <EquivalentCard
                                                                                                operationID={equivalentDiscount.id}
                                                                                                percentType={equivalentDiscount.percent_type}
                                                                                                percent={equivalentDiscount.percent}
                                                                                                username={equivalentDiscount.username}
                                                                                                nationality={equivalentDiscount.nationality}
                                                                                                phone_number={equivalentDiscount.phone_number}
                                                                                                salary={equivalentDiscount.salary}
                                                                                                backgroundColor={colors.gradients.success.state}
                                                                                        />
                                                                                </Grid>
                                                                        )}
                                                                        {equivalentDiscount.percent_type === 'deduction' && (
                                                                                <Grid item xs={12} sm={6}>
                                                                                        <EquivalentCard
                                                                                                operationID={equivalentDiscount.id}
                                                                                                percentType={equivalentDiscount.percent_type}
                                                                                                percent={equivalentDiscount.percent}
                                                                                                username={equivalentDiscount.username}
                                                                                                nationality={equivalentDiscount.nationality}
                                                                                                phone_number={equivalentDiscount.phone_number}
                                                                                                salary={equivalentDiscount.salary}
                                                                                                backgroundColor={colors.gradients.error.state}
                                                                                        />
                                                                                </Grid>
                                                                        )}
                                                                </React.Fragment>
                                                        ))}
                                                </Grid>
                                        )}
                                </>
                        )}
                </DashboardLayout>
        );
}

export default EquivalentsAndDiscountsPage;
