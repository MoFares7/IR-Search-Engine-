import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const getPermissionWarehouse = createAsyncThunk(
        'permission/getWarehousePending',
        async () => {
                try {
                        const response = await api.get(`permission/getWarehousePending`);
                        console.log("Response:", response.data);
                        return response.data;
                } catch (error) {
                        throw Error(error.response.data.message);
                }
        }
);

const permissionWarehouseSlice = createSlice({
        name: 'getPermissionWarehouse',
        initialState: {
                permissionWarehouseData: [],
                permissionWarehouseLoading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getPermissionWarehouse.pending, (state) => {
                                state.permissionWarehouseLoading = true;
                                state.error = null;
                        })
                        .addCase(getPermissionWarehouse.fulfilled, (state, action) => {
                                state.permissionWarehouseLoading = false;
                                state.permissionWarehouseData = action.payload.data;
                        })
                        .addCase(getPermissionWarehouse.rejected, (state, action) => {
                                state.permissionWarehouseLoading = false;
                                state.error = action.error.message;
                        });
        },
});

export default permissionWarehouseSlice.reducer;
