import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const changeStatusPermission = createAsyncThunk(
        'branch/changeStatus',
        async ({ permissionID, payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`permission/changeType/${permissionID}`, payload);
                        console.log("changeStatusPermission success: ", response.data);
                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const changeStatusPermissionSlice = createSlice({
        name: 'changeStatusPermission',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(changeStatusPermission.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(changeStatusPermission.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.status;
                        })
                        .addCase(changeStatusPermission.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error; // Potential issue here
                        });
        },
});

export default changeStatusPermissionSlice.reducer;
