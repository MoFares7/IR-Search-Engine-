import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const getPermissionTruck = createAsyncThunk(
        'permissionTruck/get',
        async () => {
                try {
                        const response = await api.get(`permission/getTruckPending`);
                        console.log("Response:", response.data);
                        return response.data;
                } catch (error) {
                        throw Error(error.response.data.message);
                }
        }
);

const permissionTruckSlice = createSlice({
        name: 'getPermissionTruck',
        initialState: {
                permissionTruckData: [],
                permissionTruckLoading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getPermissionTruck.pending, (state) => {
                                state.permissionTruckLoading = true;
                                state.error = null;
                        })
                        .addCase(getPermissionTruck.fulfilled, (state, action) => {
                                state.permissionTruckLoading = false;
                                state.permissionTruckData = action.payload.data;
                        })
                        .addCase(getPermissionTruck.rejected, (state, action) => {
                                state.permissionTruckLoading = false;
                                state.error = action.error.message;
                        });
        },
});

export default permissionTruckSlice.reducer;
