import React, { useState } from 'react'
import { Box, CircularProgress, TextField } from '@mui/material'
import MDTypography from '../../../../../../items/MDTypography'
import colors from '../../../../../../assets/theme/base/colors'
import typography from '../../../../../../assets/theme-dark/base/typography';
import MDBox from '../../../../../../items/MDBox/MDBox'
import MDAvatar from '../../../../../../items/MDAvatar'
import media from '../../../../../../assets/images/home-decor-1.jpg'
import MainButton from '../../../../../../components/Items/MainButton/main_button'
import { useDispatch, useSelector } from 'react-redux';
import { getPermissionTruck } from '../../services/get_permission_truck';
import { getPermissionWarehouse } from '../../services/get_permission_warehouse';
import { changeStatusPermission } from '../../services/detect_status_permission';
const RequestCard = ({ permissionID, image, branchName, namePices, dateRequest, cost, type, isWarehouse }) => {
        const dispatch = useDispatch();
        const [isRejected, setIsRejected] = useState(false);
        const [loading, setLoading] = useState(false);
        const [loadingReject, setLoadingReject] = useState(false);

        const handleAcceptRequest = () => {
                setLoading(true);
                dispatch(changeStatusPermission({
                        permissionID,
                        payload: {
                                type: 'accepted',
                                object: type
                        }
                })).then((res) => {
                        if (res.payload && res.payload.status === 'success') {
                                dispatch(getPermissionTruck());
                                dispatch(getPermissionWarehouse());
                        }
                        setLoading(false);
                });
        }

        const handleRejectRequest = () => {
                setIsRejected(true);
                setLoadingReject(true);
                dispatch(changeStatusPermission({
                        permissionID: permissionID,
                        payload: {
                                type: 'rejected',
                                object: type
                        }
                })).then((res) => {
                        if (res.payload && res.payload.status === 'success') {
                                dispatch(getPermissionTruck());
                                dispatch(getPermissionWarehouse());
                        }
                        setLoadingReject(false);
                });
        }

        return (
                <MDBox sx={{
                        backgroundColor: colors.white.main,
                        width: '100%',
                        borderRadius: 2,
                        p: 2,
                        my: 1.5,
                        '&:hover': {
                                backgroundColor: colors.grey[100]
                        }
                }}>
                        <MDBox sx={{
                                display: {
                                        xs: 'block',
                                        md: 'flex',
                                        xl: 'flex'
                                },
                                justifyContent: 'space-between',
                                alignContent: 'center',
                                alignItems: 'center'
                        }} >
                                <MDBox sx={{
                                        alignContent: 'center',
                                        display: {
                                                xs: 'block',
                                                md: 'flex',
                                                xl: 'flex'
                                        },
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        p: 1
                                }}>
                                        <MDAvatar
                                                src={image}
                                                alt={'branch name'}
                                                // size="xs"
                                                sx={({ borders: { borderWidth } }) => ({
                                                        border: `${borderWidth[2]} solid ${colors.grey[300]}`,
                                                        mr: 2,
                                                        width: {
                                                                xs: 60,
                                                                sm: 60,
                                                                md: 80,
                                                                xs: 80
                                                        },
                                                        height: {
                                                                xs: 60,
                                                                sm: 60,
                                                                md: 80,
                                                                xs: 80
                                                        },
                                                        justifyContent: 'center',
                                                        transform: 'revert',
                                                        "&:hover, &:focus": {
                                                                backgroundColor: colors.grey[100]
                                                        },
                                                })}
                                        />

                                        <MDBox sx={{ alignContent: 'center', p: 1, }}>
                                                <MDBox display='flex' sx={{ justifyContent: 'space-between', }}>
                                                        <MDTypography typography={typography.body2} sx={{ mr: 1 }} >
                                                                Branch Name:
                                                        </MDTypography>
                                                        <MDTypography typography={typography.body2} >
                                                                {branchName}
                                                        </MDTypography>
                                                </MDBox>
                                                <MDBox display='flex' sx={{ justifyContent: 'space-between' }}>
                                                        <MDTypography typography={typography.body2} sx={{ mr: 1 }}>
                                                                {isWarehouse ? 'WarehousName' : 'Truck Name:'}
                                                        </MDTypography>
                                                        <MDTypography typography={typography.body2} >
                                                                {namePices}
                                                        </MDTypography>
                                                </MDBox>
                                                <MDBox display='flex' sx={{ justifyContent: 'space-between' }}>
                                                        <MDTypography typography={typography.body2} sx={{ mr: 1 }}>
                                                                Date:
                                                        </MDTypography>
                                                        <MDTypography typography={typography.body2} >
                                                                {dateRequest}
                                                        </MDTypography>
                                                </MDBox>


                                        </MDBox>
                                </MDBox>


                                <MDBox alignContent='center'>
                                        <MDTypography typography={typography.body2} p={3}>
                                                {isWarehouse ?
                                                        <>
                                                                To the respected Prime Shippa Manager:<br />
                                                                This order to create a new wharehous in our branch contains all the important details:<br />
                                                                1- Cost: {cost} AED<br />
                                                                2. Detailed file of the truck can download her <br />
                                                                Please approve the application and thank you.<br />
                                                        </>
                                                        :
                                                        <>
                                                                To the respected Prime Shippa Manager:<br />
                                                                This order to buy a new truck to our branch contains all the important details:<br />
                                                                1- Cost: {cost} AED<br />
                                                                2. Detailed file of the truck <br />
                                                                Please approve the application and thank you.<br />
                                                        </>
                                                }
                                        </MDTypography>
                                </MDBox>

                                <Box sx={{
                                        p: 1, display: 'block', textAlign: 'center', justifyContent: 'center', alignContent: 'center',
                                }}>
                                        <Box sx={{
                                                display: {
                                                        xs: 'block',
                                                        md: 'flex',
                                                        xl: 'flex'
                                                }
                                        }}>
                                                <MainButton
                                                        title={'Accept'}
                                                        isLoading={loading}
                                                        colorTitle={colors.white.main}
                                                        backgroundColor={colors.gradients.info.state}
                                                        hoverBackgroundColor={colors.gradients.info.main}
                                                        onClick={handleAcceptRequest}
                                                        height={{
                                                                xs: 40,
                                                                sm: 40,
                                                                md: 40,
                                                                xl: 40,
                                                        }}
                                                        width={'auto'}
                                                />

                                                <Box>
                                                        <MainButton
                                                                title={'Reject'}
                                                                isLoading={loadingReject}
                                                                colorTitle={colors.white.main}
                                                                backgroundColor={colors.gradients.error.main}
                                                                hoverBackgroundColor={colors.gradients.error.state}
                                                                onClick={handleRejectRequest}
                                                                height={{
                                                                        xs: 40,
                                                                        sm: 40,
                                                                        md: 40,
                                                                        xl: 40,
                                                                }}
                                                                width={'auto'}
                                                        />
                                                </Box>

                                        </Box>

                                        <MainButton
                                                title={'Download File'}
                                                colorTitle={colors.white.main}
                                                backgroundColor={colors.gradients.secondary.main}
                                                hoverBackgroundColor={colors.gradients.secondary.state}
                                                // onClick={handleAcceptRequest}
                                                height={{
                                                        xs: 40,
                                                        sm: 40,
                                                        md: 40,
                                                        xl: 40,
                                                }}
                                                width={'auto'}
                                        />

                                </Box>
                        </MDBox>
                </MDBox >
        )
}

export default RequestCard
