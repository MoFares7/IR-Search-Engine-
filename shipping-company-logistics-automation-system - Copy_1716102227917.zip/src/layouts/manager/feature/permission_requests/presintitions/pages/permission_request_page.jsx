import React, { useState, useEffect } from 'react';
import { Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import HeaderLayout from '../../../../../../components/LayoutContainers/HeaderPageLayout/index';
import typography from '../../../../../../assets/theme-dark/base/typography';
import MDBox from '../../../../../../items/MDBox/MDBox';
import RequestCard from '../components/reqest_card';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import LoaderCard from './../../../../../../components/handleState/loader_card';
import { getPermissionTruck } from './../../services/get_permission_truck';
import { getPermissionWarehouse } from '../../services/get_permission_warehouse';
import MainDialog from '../../../../../../components/Dialog/main_dialog';

const PermissionRequestPage = () => {
        const dispatch = useDispatch();
        const [permissionID, setPermissionID] = useState(0);
        const [isDetectStatusPermission, setIsDetectStatusPermission] = useState(false);

        useEffect(() => {
                dispatch(getPermissionTruck());
                dispatch(getPermissionWarehouse());
        }, [dispatch]);

        const { permissionTruckData, permissionTruckLoading } = useSelector(state => state.getPermissionTruck);
        const { permissionWarehouseData, permissionWarehouseLoading } = useSelector(state => state.getPermissionWarehouse);

        const handleDetectStatusPermission = (permissionID) => {
                setIsDetectStatusPermission(true);
                setPermissionID(permissionID)
                console.log(" permission ID: " + permissionID);
        }

        const handleDeleteConfirmation = () => {
                console.log("this is id user: " + managerID);
                const response = dispatch(deleteBranchManager({ managerId: managerID }));
                if (response.payload.status === "success") {
                        dispatch(getBranchesManagers());
                } else {
                        setErrorMessage('An error occurred dissmial manager');
                        setErrorSnackbarOpen(true);
                }
        }

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <HeaderLayout
                                title={'Permission Requests'}
                                subTitle={"All Requests Submitted by the Heads of the Company's Branches"}
                                placeholder={"All Branches"}
                                isFilter={true}
                                options={["Abu Dhabi", "Ajman", "Al Ain", "Dubai", "Fujairah", "Ras Al Khaimah(RAK)", "Sharjah", "Umm Al Quwain(UAQ)"]}
                        />
                        {/* Display Truck Permission Requests */}
                        <Typography typography={typography.h6} sx={{ py: 2, px: 1 }}>{permissionTruckData.length} Truck Requests</Typography>
                        {permissionTruckLoading ? (
                                <LoaderCard />
                        ) : permissionTruckData && permissionTruckData.length > 0 ? (
                                <>
                                        {permissionTruckData.map((permissionTruck, index) => (
                                                <RequestCard
                                                        key={index}
                                                        permissionID={permissionTruck.id}
                                                        type={'truck'}
                                                        image={`https://prime-shippa-api.point-dev.net/storage/${permissionTruck.image.replace('public/', '')}`}
                                                        branchName={permissionTruck.branch.name}
                                                        namePices={permissionTruck.name}
                                                        dateRequest={permissionTruck.created_at.substring(0, 16)}
                                                        cost={permissionTruck.capacity}
                                                        isWarehouse={false}
                                                />
                                        ))}
                                </>
                        ) : (
                                <EmptyCard message="No Truck Permission Requests Found" />
                        )}
                        {/* Display Warehouse Permission Requests */}
                        <Typography typography={typography.h6} sx={{ py: 2, px: 1 }}>{permissionWarehouseData.length} Warehouse Requests</Typography>
                        {permissionWarehouseLoading ? (
                                <LoaderCard />
                        ) : permissionWarehouseData && permissionWarehouseData.length > 0 ? (
                                <>
                                        {permissionWarehouseData.map((permissionWarehouse, index) => (
                                                <RequestCard
                                                        key={index}
                                                        permissionID={permissionWarehouse.id}
                                                        type={'warehouse'}
                                                        image={`https://prime-shippa-api.point-dev.net/storage/${permissionWarehouse.image.replace('public/', '')}`}
                                                        branchName={permissionWarehouse.branch.name}
                                                        namePices={permissionWarehouse.name}
                                                        dateRequest={permissionWarehouse.created_at}
                                                        cost={permissionWarehouse.capacity}
                                                        isWarehouse={true}
                                                />
                                        ))}
                                </>
                        ) : (
                                <EmptyCard message="No Warehouse Permission Requests Found" />
                        )}
                        <MDBox sx={{ p: 1 }} />

                        <MainDialog
                                isDialogOpen={isDetectStatusPermission}
                                DialogClose={() => setIsDetectStatusPermission(false)}
                                headTitle={"Dismissal of Branch Manager "}
                                subTitle={"Are You Sure From Dismissal Of Branch Manager ?"}
                                onClick={handleDetectStatusPermission}
                                confirmEvent={handleDeleteConfirmation}
                        />
                </DashboardLayout>
        );
}

export default PermissionRequestPage;
