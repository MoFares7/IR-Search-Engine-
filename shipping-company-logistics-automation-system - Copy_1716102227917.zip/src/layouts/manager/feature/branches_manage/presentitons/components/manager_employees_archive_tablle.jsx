import React, { useState } from 'react';
import colors from "../../../../../../assets/theme/base/colors";
import MDAvatar from "../../../../../../items/MDAvatar";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import MDButton from '../../../../../../items/MDButton';
import { IconButton } from '@mui/material';
import { AddCircleOutline, DownloadRounded, RemoveCircleOutlineOutlined } from '@mui/icons-material';
import { useDispatch } from 'react-redux';
import { downloadFilesManagerService } from '../../services/download_file_manager_service';
import employee from '../../../../assets/lottie/employee_manager.json'
import Lottie from 'lottie-react';

export default function employeesManagerArchiveTableData(data, handleEditBranchManager, handleDeleteBranchManager, handleReEmployement, isDissimal, handleAddEquivalentDiscount) {
        const dispatch = useDispatch();

        const handleEditBranchManagerInfo = (isUpdateInfoManager, managerID, managerInfo) => {
                handleEditBranchManager(isUpdateInfoManager, managerID, managerInfo);
        }

        if (!data || !Array.isArray(data) || data.length === 0) {
                return { columns: [], rows: [] };
        }

        data = isDissimal ? (Array.isArray(data) ? data.filter(employee => employee.type === "branch_admin") : [])
                : (Array.isArray(data) ? data.filter(employee => employee.isDismissal === "false") : []);

        const Employee = ({ image, name, email }) => (
                <MDBox display="flex" alignItems="center" lineHeight={1}>
                        <Lottie animationData={employee} style={{ width: 40, height: 40 }} />
                        <MDBox ml={2} lineHeight={1}>
                                <MDTypography display="block" variant="button" fontWeight="medium">
                                        {name}
                                </MDTypography>
                                <MDTypography variant="caption">{email}</MDTypography>
                        </MDBox>
                </MDBox>
        );

        const Job = ({ title, description }) => (
                <MDBox lineHeight={1} textAlign="left">
                        <MDTypography display="block" variant="caption" color="text" fontWeight="medium">
                                {title}
                        </MDTypography>
                        <MDTypography variant="caption">{description}</MDTypography>
                </MDBox>
        );

        const rows = data.map(employee => ({
                employee: (
                        <Employee
                                name={employee.username}
                                email={employee.email}
                        />
                ),
                function: <Job title={employee.type} description={employee.degree} />,
                FatherName: <MDTypography variant="caption">{employee.father_name}</MDTypography>,
                MotherName: <MDTypography variant="caption">{employee.mother_name}</MDTypography>,
                address: <MDTypography variant="caption">{employee.address}</MDTypography>,
                NationalID: <MDTypography variant="caption">{employee.id_number}</MDTypography>,
                Email: <MDTypography variant="caption">{employee.email}</MDTypography>,
                phone: <MDTypography variant="caption">{employee.phone_number}</MDTypography>,
                nationality: <MDTypography variant="caption">{employee.nationality}</MDTypography>,
                BrithDate: <MDTypography variant="caption">{employee.bitrh_date}</MDTypography>,
                CV: <IconButton
                        onClick={() => {
                                dispatch(downloadFilesManagerService({ user_id: employee.id }))
                        }}>
                        <DownloadRounded sx={{ color: colors.info.main }} />
                </IconButton>,
                actions: (
                        <MDBox sx={{ display: 'flex' }}>
                                {isDissimal ?
                                        <MDButton onClick={() => { handleReEmployement(employee.id) }}
                                                variant="caption" fontWeight="medium" sx={{ color: colors.error.main }}>
                                                Re-Employement
                                        </MDButton>
                                        :
                                        <>
                                                <MDButton onClick={() => handleEditBranchManagerInfo(true, employee.id, employee)} // Pass employee instead of { ...managerInfo }
                                                        variant="caption" fontWeight="medium" sx={{ color: colors.success.main }}>
                                                        Edit
                                                </MDButton>
                                                <MDBox sx={{ pl: 1 }} />
                                                <MDButton onClick={() => handleDeleteBranchManager(employee.id)}
                                                        variant="caption" fontWeight="medium" sx={{ color: colors.error.main }}>
                                                        Dismissal
                                                </MDButton>
                                        </>
                                }

                        </MDBox>
                ),
        }));

        return {
                columns: [
                        { Header: 'Employee', accessor: 'employee', width: '15%', align: 'left' },
                        { Header: 'Function', accessor: 'function', align: 'left' },
                        { Header: 'Father Name', accessor: 'FatherName', align: 'center' },
                        { Header: 'Mother Name', accessor: 'MotherName', align: 'center' },
                        { Header: 'National ID', accessor: 'NationalID', align: 'center' },
                        { Header: 'Nationality', accessor: 'nationality', align: 'center' },
                        { Header: 'Email', accessor: 'Email', align: 'center' },
                        { Header: 'Address', accessor: 'address', align: 'center' },
                        { Header: 'Phone', accessor: 'phone', align: 'center' },
                        { Header: 'BrithDate', accessor: 'BrithDate', align: 'center' },
                        { Header: 'CV', accessor: 'CV', align: 'center' },
                        { Header: 'Actions', accessor: 'actions', align: 'center' },
                ],
                rows: rows,
        };
}
