import React, { useState } from 'react';
import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import MDButton from '../../../../../../items/MDButton';
import { IconButton } from '@mui/material';
import { AddCircleOutline, DownloadRounded, RemoveCircleOutlineOutlined } from '@mui/icons-material';
import { useDispatch } from 'react-redux';
import { downloadFilesManagerService } from '../../services/download_file_manager_service';
import employee from '../../../../assets/lottie/employee_manager.json'
import Lottie from 'lottie-react';

export default function employeesTableData(data, handleEditBranchManager, handleDeleteBranchManager, handleAddEquivalentDiscount) {
        const dispatch = useDispatch();

        const handleEditBranchManagerInfo = (isUpdateInfoManager, managerID, managerInfo) => {
                handleEditBranchManager(isUpdateInfoManager, managerID, managerInfo);
        }

        if (!data || !Array.isArray(data) || data.length === 0) {
                return { columns: [], rows: [] };
        }
        data = (Array.isArray(data) ? data.filter(employee => employee.manager.isDismissal === "false") : []);

        const Employee = ({ image, name, email }) => (
                <MDBox display="flex" alignItems="center" lineHeight={1}>
                        <Lottie animationData={employee} style={{ width: 40, height: 40 }} />
                        <MDBox ml={2} lineHeight={1}>
                                <MDTypography display="block" variant="button" fontWeight="medium">
                                        {name}
                                </MDTypography>
                                <MDTypography variant="caption">{email}</MDTypography>
                        </MDBox>
                </MDBox>
        );

        const Job = ({ title, description }) => (
                <MDBox lineHeight={1} textAlign="left">
                        <MDTypography display="block" variant="caption" color="text" fontWeight="medium">
                                {title}
                        </MDTypography>
                        <MDTypography variant="caption">{description}</MDTypography>
                </MDBox>
        );

        const rows = data.map(employee => ({
                employee: (
                        <Employee
                                name={employee.manager.username}
                                email={employee.manager.email}
                        />
                ),
                function: <Job title={employee.manager.type} description={employee.manager.degree} />,
                FatherName: <MDTypography variant="caption">{employee.manager.father_name}</MDTypography>,
                MotherName: <MDTypography variant="caption">{employee.manager.mother_name}</MDTypography>,
                address: <MDTypography variant="caption">{employee.manager.address}</MDTypography>,
                NationalID: <MDTypography variant="caption">{employee.manager.id_number}</MDTypography>,
                Email: <MDTypography variant="caption">{employee.manager.email}</MDTypography>,
                phone: <MDTypography variant="caption">{employee.manager.phone_number}</MDTypography>,
                nationality: <MDTypography variant="caption">{employee.manager.nationality}</MDTypography>,
                BrithDate: <MDTypography variant="caption">{employee.manager.bitrh_date}</MDTypography>,
                CV: <IconButton
                        onClick={() => {
                                dispatch(downloadFilesManagerService({ user_id: employee.manager.id }))
                        }}>
                        <DownloadRounded sx={{ color: colors.info.main }} />
                </IconButton>,
                EquivalentsAndDiscounts: (
                        <MDBox sx={{ display: 'flex' }} >
                                <IconButton onClick={() => handleAddEquivalentDiscount(employee.manager.id, 'bonus')}>
                                        <AddCircleOutline sx={{ color: colors.info.main }} />
                                </IconButton>
                                <IconButton onClick={() => handleAddEquivalentDiscount(employee.manager.id, 'deduction')}>
                                        <RemoveCircleOutlineOutlined sx={{ color: colors.error.main }} />
                                </IconButton>
                                <MDBox sx={{ pl: 1 }} />
                        </MDBox>

                ),
                actions: (
                        <MDBox sx={{ display: 'flex' }}>
                                <MDButton onClick={() => handleEditBranchManagerInfo(true, employee.manager.id, employee.manager)}
                                        variant="caption" fontWeight="medium" sx={{ color: colors.success.main }}>
                                        Edit
                                </MDButton>
                                <MDBox sx={{ pl: 1 }} />
                                <MDButton onClick={() => handleDeleteBranchManager(employee.manager.id)}
                                        variant="caption" fontWeight="medium" sx={{ color: colors.error.main }}>
                                        Dismissal
                                </MDButton>
                        </MDBox>
                ),
        }));

        return {
                columns: [
                        { Header: 'Employee', accessor: 'employee', width: '15%', align: 'left' },
                        { Header: 'Function', accessor: 'function', align: 'left' },
                        { Header: 'Father Name', accessor: 'FatherName', align: 'center' },
                        { Header: 'Mother Name', accessor: 'MotherName', align: 'center' },
                        { Header: 'National ID', accessor: 'NationalID', align: 'center' },
                        { Header: 'Nationality', accessor: 'nationality', align: 'center' },
                        { Header: 'Email', accessor: 'Email', align: 'center' },
                        { Header: 'Address', accessor: 'address', align: 'center' },
                        { Header: 'Phone', accessor: 'phone', align: 'center' },
                        { Header: 'BrithDate', accessor: 'BrithDate', align: 'center' },
                        { Header: 'CV', accessor: 'CV', align: 'center' },
                        { Header: "Equivalents and Discounts", accessor: "EquivalentsAndDiscounts", align: "center" },
                        { Header: 'Actions', accessor: 'actions', align: 'center' },
                ],
                rows: rows,
        };
}
