import React, { useEffect, useState } from 'react'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import { Card, Grid } from '@mui/material'
import MDBox from '../../../../../../items/MDBox/MDBox'
import MDTypography from '../../../../../../items/MDTypography'
import EmptyCard from '../../../../../../components/handleState/empty_card'
import ErrorCard from '../../../../../../components/handleState/error_card'
import DataTable from '../../../../../../components/Tables'
import ReEmployementDialog from '../../../../../../components/Dialog/re_employement_dialog'
import { getEmployeesArchiveService } from '../../../../../branch/feature/employees_archive/services/get_employees_archive_service'
import { useDispatch, useSelector } from 'react-redux'
import employeesManagerArchiveTableData from '../components/manager_employees_archive_tablle'
import LoaderCard from '../../../../../../components/handleState/loader_card'

const BranchManagerArchive = () => {
        const dispatch = useDispatch();
        const [isReEmployementDialog, setIsReEmployementDialog] = useState(false);
        const [managerID, setManagerID] = useState('');

        useEffect(() => {
                dispatch(getEmployeesArchiveService());
        }, [dispatch]);

        const { data: archiveData, loading: archiveLoading } = useSelector(state => state.getEmployeesArchiveService);

        const handleReEmployement = (managerID) => {
                setIsReEmployementDialog(true);
                setManagerID(managerID);
        }

        const managerDissimalEmployeeTable = archiveData ? employeesManagerArchiveTableData(archiveData, '', '', handleReEmployement, true, '') : { columns: [], rows: [] };

        return (
                <DashboardLayout>
                        <Grid container spacing={6} pt={5}>
                                <Grid item xs={12}>
                                        <Card>
                                                <MDBox
                                                        mx={2}
                                                        mt={-3}
                                                        py={3}
                                                        px={2}
                                                        variant="gradient"
                                                        bgColor="info"
                                                        borderRadius="lg"
                                                        coloredShadow="info"
                                                >
                                                        <MDTypography variant="h6" color="white">
                                                                Branches Manager Dissimal
                                                        </MDTypography>
                                                </MDBox>
                                                <MDBox pt={2}>
                                                        {archiveLoading ? (
                                                                <LoaderCard />
                                                        ) : !archiveData || archiveData.length === 0 ? (
                                                                <EmptyCard />
                                                        ) : (
                                                                <DataTable
                                                                        table={{ columns: managerDissimalEmployeeTable.columns, rows: managerDissimalEmployeeTable.rows }}
                                                                        isSorted={false}
                                                                        entriesPerPage={false}
                                                                        showTotalEntries={false}
                                                                        noEndBorder
                                                                />
                                                        )}
                                                </MDBox>
                                        </Card>
                                </Grid>
                        </Grid>

                        <ReEmployementDialog
                                isDialogOpen={isReEmployementDialog}
                                DialogClose={() => setIsReEmployementDialog(false)}
                                isManager={true}
                                headTitle={"Re Employenemt For Dismissal of Branch Manager "}
                                employeeID={managerID}
                                onClick={handleReEmployement}
                                handleReEmployment={handleReEmployement}
                        />

                </DashboardLayout>
        )
}

export default BranchManagerArchive
