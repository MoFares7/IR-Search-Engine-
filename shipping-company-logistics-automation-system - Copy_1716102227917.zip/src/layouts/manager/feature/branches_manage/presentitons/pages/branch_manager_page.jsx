import React, { useEffect, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import employeesTableData from '../components/manager_emplyess_table';
import DataTable from '../../../../../../components/Tables';
import { Card, Grid, Snackbar } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MDTypography from '../../../../../../items/MDTypography';
import { useSelector, useDispatch } from 'react-redux';
import { getBranchesManagers } from '../../services/get_branch_manager';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import MainDialog from '../../../../../../components/Dialog/main_dialog';
import { deleteBranchManager } from '../../services/delete_branch_manager';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import { ArchiveOutlined, ManageAccountsRounded } from '@mui/icons-material';
import { getEmployeesArchiveService } from '../../../../../branch/feature/employees_archive/services/get_employees_archive_service';
import { useNavigate } from 'react-router-dom';
import LoaderCard from '../../../../../../components/handleState/loader_card';

const BranchManagerPage = () => {
        const dispatch = useDispatch();
        const navigator = useNavigate();
        const [isDeleteManagerDialog, setIsDeleteManagerDialog] = useState(false);
        const [managerID, setManagerID] = useState('');
        const [errorSnackbarOpen, setErrorSnackbarOpen] = useState(false);
        const [errorMessage, setErrorMessage] = useState('');
        const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
        const [percentType, setPercentType] = useState('');
        const [isDialogAddEquivalentDiscountOpen, setIsDialogAddEquivalentDiscountOpen] = useState(false);

        useEffect(() => {
                dispatch(getBranchesManagers());
        }, [dispatch]);

        const { loading: loading, data: data } = useSelector(state => state.getBranchesManagers);

        const handleCreateManagerAccount = () => {
                window.location.href = '/create-new-branch-manager'
        };

        const handleEditBranchManager = (isUpdateInfoManager, managerID, managerInfo) => {
                isUpdateInfoManager = true;
                const queryParams = new URLSearchParams({
                        isUpdateInfoManager: isUpdateInfoManager,
                        managerID: managerID,
                        ...managerInfo
                });

                window.location.href = `/create-new-branch-manager?${queryParams.toString()}`;
        }

        const handleDeleteBranchManager = (managerID) => {
                setIsDeleteManagerDialog(true);
                setManagerID(managerID);
        }

        const handleDeleteConfirmation = async () => {
                try {
                        const response = await dispatch(deleteBranchManager({ managerId: managerID }));
                        console.log("fares: " + response.payload.status);
                        if (response.payload.status === "success") {
                                setIsDeleteManagerDialog(false);
                                dispatch(getBranchesManagers());
                                dispatch(getEmployeesArchiveService());
                                setErrorMessage('The Branch Manager is Dissimal');
                                setErrorSnackbarOpen(true);
                        } else {
                                setIsDeleteManagerDialog(false);
                                setErrorMessage('An error occurred dissmial manager');
                                setErrorSnackbarOpen(true);
                        }
                } catch (error) {
                        console.error("Error:", error);
                        setIsDeleteManagerDialog(false);
                        setErrorMessage('An error occurred dissmial manager');
                        setErrorSnackbarOpen(true);
                }
        };

        const handleAddEquivalentDiscount = (employeeID, percentType) => {
                console.log("percentType: " + percentType)
                setSelectedEmployeeId(employeeID);
                setPercentType(percentType);
                setIsDialogAddEquivalentDiscountOpen(true);
        };

        const handleDisplayManagerArchive = () => {
                navigator('/branch-Manage-Archive')
        }

        const managerEmployeeTable = data ? employeesTableData(data, handleEditBranchManager, handleDeleteBranchManager, handleAddEquivalentDiscount) : { columns: [], rows: [] };

        return (
                <DashboardLayout>
                        <DashboardNavbar
                                firstOption={
                                        <MenuOptionItem icon={<ManageAccountsRounded />} title="Create New Branch Manager" onClick={handleCreateManagerAccount} />
                                }
                                secondOption={
                                        <MenuOptionItem icon={<ArchiveOutlined />} title="Display Manager Archive" onClick={handleDisplayManagerArchive} />
                                }
                        />

                        {loading ? (
                                <LoaderCard />
                        ) : data.length === 0 ? (
                                <EmptyCard />
                        ) : (
                                <Grid container spacing={6} pt={5}>
                                        <Grid item xs={12}>
                                                <Card>
                                                        <MDBox
                                                                mx={2}
                                                                mt={-3}
                                                                py={3}
                                                                px={2}
                                                                variant="gradient"
                                                                bgColor="info"
                                                                borderRadius="lg"
                                                                coloredShadow="info"
                                                        >
                                                                <MDTypography variant="h6" color="white">
                                                                        Branches Manager
                                                                </MDTypography>
                                                        </MDBox>
                                                        <MDBox pt={2}>
                                                                {data.length === 0 ? (
                                                                        <EmptyCard />
                                                                ) : (
                                                                        <DataTable
                                                                                table={{ columns: managerEmployeeTable.columns, rows: managerEmployeeTable.rows }}
                                                                                isSorted={false}
                                                                                entriesPerPage={false}
                                                                                showTotalEntries={false}
                                                                                noEndBorder
                                                                        />
                                                                )}
                                                        </MDBox>
                                                </Card>
                                        </Grid>
                                </Grid>
                        )}

                        < MainDialog
                                isDialogOpen={isDeleteManagerDialog}
                                DialogClose={() => setIsDeleteManagerDialog(false)}
                                headTitle={"Dismissal of Branch Manager "}
                                subTitle={"Are You Sure From Dismissal Of Branch Manager ?"}
                                confirmEvent={handleDeleteConfirmation}
                        />

                        <Snackbar
                                open={errorSnackbarOpen}
                                autoHideDuration={4000}
                                onClose={() => { setErrorSnackbarOpen(false); }}
                                message={errorMessage}
                                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                        />

                </DashboardLayout >
        );
};

export default BranchManagerPage;
