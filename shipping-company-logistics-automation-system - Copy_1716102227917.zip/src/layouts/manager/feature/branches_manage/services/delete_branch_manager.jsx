import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const deleteBranchManager = createAsyncThunk(
        'branch/changeStatus',
        async ({ managerId }, { rejectWithValue }) => {
                try {
                        const response = await api.get(`employee/dismissal/${managerId}`);
                        console.log("deleteBranchManager success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const deleteBranchManagerSlice = createSlice({
        name: 'deleteBranchManager',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(deleteBranchManager.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(deleteBranchManager.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.status = action.payload.status;
                        })
                        .addCase(deleteBranchManager.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default deleteBranchManagerSlice.reducer;
