import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const getBranchesManagers = createAsyncThunk(
        'branches/getBranchesManagers',
        async () => {
                const response = await api.get(`user`);
                console.log("response managers branches: " + response.data);
                return response.data;
        }
);

const getBranchesManagersSlice = createSlice({
        name: 'getBranchesManagers',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getBranchesManagers.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getBranchesManagers.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(getBranchesManagers.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getBranchesManagersSlice.reducer;
