import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const createNewBranchManager = createAsyncThunk(
        'branch/store',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`user/store`, payload);
                        console.log("createNewBranchManager success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);


const createBrnchSlice = createSlice({
        name: 'createNewBranchManager',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(createNewBranchManager.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(createNewBranchManager.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(createNewBranchManager.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default createBrnchSlice.reducer;
