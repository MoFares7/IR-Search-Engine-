import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import MDButton from '../../../../../../items/MDButton';

export default function payrollTable(data, handleEditSalary) {


        const handleEditSalaryInfo = (isUpdateInfo,  salaryInfo) => {
                handleEditSalary(isUpdateInfo, salaryInfo);
                
        }
        const rows = data.map(salary => ({
                SalaryName: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {salary.id}
                        </MDTypography>
                ),
                Beneficiaries: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {salary.type}
                        </MDTypography>
                ),
                MaxRang: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {salary.max}
                        </MDTypography>
                ),
                MinRange: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {salary.min}
                        </MDTypography>
                ),
                actions: (
                        <MDBox sx={{ display: 'flex' }}>
                                <MDButton
                                        onClick={() => handleEditSalaryInfo(true, salary)}
                                        sx={{ color: colors.success.main }}>
                                        Edit
                                </MDButton>
                        </MDBox>
                ),
        }));

        return {

                columns: [
                        { Header: "Salary Name", accessor: "SalaryName", width: "35%", align: "left" },
                        { Header: "Beneficiaries", accessor: "Beneficiaries", align: "left" },
                        { Header: "Max Rang", accessor: "MaxRang", align: "left" },
                        { Header: "Min Range", accessor: "MinRange", align: "left" },
                        { Header: "Actions", accessor: "actions", align: "center" },
                ],
                rows: rows,
        };
}
