import React, { useEffect, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import MDBox from '../../../../../../items/MDBox/MDBox';
import colors from '../../../../../../assets/theme/base/colors';
import DataTable from '../../../../../../components/Tables';
import { useDispatch, useSelector } from 'react-redux';
import payrollTable from '../components/payroll_table';
import MDTypography from '../../../../../../items/MDTypography';
import { Card, Grid, IconButton } from '@mui/material';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import AddPayrollSection from '../components/add_payroll_section';
import { getSalaryService } from '../../services/get_salary_service';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import ErrorCard from '../../../../../../components/handleState/error_card';
import EmptyCard from '../../../../../../components/handleState/empty_card';

const PayrollRangManagement = () => {
        const dispatch = useDispatch();
        const [isAddPayrollDialogOpen, setIsAddPayrollDialogOpen] = useState(false);

        const { data, loading, error } = useSelector(state => state.getSalaryService);

        useEffect(() => {
                dispatch(getSalaryService());
        }, [dispatch]);

        const [salaryID, setSalaryID] = useState('');
        const [typeSalary, setTypeSalary] = useState('');
        const [minSalary, setMinSalary] = useState('');
        const [maxSalary, setMaxSalary] = useState('');

        const handleCloseDialog = () => {
                setIsAddPayrollDialogOpen(false);
                setSalaryID('');
                setTypeSalary('');
                setMaxSalary('');
                setMinSalary('')
        };
        const handleEditSalary = (isUpdateInfoSalary, salaryInfo) => {
                isUpdateInfoSalary = true;
                setIsAddPayrollDialogOpen(true);
                setSalaryID(salaryInfo.id);
                setTypeSalary(salaryInfo.type);
                setMaxSalary(salaryInfo.max);
                setMinSalary(salaryInfo.min);
        };


        const { columns, rows } = payrollTable(data, handleEditSalary);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <Grid container spacing={6} pt={5}>
                                <Grid item xs={12}>
                                        <Card>
                                                <MDBox
                                                        display="flex"
                                                        justifyContent="space-between"
                                                        mx={2}
                                                        mt={-3}
                                                        py={3}
                                                        px={2}
                                                        variant="gradient"
                                                        bgColor="info"
                                                        borderRadius="lg"
                                                        coloredShadow="info"
                                                >
                                                        <MDTypography variant="h6" color="white">
                                                                Salary Management
                                                        </MDTypography>

                                                </MDBox>
                                                <MDBox pt={2}>
                                                        {loading ?
                                                                (
                                                                        <LoaderCard />
                                                                )
                                                                : error ?
                                                                        (
                                                                                <ErrorCard />
                                                                        ) : data.length === 0 ?

                                                                                (
                                                                                        <EmptyCard />
                                                                                )
                                                                                : (
                                                                                        <DataTable
                                                                                                table={{ columns, rows }}
                                                                                                isSorted={false}
                                                                                                entriesPerPage={false}
                                                                                                showTotalEntries={false}
                                                                                                noEndBorder
                                                                                        />
                                                                                )}
                                                </MDBox>
                                        </Card>
                                </Grid>
                        </Grid>
                        <AddPayrollSection
                                isDialogOpen={isAddPayrollDialogOpen}
                                onCloseDialog={handleCloseDialog}
                                salaryID={salaryID} 
                                initialtype={typeSalary}
                                initialMaxSalary={maxSalary}
                                initialMinSalary={minSalary}
                        />




                </DashboardLayout>
        );
};

export default PayrollRangManagement;
