import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const getSalaryService = createAsyncThunk(
        'params/index',
        async () => {
                try {
                        const response = await api.get(`params/index`);
                        return response.data.data;
                } catch (error) {
                        throw Error(error.response.data.message);
                }
        }
);

const getSalarySlice = createSlice({
        name: 'getSalaryService',
        initialState: {
                data: [],
                error: null,
                loading: false,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getSalaryService.pending, (state) => {
                                state.loading = true;
                                state.error = null; 
                        })
                        .addCase(getSalaryService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.data = action.payload;
                        })
                        .addCase(getSalaryService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getSalarySlice.reducer;