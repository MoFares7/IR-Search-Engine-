import React from 'react'
import MDBox from '../../../../../../items/MDBox/MDBox'
import { Box, CircularProgress, IconButton, TextField } from '@mui/material'
import colors from '../../../../../../assets/theme/base/colors'
import { SendRounded } from '@mui/icons-material'

const AddQuestionCard = ({
        loadingData, valueQuestion,
        valueAnswer, onChangeQuestion,
        onChangeAnswer, handleCreateQuestion,
        validationErrorsQuestion, validationErrorsAnswer }) => {
        return (
                <Box sx={{
                        backgroundColor: colors.gradients.info.state,
                        width: '60%',
                        borderRadius: 2,
                        p: 2,
                        position: 'fixed',
                        bottom: 10,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        textAlign: 'center',
                }} >

                        <MDBox sx={{ width: '90%', }}>

                                <TextField label="Enter Question" variant="standard" sx={{ width: '80%', pb: 1 }}
                                        onChange={onChangeQuestion}
                                        value={valueQuestion}
                                        error={validationErrorsQuestion}
                                        helperText={validationErrorsQuestion}
                                        inputProps={{
                                                style: { color: colors.white.main }
                                        }}
                                        InputLabelProps={{
                                                style: { color: colors.white.main }
                                        }}
                                />

                                <MDBox sx={{ mt: 1 }} />
                                <TextField label="Enter Answer" variant="standard" sx={{ width: '80%', pb: 1 }}
                                        onChange={onChangeAnswer}
                                        value={valueAnswer}
                                        error={validationErrorsAnswer}
                                        helperText={validationErrorsAnswer}
                                        inputProps={{
                                                style: { color: colors.white.main }
                                        }}
                                        InputLabelProps={{
                                                style: { color: colors.white.main }
                                        }}
                                />
                        </MDBox>

                        <IconButton sx={{ color: colors.white.main }}
                                onClick={handleCreateQuestion}
                        >
                                {loadingData ?
                                        <CircularProgress sx={{ color: colors.white.main }} />
                                        :
                                        <SendRounded />
                                }
                        </IconButton>
                </Box>
        )
}

export default AddQuestionCard
