import React from 'react'
import MDBox from '../../../../../../items/MDBox/MDBox'
import MDTypography from '../../../../../../items/MDTypography'
import { Divider, IconButton, Menu } from '@mui/material'
import colors from '../../../../../../assets/theme/base/colors'
import typography from '../../../../../../assets/theme-dark/base/typography'
import { useState } from 'react'
import MenuOptionItem from '../../../../../../components/Items/NotificationItem'
import { Edit, DeleteOutlineRounded, EditAttributesRounded, MoreVertRounded, EditOutlined } from '@mui/icons-material';
import './style/card_style.css';
import { useDispatch, useSelector } from 'react-redux'
import { deleteQuestion } from '../../services/delete_question_service'
import { getAnswers } from '../../services/get_answers'

const QuestionCard = ({ questionID, questionTitle, answerTitle }) => {
        const dispatch = useDispatch();
        const [openMenu, setOpenMenu] = useState(null);

        const deleteLoading = useSelector(state => state.deleteQuestion.loading);

        const handleOpenMenu = (event) => {
                setOpenMenu(event.currentTarget);
        };

        const handleCloseMenu = () => {
                setOpenMenu(null);
        };

        const handleDeleteQuestion = async () => {
                console.log("questionID: " + questionID);
                if (questionID) {
                        dispatch(deleteQuestion(questionID))
                                .then((action) => {
                                        const { status, message } = action.payload;
                                        if (status === 'success') {
                                                dispatch(getAnswers());
                                        } else {
                                                console.log("Deletion failed. Status: ", status);
                                        }
                                })
                                .catch((error) => {
                                        console.error("Error deleting question: ", error);
                                        // Handle error
                                });
                } else {
                        console.error("QuestionID is undefined or null.");
                }
        }


        const renderMenu = (
                <Menu
                        anchorEl={openMenu}
                        anchorReference="anchorEl"
                        anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'left',
                        }}
                        open={Boolean(openMenu)}
                        onClose={handleCloseMenu}
                        sx={{ mt: 1 }}
                >
                        <MenuOptionItem icon={<EditOutlined />} title="Edit On Question" onClick={() => { }} />
                        <MenuOptionItem icon={<DeleteOutlineRounded />} title={deleteLoading ? "Deleteing..." : "Delete Question"} onClick={handleDeleteQuestion} />
                </Menu>
        );
        return (
                <div class="card">
                        <div class="card2">
                                {/* <MDBox sx={{
                                        // alignItems: 'center', p: 1, m: 2, backgroundColor: colors.gradients.info.state, borderRadius: 2, textAlign: 'center'
                                }}> */}
                                <MDBox textAlign="End">
                                        <IconButton
                                                size="small"
                                                disableRipple
                                                color="black"
                                                aria-controls="notification-menu"
                                                aria-haspopup="true"
                                                variant="contained"
                                                onClick={handleOpenMenu}
                                        >
                                                <MoreVertRounded />
                                        </IconButton>
                                </MDBox>
                                {renderMenu}
                                <MDBox sx={{ mx: 1 }}>
                                        <MDBox sx={{ backgroundColor: colors.gradients.light.main, borderRadius: 1 }}>

                                                <MDTypography typography={typography.body2} sx={{ textAlign: 'start', pl: 1, color: colors.black.main }} >
                                                        The Question:
                                                </MDTypography>
                                        </MDBox>
                                        <MDTypography typography={typography.body2} sx={{ pl: 1, color: colors.grey[800] }} >
                                                {questionTitle}
                                        </MDTypography>
                                </MDBox>
                                {/* <Divider sx={{ backgroundColor: colors.white.main, my: 1 }} /> */}

                                <MDBox sx={{ m: 1 }}>
                                        <MDBox sx={{ backgroundColor: colors.gradients.light.main, borderRadius: 1 }}>
                                                <MDTypography typography={typography.body2} sx={{ textAlign: 'start', pl: 1, color: colors.black.main }} >
                                                        The Answer:
                                                </MDTypography>
                                        </MDBox>
                                        <MDTypography typography={typography.body2} sx={{ pl: 1, color: colors.grey[800] }} >
                                                {answerTitle}
                                        </MDTypography>
                                </MDBox>
                                {/* </MDBox > */}
                        </div>
                </div>

        )
}

export default QuestionCard
