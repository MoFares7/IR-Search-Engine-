import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import MDBox from '../../../../../../items/MDBox/MDBox';
import Lottie from 'lottie-react';
import aq from '../../../../assets/lottie/q&a.json';
import MDTypography from '../../../../../../items/MDTypography';
import typography from './../../../../../../assets/theme-dark/base/typography';
import { AddBoxRounded } from '@mui/icons-material';
import QuestionCard from '../components/question_card';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import AddQuestionCard from '../components/add_question_card';
import { getQuestions } from '../../services/get_question';
import { getAnswers } from '../../services/get_answers';
import colors from '../../../../../../assets/theme/base/colors';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import { Box, Divider } from '@mui/material';
import HeaderLayout from '../../../../../../components/LayoutContainers/HeaderPageLayout';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import ErrorCard from './../../../../../../components/handleState/error_card';
import { createNewQuestionService } from '../../services/create_question_service';

const ChatBotConfigPage = () => {
  const dispatch = useDispatch();
  const [addQuestion, setAddQuestion] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [questionError, setQuestionError] = useState('');
  const [answerError, setAnswerError] = useState('');

  useEffect(() => {
    dispatch(getAnswers());
  }, [dispatch]);

  const loadingCreateQuestion = useSelector(state => state.createNewQuestionService.loading);
  const answers = useSelector(state => state.getAnswers.data);
  const loader = useSelector(state => state.getAnswers.loading);
  const error = useSelector(state => state.getAnswers.error);

  const handleCreateNewQuestion = async () => {
    setQuestionError('');
    setAnswerError('');


    if (question.trim() === '') {
      setQuestionError('The question field is required');
      return;
    }
    if (answer.trim() === '') {
      setAnswerError('The answer field is required');
      return;
    }
    if (
      question !== '' ||
      answer !== '' ||
      answer !== 'The Field is required' ||
      question !== 'The Field is required'
    ) {
      const response = await dispatch(createNewQuestionService({
        payload: {
          "questionDescription": question,
          "answerText": answer
        }
      }));
      if (response.payload.status === 'success') {
        dispatch(getAnswers());
        setAddQuestion(false);
        setQuestion('');
        setAnswer('');
      }
      console.log("abbas")
      console.log("question: " + question)
    }
  };

  return (
    <DashboardLayout>
      <DashboardNavbar
        firstOption={
          <MenuOptionItem icon={<AddBoxRounded />} title="Add New Question" onClick={() => setAddQuestion(true)} />
        }
      />

      <HeaderLayout
        title={'Chatbot Management'}
        subTitle={"Here all Question and Centrlize Management"}
        placeholder={"Status"}
        isFilter={false}
        options={['Active', 'InActive']}
      />
      {loader ? (
        <LoaderCard />
      ) : (
        <MDBox
          sx={{
            display: {
              xs: 'block',
              md: 'grid',
              xl: 'grid'
            },
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '20px',
            pt: 3,
            justifyContent: 'center'
          }}
        >
          {answers.length === 0 ? (
            <EmptyCard message={"Not Founded Any Questions"} />
          ) : error ? (
            <ErrorCard />
          ) : (
            <>
              {answers.map(answer => (
                <React.Fragment key={answer.id}>
                  <Box py={1}>
                    <QuestionCard
                      questionID={answer.id}
                      questionTitle={answer.question}
                      answerTitle={answer.answer} />
                  </Box>
                </React.Fragment>
              ))}
            </>
          )}
        </MDBox>
      )}

      <Box sx={{ display: 'flex', justifyContent: 'center' }}>
        {addQuestion && (
          <AddQuestionCard
            valueQuestion={question}
            valueAnswer={answer}
            onChangeQuestion={(e) => setQuestion(e.target.value)}
            onChangeAnswer={(e) => setAnswer(e.target.value)}
            loadingData={loadingCreateQuestion}
            handleCreateQuestion={handleCreateNewQuestion}
          />
        )}
      </Box>
    </DashboardLayout>
  );
};

export default ChatBotConfigPage;
