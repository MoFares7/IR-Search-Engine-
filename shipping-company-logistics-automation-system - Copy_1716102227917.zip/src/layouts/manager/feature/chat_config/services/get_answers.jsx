import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const getAnswers = createAsyncThunk(
        'answers/index',
        async () => {
                try {
                        const response = await axios.get(`https://chat-bot-servies.onrender.com/api/answers/index`);
                        return response.data;
                } catch (error) {
                        throw Error(error);
                }
        }
);

const getSalarySlice = createSlice({
        name: 'getAnswers',
        initialState: {
                data: [],
                error: null,
                loading: false,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getAnswers.pending, (state) => {
                                state.loading = true;
                                state.error = null;
                        })
                        .addCase(getAnswers.fulfilled, (state, action) => {
                                state.loading = false;
                                state.data = action.payload;
                        })
                        .addCase(getAnswers.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getSalarySlice.reducer;