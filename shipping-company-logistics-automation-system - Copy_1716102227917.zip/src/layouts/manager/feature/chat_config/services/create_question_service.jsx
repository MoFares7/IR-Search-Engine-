import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'
import axios from 'axios';

export const createNewQuestionService = createAsyncThunk(
        'category/store',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await axios.post(`https://chat-bot-servies.onrender.com/api/answers/store`, payload);
                        console.log("createNewQuestionService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const createQuestionSlice = createSlice({
        name: 'createNewQuestionService',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(createNewQuestionService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(createNewQuestionService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(createNewQuestionService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default createQuestionSlice.reducer;

