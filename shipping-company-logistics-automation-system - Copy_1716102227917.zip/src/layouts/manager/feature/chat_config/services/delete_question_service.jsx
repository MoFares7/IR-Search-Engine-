import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const deleteQuestion = createAsyncThunk(
        'question/delete',
        async (questionID, { rejectWithValue }) => {
                try {
                        const response = await axios.delete(`https://chat-bot-servies.onrender.com/api/question/destroy?id=${questionID}`);
                        console.log("deleteQuestion success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const deleteQuestionSlice = createSlice({
        name: 'deleteQuestion',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(deleteQuestion.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(deleteQuestion.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.status = action.payload.status;
                        })
                        .addCase(deleteQuestion.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default deleteQuestionSlice.reducer;
