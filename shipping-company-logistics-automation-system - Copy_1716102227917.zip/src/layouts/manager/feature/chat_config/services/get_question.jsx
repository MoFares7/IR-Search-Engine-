import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const getQuestions = createAsyncThunk(
        'question/index',
        async () => {
                try {
                        const response = await axios.get(`http://localhost:3001/api/question/index`);
                        return response.data;
                } catch (error) {
                        throw Error(error);
                }
        }
);

const getSalarySlice = createSlice({
        name: 'getQuestions',
        initialState: {
                data: [],
                error: null,
                loading: false,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getQuestions.pending, (state) => {
                                state.loading = true;
                                state.error = null;
                        })
                        .addCase(getQuestions.fulfilled, (state, action) => {
                                state.loading = false;
                                state.data = action.payload;
                        })
                        .addCase(getQuestions.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getSalarySlice.reducer;