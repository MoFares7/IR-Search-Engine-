import React from 'react';
import colors from '../../../../../../assets/theme/base/colors';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MDAvatar from '../../../../../../items/MDAvatar';
import MDTypography from '../../../../../../items/MDTypography';

const HeaderChat = ({ isSelected, employeeName, employeeImage, employeeEmail, onClick }) => {
        const Employee = ({ image, name }) => (
                <MDBox
                        display={{
                                xs: "block",
                                md: "flex",
                                xl: "flex"
                        }}
                        alignItems="center"
                        lineHeight={1}
                >
                        <MDAvatar src={image} name={name} size="md" />
                        <MDBox ml={2} lineHeight={1}>
                                <MDTypography
                                        display="block"
                                        variant="button"
                                        fontWeight="medium"
                                        sx={{
                                                color: !isSelected ? colors.dark.main : colors.white.main,
                                        }}
                                >
                                        {name}
                                </MDTypography>
                        </MDBox>
                </MDBox>
        );

        return (
                <MDBox
                        onClick={onClick}
                        sx={{
                                position: 'relative',
                                backgroundColor: isSelected ? colors.info.main : colors.grey[300],
                                p: 0.5,
                                pl: 1.5,
                                width: {
                                        xs: 100,
                                        sm: 250,
                                        md: 320,
                                        xl: 320
                                },
                                height: 'auto',
                                alignItems: 'center',
                        }}
                >
                        <Employee image={employeeImage} name={employeeName} email={employeeEmail} />
                </MDBox>
        );
};

export default HeaderChat;
