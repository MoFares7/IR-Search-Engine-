import React, { useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import colors from '../../../../../../assets/theme/base/colors';
import { TextField, Divider } from '@mui/material';
import { SendRounded } from '@mui/icons-material';
import { Card } from '@mui/material';
import HeaderChat from '../components/header_chat';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MDTypography from '../../../../../../items/MDTypography';
import persone from '../../../../../../assets/images/team-4.jpg';

const SupportPage = () => {
        const [message, setMessage] = useState('');
        const [messages, setMessages] = useState([]);
        const [selectedChat, setSelectedChat] = useState(null);

        const handleSendMessage = () => {
                if (message.trim() !== '') {
                        setMessages([...messages, message]);
                        setMessage('');
                }
        };

        const handleHeaderChatClick = (index) => {
                setSelectedChat(index);
        };

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <MDBox sx={{ display: 'flex', height: '100vh' }}>
                                <MDBox sx={{ width: 250, flexShrink: 0, height: '100%', overflowY: 'auto' }}>
                                        <HeaderChat
                                                isSelected={selectedChat === 0}
                                                employeeImage={persone}
                                                employeeName="Fares Dabbas"
                                                employeeEmail="fares.@creative.com"
                                                onClick={() => handleHeaderChatClick(0)}
                                        />
                                        <HeaderChat
                                                isSelected={selectedChat === 1}
                                                employeeImage={persone}
                                                employeeName="Fares Dabbas"
                                                employeeEmail="fares.@creative.com"
                                                onClick={() => handleHeaderChatClick(1)}
                                        />
                                </MDBox>
                                <Divider orientation="vertical" sx={{ backgroundColor: colors.dark.main }} />

                                {/* this is Chat body */}
                                <MDBox sx={{  height: '100%', overflowY: 'auto' }}>
                                        {selectedChat !== null && (
                                                <MDBox sx={{ marginBottom: 23 }}>
                                                        {messages.map((msg, index) => (
                                                                <Card key={index} sx={{
                                                                        width: {
                                                                                xs: 250,
                                                                                sm: 320,
                                                                                md: 350,
                                                                                lg: 350,
                                                                                xl: 350
                                                                        },
                                                                        height: 'auto',
                                                                        marginBottom: 1,
                                                                        mt: 1,
                                                                        backgroundColor: colors.success.main,
                                                                        color: colors.white.main,
                                                                        borderRadius: '10px 10px 10px 0px',
                                                                }}>
                                                                        <MDBox sx={{ justifyContent: 'center', p: 1 }}>
                                                                                <MDTypography sx={{ color: colors.white.main }}>{msg}</MDTypography>
                                                                        </MDBox>
                                                                        <MDTypography sx={{ fontSize: 12, color: colors.white.main }}>14/3/2024: 11:49</MDTypography>
                                                                </Card>
                                                        ))}
                                                        <MDBox sx={{
                                                                position: 'fixed',
                                                                bottom: 0,
                                                                width: {
                                                                        xs: 250,
                                                                        sm: 320,
                                                                        md: 500,
                                                                        lg: 500,
                                                                        xl: 900
                                                                },
                                                        }}>
                                                                <TextField
                                                                        placeholder='send message'
                                                                        fullWidth
                                                                        value={message}
                                                                        onChange={(e) => setMessage(e.target.value)}
                                                                        sx={{
                                                                                p: 2,
                                                                                display: 'flex',
                                                                                alignItems: 'center',
                                                                        }}
                                                                        InputProps={{
                                                                                style: {
                                                                                        color: colors.white.main,
                                                                                        borderBottom: `1px solid ${colors.dark.main}`,
                                                                                        borderTop: `1px solid ${colors.dark.main}`,
                                                                                        borderLeft: `1px solid ${colors.dark.main}`,
                                                                                        borderRight: `1px solid ${colors.dark.main}`,
                                                                                        backgroundColor: 'transparent',
                                                                                },
                                                                                endAdornment: (
                                                                                        <SendRounded
                                                                                                style={{
                                                                                                        color: colors.dark.main,
                                                                                                        cursor: 'pointer',
                                                                                                }}
                                                                                                onClick={handleSendMessage}
                                                                                        />
                                                                                ),
                                                                        }}
                                                                />
                                                        </MDBox>
                                                </MDBox>
                                        )}
                                </MDBox>
                        </MDBox>
                </DashboardLayout>
        );
};

export default SupportPage;
