import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const createNewPricingOperation = createAsyncThunk(
        'category/store',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`category/store`, payload);
                        console.log("createNewPricingOperation success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const createPricingOperation = createSlice({
        name: 'createNewPricingOperation',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(createNewPricingOperation.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(createNewPricingOperation.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(createNewPricingOperation.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default createPricingOperation.reducer;
