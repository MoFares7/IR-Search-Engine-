import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const deletePricingOperation = createAsyncThunk(
        'category/delete',
        async ({ operationId }, { rejectWithValue }) => {
                try {
                        const response = await api.delete(`category/delete/${operationId}`);
                        console.log("deletePricingOperation success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const deletePricingOperationSlice = createSlice({
        name: 'deletePricingOperation',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(deletePricingOperation.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(deletePricingOperation.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(deletePricingOperation.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default deletePricingOperationSlice.reducer;
