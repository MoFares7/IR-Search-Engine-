import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import MDButton from '../../../../../../items/MDButton';

export default function pricingTableData(data, handleEditPricing, handleDeletePricing) {

        const handleEditPricingInfo = (isUpdateInfoPricing, categortID, pricingInfo) => {
                handleEditPricing(isUpdateInfoPricing, categortID, pricingInfo);
        }

        const rows = data.map(price => ({
                GoodsName: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {price.name}
                        </MDTypography>
                ),
                TransportPrice: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {price.price}AED
                        </MDTypography>
                ),
                PercentProfit: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {price.percentProfit}
                        </MDTypography>
                ),
                TransportPriceFast: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {price.price_fast_order}
                        </MDTypography>
                ),
                PercentProfitFast: (
                        <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                {price.percentProfit_fast_order}
                        </MDTypography>
                ),
                actions: (
                        <MDBox sx={{ display: 'flex' }}>
                                <MDButton onClick={() => handleEditPricingInfo(true, price.id, price)} variant="caption" fontWeight="medium" sx={{ color: colors.success.main }}>
                                        Edit
                                </MDButton>
                                <MDBox sx={{ pl: 1 }} />
                                <MDButton
                                        onClick={() => handleDeletePricing(price.id)}
                                        variant="caption"
                                        fontWeight="medium" sx={{ color: colors.error.main }}>
                                        Delete
                                </MDButton>
                        </MDBox>
                ),
        }));

        return {

                columns: [
                        { Header: "Goods Name", accessor: "GoodsName", width: "10%", align: "center" },
                        { Header: "Transport Price Normal / KM", accessor: "TransportPrice", align: "center" },
                        { Header: "Percent Profit Normal", accessor: "PercentProfit", align: "center" },
                        { Header: "Transport Price Fast / KM", accessor: "TransportPriceFast", align: "center" },
                        { Header: "Percent Profit Fast", accessor: "PercentProfitFast", align: "center" },
                        { Header: "Actions", accessor: "actions", align: "center" },
                ],
                rows: rows,
        };
}
