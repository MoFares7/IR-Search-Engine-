import React, { useEffect, useState } from 'react';
import { Card, Grid, IconButton } from '@mui/material';
import { AddBoxRounded } from '@mui/icons-material';
import { useDispatch, useSelector } from 'react-redux';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MDTypography from '../../../../../../items/MDTypography';
import DataTable from '../../../../../../components/Tables';
import pricingTableData from '../components/pricing_table';
import { getPricingManagement } from '../../service/get_pricing_service';
import AddGoods from '../components/add_goods';
import ErrorCard from '../../../../../../components/handleState/error_card';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import MainDialog from '../../../../../../components/Dialog/main_dialog';
import { deletePricingOperation } from '../../service/delete_pricing_service';

const PricingManagementPage = () => {
        const dispatch = useDispatch();
        const { data, loading, error } = useSelector(state => state.getPricingManagement);

        useEffect(() => {
                dispatch(getPricingManagement());
        }, [dispatch]);

        const [isDialogAddGoodsOpen, setIsDialogAddGoodsOpen] = useState(false);
        const [isDialogDeleteGoodsOpen, setIsDialogDeleteGoodsOpen] = useState(false);
        const [isUpdateInfo, setIsUpdateInfo] = useState(false);
        const [goodsID, setGoodsID] = useState('');
        const [nameGoods, setNameGoods] = useState('');
        const [price, setPrice] = useState('');
        const [percentProfit, setPercentProfit] = useState('');
        const [priceFastOrder, setPriceFastOrder] = useState('');
        const [percentProfitFastOrder, setPercentProfitFastOrder] = useState('');

        const handleCloseDialog = () => {
                setIsDialogAddGoodsOpen(false);
                setIsDialogDeleteGoodsOpen(false);
                setGoodsID('');
                setNameGoods('');
                setPrice('');
                setPercentProfit('');
                setPriceFastOrder('');
                setPercentProfitFastOrder('');
                setIsUpdateInfo(false)
        };

        const handleEditPricing = (isUpdateInfoPricing, goodsID, pricingInfo) => {
                isUpdateInfoPricing = true;
                setIsDialogAddGoodsOpen(true);
                setGoodsID(goodsID);
                setNameGoods(pricingInfo.name);
                setPrice(pricingInfo.price);
                setPercentProfit(pricingInfo.percentProfit);
                setPriceFastOrder(pricingInfo.price_fast_order);
                setPercentProfitFastOrder(pricingInfo.percentProfit_fast_order)
                setIsUpdateInfo(true);
        };

        const handleDeletePricing = (goodsID) => {
                setIsDialogDeleteGoodsOpen(true);
                setGoodsID(goodsID);
        }

        const handleDeleteConfirmation = () => {
                dispatch(deletePricingOperation({ operationId: goodsID }))
                        .unwrap()
                        .then((response) => {
                                if (response.status === "success") {
                                        dispatch(getPricingManagement());
                                        setIsDialogDeleteGoodsOpen(false);
                                }
                        })
                        .catch((error) => {
                                console.error("Delete pricing operation failed:", error);
                        });
        };


        const { columns, rows } = pricingTableData(data, handleEditPricing, handleDeletePricing);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <Grid container spacing={6} pt={5}>
                                <Grid item xs={12}>
                                        <Card>
                                                <MDBox
                                                        display="flex"
                                                        justifyContent="space-between"
                                                        mx={2}
                                                        mt={-3}
                                                        py={3}
                                                        px={2}
                                                        variant="gradient"
                                                        bgColor="info"
                                                        borderRadius="lg"
                                                        coloredShadow="info"
                                                >
                                                        <MDTypography variant="h6" color="white">
                                                                Pricing Management
                                                        </MDTypography>

                                                        <IconButton onClick={() => { setIsDialogAddGoodsOpen(true); }}>
                                                                <AddBoxRounded color='white' />
                                                        </IconButton>
                                                </MDBox>
                                                <MDBox pt={2}>
                                                        {loading ?
                                                                (
                                                                        <LoaderCard />
                                                                )
                                                                : error ?
                                                                        (
                                                                                <ErrorCard />
                                                                        ) : data.length === 0 ?

                                                                                (
                                                                                        <EmptyCard />
                                                                                )
                                                                                : (
                                                                                        <DataTable
                                                                                                table={{ columns, rows }}
                                                                                                isSorted={false}
                                                                                                entriesPerPage={false}
                                                                                                showTotalEntries={false}
                                                                                                noEndBorder
                                                                                        />
                                                                                )}
                                                </MDBox>
                                        </Card>
                                </Grid>
                        </Grid>
                        <AddGoods
                                isDialogOpen={isDialogAddGoodsOpen}
                                onCloseDialog={handleCloseDialog}
                                initialName={nameGoods}
                                initialPrice={price}
                                initialPercentProfit={percentProfit}
                                initialPriceFastOrder={priceFastOrder}
                                initialPercentProfitFastOrder={percentProfitFastOrder}
                                isUpdateEnable={isUpdateInfo}
                                goodsID={goodsID}
                        />

                        <MainDialog
                                isDialogOpen={isDialogDeleteGoodsOpen}
                                DialogClose={() => setIsDialogDeleteGoodsOpen(false)}
                                headTitle={"Delete Category Goods"}
                                subTitle={"Are you sure to delete this goods ?"}
                                onClick={handleDeletePricing}
                                confirmEvent={handleDeleteConfirmation}
                        />

                </DashboardLayout>
        );
};

export default PricingManagementPage;
