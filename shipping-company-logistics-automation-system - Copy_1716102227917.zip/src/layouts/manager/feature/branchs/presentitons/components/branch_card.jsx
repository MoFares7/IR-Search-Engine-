import React, { useState } from 'react';
import { Box, IconButton, Menu, MenuItem } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MDTypography from '../../../../../../items/MDTypography';
import { DisabledByDefaultRounded, DoneOutlineRounded, DownloadOutlined, LocationOnOutlined, MoreVertRounded, Update } from '@mui/icons-material';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import colors from '../../../../../../assets/theme/base/colors';
import borders from '../../../../../../assets/theme/base/borders';
import typography from './../../../../../../assets/theme-dark/base/typography';
import { useDispatch } from 'react-redux';
import { downloadFilesBranchService } from '../../services/apis/download_file_branch_service';

const BranchCard = ({
        branchId,
        status,
        branchName,
        managerID,
        branchCity,
        branchPhoneNumber,
        branchMobile,
        branchAddress,
        branchDocument,
        branchEmail,
        branchLat,
        branchLng,
        managerName,
        branchCost,
        percent,
        isUpdateInfoBranch,
        isChangeStatusBranch
}) => {
        const dispatch = useDispatch();
        const [openMenu, setOpenMenu] = useState(null);

        const handleChangeStatusBranch = () => {
                isChangeStatusBranch();
        };

        const handleUpdateBranchInfo = () => {
                isUpdateInfoBranch();
        };

        const handleDisplayLocationBranch = () => {
                const staticMapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${branchLat},${branchLng}&zoom=15&size=400x400&markers=color:red%7Clabel:B%7C${branchLat},${branchLng}&key=YOUR_API_KEY`;
                window.open(staticMapUrl, '_blank');
        };

        const handleDownloadBranchDocument = () => {
                dispatch(downloadFilesBranchService({ branch_id: branchId }));
        };

        const renderMenu = (
                <Menu
                        anchorEl={openMenu}
                        anchorReference="anchorEl"
                        anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'left',
                        }}
                        open={Boolean(openMenu)}
                        onClose={() => {
                                setOpenMenu(null);
                        }}
                        sx={{ mt: 1 }}
                >
                        <MenuOptionItem icon={<Update />} title="Update Info Branch" onClick={handleUpdateBranchInfo} />
                        <MenuOptionItem icon={status === 'active' ? <DisabledByDefaultRounded /> : <DoneOutlineRounded />} title={status === 'active' ? "Disable Branch" : "Enable Branch"} onClick={handleChangeStatusBranch} />
                        <MenuOptionItem icon={<LocationOnOutlined />} title="Display Location" onClick={handleDisplayLocationBranch} />
                        <MenuOptionItem icon={<DownloadOutlined />} title="Download Branch Documents" onClick={() => handleDownloadBranchDocument(branchId)} />
                </Menu>
        );

        return (
                <MDBox
                        sx={{
                                transition: 'transform 0.4s ease',
                                '&:hover': {
                                        transform: 'scale(0.98)',
                                },
                                borderRadius: 2,
                                border: `1px solid ${colors.grey[300]}`,
                        }}
                >
                        <MDBox display="block" alignItems="center" color="black" borderRadius={borders.borderRadius.lg} bgColor={colors.white.main}>
                                <MDBox display="flex" justifyContent="space-between" color="black">
                                        <MDBox
                                                sx={{
                                                        backgroundColor: status != 'inActive' ? colors.gradients.success.main : colors.gradients.error.main,
                                                        width: '100px',
                                                        borderRadius: '8px 0 8px 0',
                                                }}
                                        >
                                                <MDTypography typography={typography.body2} p={1} textAlign="center" justifyContent="center" sx={{ color: colors.white.main }}>
                                                        {status}
                                                </MDTypography>
                                        </MDBox>
                                        <IconButton
                                                size="small"
                                                disableRipple
                                                color="inherit"
                                                aria-controls="notification-menu"
                                                aria-haspopup="true"
                                                variant="contained"
                                                onClick={(event) => {
                                                        setOpenMenu(event.currentTarget);
                                                }}
                                        >
                                                <MoreVertRounded sx={{ color: colors.white.main }} />
                                        </IconButton>
                                </MDBox>
                                {renderMenu}
                                <MDBox p={1} display="flex" justifyContent='space-between'>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>Branch Name</MDTypography>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>{branchName}</MDTypography>
                                </MDBox>
                                <MDBox p={1} display="flex" justifyContent='space-between'>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>Manager Name</MDTypography>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>{managerName}</MDTypography>
                                </MDBox>
                                <MDBox p={1} display="flex" pb={0.1} justifyContent='space-between'>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>Location</MDTypography>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>{branchCity}</MDTypography>
                                </MDBox>
                                <MDBox p={1} display="flex" pb={0.1} justifyContent='space-between'>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>Phone Number</MDTypography>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>{branchPhoneNumber}</MDTypography>
                                </MDBox>
                                <MDBox p={1} display="flex" pb={0.1} justifyContent='space-between'>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>Address</MDTypography>
                                        <MDTypography fontWeight="light" color="black" fontSize={'15px'} p={1}>{branchAddress}</MDTypography>
                                </MDBox>
                        </MDBox>
                </MDBox>
        );
}

export default BranchCard;