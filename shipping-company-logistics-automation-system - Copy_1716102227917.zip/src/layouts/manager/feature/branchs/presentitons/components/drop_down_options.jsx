import React from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import colors from '../../../../../../assets/theme/base/colors';

const DropdownSelectOption = ({ value, options, placeholder, label, onChange }) => {
        const handleChange = (event) => {
                onChange(event.target.value);
        };

        return (
                <div>
                        <FormControl variant="standard" sx={{
                                m: 1,
                                width: {
                                        xs: '250px',
                                        sm: '290px',
                                        md: '380px',
                                        xl: '490px'
                                },
                                // height: '20px'

                        }}>
                                <InputLabel id="demo-simple-select-standard-label">{label}</InputLabel>
                                <Select
                                        labelId="demo-simple-select-standard-label"
                                        id="demo-simple-select-standard"
                                        value={value}
                                        onChange={handleChange}
                                        label={label}
                                        sx={{ colors: colors.dark.main }}
                                        style={{ color: colors.dark.main }}
                                >
                                        <MenuItem value="">{placeholder}</MenuItem>
                                        {options.map((option) => (
                                                <MenuItem key={option} value={option} style={{ color: colors.dark.main }}>{option}</MenuItem>
                                        ))}
                                </Select>
                        </FormControl>
                </div>
        );
};

export default DropdownSelectOption;
