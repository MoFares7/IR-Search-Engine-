import React, { useRef, useState } from 'react';
import MDBox from '../../../../../../items/MDBox/MDBox';
import { CircularProgress } from '@mui/material';
import MDTypography from '../../../../../../items/MDTypography';
import DropdownTextField from '../components/drop_down_textFiled.jsx';
import TextFeildForm from '../../../../../../components/Items/Form_TextFeild/text_feild_form.jsx';
import colors from '../../../../../../assets/theme/base/colors.jsx';
import { createNewBranch } from '../../services/apis/create_branch_api.jsx';
import { useDispatch, useSelector } from 'react-redux';
import { fetchBranches } from '../../services/apis/get_branches_api.jsx';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout/index.jsx';
import { useEffect } from 'react';
import { getBranchesManagers } from '../../../branches_manage/services/get_branch_manager.jsx';
import MainButton from '../../../../../../components/Items/MainButton/main_button.jsx';
import { useLocation } from 'react-router-dom';
import { updateBranchInfo } from '../../services/apis/update_branch_service.jsx';
import MainBadgeItem from '../../../../../../components/Items/Badge/badge.jsx';

const AddNewBranchPage = () => {
        const location = useLocation();
        const [branchInfo, setBranchInfo] = useState({});
        const [isUpdateBranchInfo, setIsUpdateBranchInfo] = useState(false);

        useEffect(() => {
                const queryParams = new URLSearchParams(location.search);
                const branchInfo = Object.fromEntries(queryParams.entries());
                console.log("Branch Info:", branchInfo);
                setBranchInfo(branchInfo || '');
                setBranchID(branchInfo.branchId || '');
                setBranchName(branchInfo.branchName || '');
                setImage(branchInfo.branchImage || '')
                setCity(branchInfo.branchCity || '');
                setNumberPhone(branchInfo.branchPhoneNumber || '');
                setMobile(branchInfo.branchMobile || '');
                setEmail(branchInfo.branchEmail || '');
                setLat(branchInfo.branchLat || '');
                setLng(branchInfo.branchLng || '');
                setFileName(branchInfo.branchDocument || '');
                setDocument(branchInfo.branchDocument || '');
                setAddress(branchInfo.branchAddress || '');
                setManagerID(branchInfo.managerID || '');
                setManagerName(branchInfo.managerName || '');
                setPercent(branchInfo.percent || '')

                setIsUpdateBranchInfo(branchInfo.isUpdateBranchInfo === 'true');

        }, [location]);

        const dispatch = useDispatch();
        const [branchID, setBranchID] = useState('');
        const [avatarImage, setAvatarImage] = useState(null);
        const [branchName, setBranchName] = useState('');
        const [city, setCity] = useState('');
        const [mobile, setMobile] = useState('');
        const [lng, setLng] = useState('');
        const [lat, setLat] = useState('');
        const [numberPhone, setNumberPhone] = useState('');
        const [email, setEmail] = useState('');
        const [address, setAddress] = useState('');
        const [cost, setCost] = useState('');
        const [managerName, setManagerName] = useState('');
        const [managerID, setManagerID] = useState('');
        const [percent, setPercent] = useState('');
        const [document, setDocument] = useState('');
        const [fileName, setFileName] = useState('');
        const [image, setImage] = useState('');
        const fileInputRef = useRef(null);

        const loading = useSelector(state => state.createNewBranch.loading);
        const errorCraretBranch = useSelector(state => state.createNewBranch.error);
        const updateLoading = useSelector(state => state.updateBranchInfo.loading);
        const branchManagers = useSelector(state => state.getBranchesManagers.data);
        const branchManagersLoading = useSelector(state => state.getBranchesManagers.loading);

        const [validationErrors, setValidationErrors] = useState({
                branchName: '',
                city: '',
                mobile: '',
                numberPhone: '',
                email: '',
                address: '',
                lat: '',
                lng: '',
                cost: '',
                percent: '',
                managerID: '',
                document: ''
        });

        useEffect(() => {
                dispatch(getBranchesManagers());
        }, [dispatch]);

        const handleFileChange = (e) => {
                const file = e.target.files[0];
                if (file) {
                        console.log("File object:", file);
                        console.log("File type:", file.type);
                        setDocument(file);
                        setFileName(file.name);
                        setValidationErrors({ ...validationErrors, document: '' });
                }
        };


        const handleDocumentSelected = () => {
                if (fileInputRef.current) {
                        fileInputRef.current.click();
                }
        };

        const handleSelectImage = (event) => {
                const file = event.target.files[0];
                if (file) {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                                console.log("Selected file:", file.type);
                                setImage(e.target.result);
                                setAvatarImage(file);
                        };
                        reader.readAsDataURL(file);
                }
        };


        const handleCreateBranch = async () => {
                const errors = {};

                console.log("doc: " + document);

                if (branchName.trim() === '') {
                        errors.branchName = 'Branch name is required';
                }

                if (city.trim() === '') {
                        errors.city = 'City is required';
                }

                if (mobile.trim() === '' || mobile.length < 10 ) {
                        errors.mobile = 'Mobile Number is must to be greater than 10 number and is required';
                }

                if (numberPhone.trim() === '') {
                        errors.numberPhone = 'Number Phone is required';
                }

                if (address.trim() === '') {
                        errors.address = 'Address is required';
                }

                if (email.trim() === '') {
                        errors.email = 'Email is required';
                }

                if (lat.trim() === '') {
                        errors.lat = 'Latitude is required';
                }

                if (lng.trim() === '') {
                        errors.lng = 'Langtuning is required';
                }

                if (percent.trim() === '') {
                        errors.percent = 'Percent To Manager Branch is required';
                }

                if (managerID === '') {
                        errors.managerID = 'Manager is required';
                }

                if (!isUpdateBranchInfo) {
                        if (!document) {
                                errors.document = 'Document is required';
                        }
                        if (cost === '') {
                                errors.cost = 'Cost of construction is required';
                        }
                }

                setValidationErrors(errors);

                if (Object.keys(errors).length === 0) {
                        try {
                                let response;
                                const selectedManager = branchManagers.find(manager => manager.username === managerName);
                                const selectedManagerID = selectedManager ? selectedManager.id : '';

                                //todo when update I send file is must file or name
                                if (isUpdateBranchInfo) {
                                        response = await dispatch(updateBranchInfo({
                                                branch_id: branchID,
                                                payload: {
                                                        image: avatarImage,
                                                        name: branchName,
                                                        districts: city,
                                                        lng: lng,
                                                        lat: lat,
                                                        manager_id: managerID,
                                                        phone_number: numberPhone,
                                                        address: address,
                                                        Mobile: mobile,
                                                        email: email,
                                                        document: document === '' ? fileName : document,
                                                        percent: percent,
                                                        // cost: cost
                                                }
                                        }));
                                } else {
                                        response = await dispatch(createNewBranch({
                                                payload: {
                                                        image: avatarImage,
                                                        name: branchName,
                                                        districts: city,
                                                        lng: lng,
                                                        lat: lat,
                                                        manager_id: managerID,
                                                        phone_number: numberPhone,
                                                        address: address,
                                                        Mobile: mobile,
                                                        email: email,
                                                        percent: percent,
                                                        cost: cost,
                                                        document: document
                                                }
                                        }));
                                }

                                if (response.payload.name && response.payload.name.length > 0) {
                                        setBranchName('')
                                        errors.branchName = response.payload.name[0];
                                }
                                if (response.payload.Mobile && response.payload.Mobile.length > 0) {
                                        setMobile('')
                                        errors.Mobile = response.payload.Mobile[0];
                                }
                                if (response.payload.email && response.payload.email.length > 0) {
                                        setEmail('')
                                        errors.email = response.payload.email[0];
                                }
                                if (response.payload.phone_number && response.payload.phone_number.length > 0) {
                                        setNumberPhone('')
                                        errors.numberPhone = response.payload.phone_number[0];
                                }
                                if (response.payload.address && response.payload.address.length > 0) {
                                        setAddress('')
                                        errors.address = response.payload.address[0];
                                }
                                if (response.payload.manager_id && response.payload.manager_id.length > 0) {
                                        setManagerID('')
                                        errors.managerID = response.payload.managerID[0];
                                }

                                if (response.payload.status === 'fail') {
                                        setValidationErrors(errors);
                                } else {
                                        window.location.href = '/branch';
                                        dispatch(fetchBranches());
                                }
                        } catch (error) {
                                console.error("Error creating branch:", error);
                        }
                }
        }

        return (
                <DashboardLayout>
                        <MDBox sx={{
                                backgroundColor: colors.gradients.info.main,
                                colors: colors.white.main,
                                height: '75px', alignItems: 'center', alignContent: 'center',
                                borderRadius: '0.5rem',
                        }}>
                                <MDTypography fontWeight="bold" color="white" fontSize={'18px'} p={1}
                                        textAlign='center' >{isUpdateBranchInfo ? ' Update Branch Information'
                                                : ' Create New Branch Inside Company'
                                        }
                                </MDTypography>
                        </MDBox>

                        <MDBox display="flex" justifyContent="center" p={2}  >
                                <MainBadgeItem
                                        avatarImage={image}
                                        handleSelectImage={handleSelectImage}
                                />
                        </MDBox>
                        {/* //! first row */}
                        <MDBox display="flex" justifyContent="space-between" >
                                <TextFeildForm
                                        value={branchName}
                                        placeholder={validationErrors.branchName ? validationErrors.branchName : "Branch Name"}
                                        label={"Branch Name"}
                                        validationColor={validationErrors.branchName ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.branchName}
                                        onChange={(e) => {
                                                setBranchName(e.target.value);
                                                setValidationErrors({ ...validationErrors, branchName: '' });
                                        }}
                                />

                                <TextFeildForm
                                        value={address}
                                        placeholder={validationErrors.address ? validationErrors.address : "Address"}
                                        label={"Address"}
                                        validationColor={validationErrors.address ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.address}
                                        onChange={(e) => {
                                                setAddress(e.target.value);
                                                setValidationErrors({ ...validationErrors, address: '' });
                                        }}
                                />

                        </MDBox>

                        {/* //! second row */}
                        <MDBox display="flex" justifyContent="space-between" >
                                <TextFeildForm
                                        value={mobile}
                                        isNumaric={true}
                                        placeholder={validationErrors.mobile ? validationErrors.mobile : "Mobile Number"}
                                        label={"Mobile Number"}
                                        validationColor={validationErrors.mobile ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.mobile}
                                        onChange={(e) => {
                                                setMobile(e.target.value);
                                                setValidationErrors({ ...validationErrors, mobile: '' });
                                        }}
                                />
                                <TextFeildForm
                                        value={numberPhone}
                                        isNumaric={true}
                                        placeholder={validationErrors.numberPhone ? validationErrors.numberPhone : "Phone Number"}
                                        label={"Phone Number"}
                                        validationErrors={validationErrors.numberPhone}
                                        validationColor={validationErrors.numberPhone ? colors.gradients.error.main : colors.white}
                                        onChange={(e) => {
                                                setNumberPhone(e.target.value);
                                                setValidationErrors({ ...validationErrors, numberPhone: '' });
                                        }}
                                />
                        </MDBox>

                        {/* //! third row */}
                        <MDBox display="flex" justifyContent="space-between" >

                                <DropdownTextField
                                        value={city}
                                        isFulWidth={false}
                                        options={["Abu Dhabi", "Ajman", "Al Ain", "Dubai", "Fujairah", "Ras Al Khaimah(RAK)", "Sharjah", "Umm Al Quwain(UAQ)"]}
                                        validationErrors={validationErrors.city}
                                        validationColor={validationErrors.city ? colors.gradients.error.main : colors.white}
                                        placholder={"City"}
                                        label={"City"}
                                        onChange={(newValue) => setCity(newValue)}
                                />

                                <DropdownTextField
                                        value={managerName}
                                        isFulWidth={false}
                                        placholder={"Branch Manager"}
                                        label={"Branch Manager"}
                                        validationErrors={validationErrors.managerID}
                                        validationColor={validationErrors.managerID ? colors.gradients.error.main : colors.white}
                                        options={branchManagers?.map(manager => manager.username)}
                                        branchManagersLoading={branchManagersLoading}
                                        onChange={(newValue) => {
                                                const selectedManager = branchManagers.find(manager => manager.username === newValue);
                                                if (selectedManager) {
                                                        setManagerID(selectedManager.id);
                                                        console.log("selectedManager ID: " + selectedManager.id);
                                                } else {
                                                        setManagerID('');
                                                }
                                        }}
                                />


                        </MDBox>


                        {/* //! fourth row */}
                        <MDBox display="flex" justifyContent="space-between" >
                                <TextFeildForm
                                        value={email}
                                        placeholder={validationErrors.email ? validationErrors.email : "Email"}
                                        label={"Email"}
                                        validationColor={validationErrors.email ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.email}
                                        onChange={(e) => {
                                                setEmail(e.target.value);
                                                setValidationErrors({ ...validationErrors, email: '' });
                                        }}
                                />
                                {isUpdateBranchInfo ? <MDBox /> :
                                        <TextFeildForm
                                                value={cost}
                                                placeholder={validationErrors.cost ? validationErrors.cost : "Cost of Construction"}
                                                label={"Cost of Construction"}
                                                validationColor={validationErrors.cost ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.cost}
                                                onChange={(e) => {
                                                        setCost(e.target.value);
                                                        setValidationErrors({ ...validationErrors, cost: '' });
                                                }}
                                        />
                                }

                                <TextFeildForm
                                        value={percent}
                                        placeholder={validationErrors.percent ? validationErrors.percent : "Percent"}
                                        label={"Percent"}
                                        validationColor={validationErrors.percent ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.percent}
                                        onChange={(e) => {
                                                setPercent(e.target.value);
                                                setValidationErrors({ ...validationErrors, percent: '' });
                                        }}
                                />

                        </MDBox>

                        {/* //! fifth row */}
                        <MDBox display="flex" justifyContent="space-between" >
                                <TextFeildForm
                                        value={lat}
                                        isNumaric={true}
                                        placeholder={validationErrors.lat ? validationErrors.lat : "Latitude"}
                                        label={"Latitude"}
                                        validationColor={validationErrors.lat ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.lat}
                                        onChange={(e) => {
                                                setLat(e.target.value);
                                                setValidationErrors({ ...validationErrors, lat: '' });
                                        }}
                                />
                                <TextFeildForm
                                        value={lng}
                                        isNumaric={true}
                                        placeholder={validationErrors.lng ? validationErrors.lng : "Langtuning"}
                                        label={"Langtuning"}
                                        validationColor={validationErrors.lng ? colors.gradients.error.main : colors.white}
                                        validationErrors={validationErrors.lng}
                                        onChange={(e) => {
                                                setLng(e.target.value);
                                                setValidationErrors({ ...validationErrors, lng: '' });
                                        }}
                                />
                        </MDBox>

                        {/* //! six row */}
                        <MDBox
                                sx={{ width: '95%' }}
                                onClick={handleDocumentSelected}
                        >
                                <label>
                                        <input
                                                type="file"
                                                style={{ display: 'none' }}
                                                onChange={handleFileChange}
                                                accept=".pdf, .doc, .docx"
                                                disabled={document !== ''}
                                                ref={fileInputRef}
                                        />
                                        <TextFeildForm
                                                value={fileName || ''}
                                                placeholder={validationErrors.document ? validationErrors.document : 'Select a Document'}
                                                label={"Document Files"}
                                                validationColor={validationErrors.document ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.document}
                                                readOnly
                                        />
                                </label>
                        </MDBox>

                        <MDBox display="flex" justifyContent="space-around" pt={3}>
                                <MainButton
                                        title={loading || updateLoading ?
                                                <CircularProgress size={24} sx={{ color: colors.white.main }} />
                                                : isUpdateBranchInfo ? 'Update ' : 'Create'}
                                        width={"20%"}
                                        backgroundColor={colors.gradients.info.main}
                                        hoverBackgroundColor={"#2f4858"}
                                        colorTitle={colors.white.main}
                                        onClick={handleCreateBranch}
                                />
                                <MainButton
                                        title={'Create New Branch Manager'}
                                        width={"20%"}
                                        backgroundColor={colors.gradients.success.main}
                                        hoverBackgroundColor={colors.gradients.success.state}
                                        colorTitle={colors.white.main}
                                        onClick={() => {
                                                window.location.href = '/create-new-branch-manager';
                                        }}
                                />
                                <MainButton
                                        title={'Back'}
                                        width={"20%"}
                                        backgroundColor={colors.gradients.error.main}
                                        hoverBackgroundColor={colors.gradients.error.state}
                                        colorTitle={colors.white.main}
                                        onClick={() => {
                                                window.location.href = '/branch';
                                        }}
                                />


                        </MDBox>
                </DashboardLayout>
        )
}

export default AddNewBranchPage
