import React, { useEffect, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import { Grid } from '@mui/material';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import BranchCard from '../components/branch_card';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import { LocationCityRounded } from '@mui/icons-material';
import MainDialog from '../../../../../../components/Dialog/main_dialog.jsx';
import { useDispatch, useSelector } from 'react-redux';
import { fetchBranches } from '../../services/apis/get_branches_api.jsx';
import { changeStatusBranch } from '../../services/apis/change_status_service.jsx';
import ErrorCard from '../../../../../../components/handleState/error_card.jsx';
import EmptyCard from '../../../../../../components/handleState/empty_card.jsx';
import colors from '../../../../../../assets/theme/base/colors.jsx';
import MDBox from '../../../../../../items/MDBox/MDBox.jsx';
import BranchCardLoading from '../../../../../../components/Cards/shimmarCards/branch_card_shimmar.jsx';
import HeaderLayout from '../../../../../../components/LayoutContainers/HeaderPageLayout/index.jsx';

const BranchesPage = () => {
  const dispatch = useDispatch();
  const [isDialogChangeStatusOpen, setIsDialogChangeStatusOpen] = useState(false);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('');
  const [selectedBranchId, setSelectedBranchId] = useState('');

  useEffect(() => {
    dispatch(fetchBranches());
  }, [dispatch]);

  const branches = useSelector(state => state.branches.branches);
  const loading = useSelector(state => state.branches.loading);
  const error = useSelector(state => state.branches.error);

  const handleCreateNewBranch = () => {
    window.location.href = '/add-branch'
  };

  const handleUpdateInfoBranch = (isUpdateBranchInfo, branchId, branchInfo) => {
    isUpdateBranchInfo = true;
    const queryParams = new URLSearchParams({
      isUpdateBranchInfo: isUpdateBranchInfo,
      branchId: branchId,
      ...branchInfo
    });

    window.location.href = `/add-branch?${queryParams.toString()}`;
  };

  const handleChangeStatusBranch = async (branchId) => {
    try {
      const res = await dispatch(changeStatusBranch({ branch_id: branchId }));
      if (res.payload.status === 'success') {
        handleCloseChangeStatusDialog();
        dispatch(fetchBranches());
      }
    } catch (error) {
    }
  };

  const handleOpenChangeStatusDialog = (branchId) => {
    setIsDialogChangeStatusOpen(true);
    setSelectedBranchId(branchId);
  };

  const handleCloseChangeStatusDialog = () => {
    setIsDialogChangeStatusOpen(false);
  };

  const filteredBranches = branches.filter(branch => {
    if (selectedStatusFilter === '') {
      return true;
    } else {
      return branch.status.toLowerCase() === selectedStatusFilter.toLowerCase();
    }
  });

  return (
    <DashboardLayout>
      <DashboardNavbar
        firstOption={
          <MenuOptionItem icon={<LocationCityRounded />} title="Create New Branch" onClick={handleCreateNewBranch} />
        }
      />

      <MDBox lineHeight={1.25} sx={{ borderRadius: 5, backgroundColor: colors.white.main }}>

        <HeaderLayout
          title={'Company Branches'}
          subTitle={"All Branches is Available in This Company"}
          placeholder={"Status"}
          isFilter={true}
          options={['Active', 'InActive']}
          value={selectedStatusFilter}
          onChange={(newValue) => setSelectedStatusFilter(newValue)}

        />

        <MDBox sx={{ p: 1 }} />

        {loading ?
          (
            <Grid container spacing={2} >
              {[...Array(6)].map((_, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <MDBox sx={{ alignItems: 'center', alignContent: 'center' }}>
                    <BranchCardLoading />
                  </MDBox>
                </Grid>
              ))}
            </Grid>
          )
          : error ?
            (
              <MDBox sx={{ alignItems: 'center', alignContent: 'center' }}>
                <ErrorCard />
              </MDBox>
            )
            : (
              <Grid container spacing={2} sx={{ justifyContent: 'center', textAlign: 'center' }}>
                {Array.isArray(filteredBranches) && filteredBranches.length === 0 ? (
                  <MDBox sx={{ alignItems: 'center', alignContent: 'center' }}>
                    <EmptyCard
                      message={"The Branches is Empty"}
                    />
                  </MDBox>
                ) : (
                  filteredBranches.map((branch, index) => (

                    <Grid key={index} item xs={12} md={4}>
                      <BranchCard
                        key={branch.id}
                        branchId={branch.id}
                        status={branch.status}
                        branchName={branch.name}
                        managerName={branch.branch__manager ? branch.branch__manager.user.username : "No Manager"}
                        managerID={branch.branch__manager ? branch.branch__manager.user_id : 0}
                        branchCity={branch.districts}
                        branchPhoneNumber={branch.phone_number}
                        branchMobile={branch.Mobile}
                        branchDocument={branch.document}
                        branchEmail={branch.email}
                        branchLat={branch.lat}
                        branchLng={branch.lng}
                        percent={branch.percent}
                        branchAddress={branch.address}
                        isUpdateInfoBranch={(isUpdateBranchInfo) => handleUpdateInfoBranch(
                          isUpdateBranchInfo,
                          branch.id, {
                          branchName: branch.name,
                          branchImage: `https://prime-shippa-api.point-dev.net/storage/${branch.image.replace('public/', '')}`,
                          managerName: branch.branch__manager ? branch.branch__manager.user.username : "No Manager",
                          managerID: branch.branch__manager ? branch.branch__manager.user.id : 0,
                          branchCity: branch.districts,
                          branchPhoneNumber: branch.phone_number,
                          branchMobile: branch.Mobile,
                          branchDocument: branch.document,
                          branchEmail: branch.email,
                          branchLat: branch.lat,
                          branchLng: branch.lng,
                          branchAddress: branch.address,
                          percent: branch.percent
                        },

                        )}
                        isChangeStatusBranch={() => handleOpenChangeStatusDialog(branch.id)}
                      />

                      {/* <BranchCard
                        key={branch.branch.index}
                        branchId={branch.branch.id}
                        status={branch.branch.status}
                        branchName={branch.branch.name}
                        managerName={branch.manager ? branch.manager.username : "No Manager"}
                        managerID={branch.manager ? branch.manager.id : 0}
                        branchCity={branch.branch.districts}
                        branchPhoneNumber={branch.branch.phone_number}
                        branchMobile={branch.branch.Mobile}
                        branchDocument={branch.branch.document}
                        branchEmail={branch.branch.email}
                        branchLat={branch.branch.lat}
                        branchLng={branch.branch.lng}
                        branchAddress={branch.branch.address}
                        isChangeStatusBranch={() => handleOpenChangeStatusDialog(branch.branch.id)}
                      /> */}
                    </Grid>
                  )))}
              </Grid>
            )}
        <MDBox sx={{ pb: 2 }} />
      </MDBox>

      {/* dialog to change status branch */}
      <MainDialog
        isDialogOpen={isDialogChangeStatusOpen}
        DialogClose={handleCloseChangeStatusDialog}
        headTitle={"Change Status Branch"}
        subTitle={"Are you sure to change status branch ?"}
        onClick={handleChangeStatusBranch}
        confirmEvent={() => handleChangeStatusBranch(selectedBranchId)}
      />
    </DashboardLayout >
  );
};

export default BranchesPage;
