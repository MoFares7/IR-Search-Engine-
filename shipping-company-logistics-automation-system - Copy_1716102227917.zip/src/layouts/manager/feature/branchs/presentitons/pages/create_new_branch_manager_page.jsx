import React, { useState, useRef, useEffect } from 'react'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import { useDispatch, useSelector } from 'react-redux';
import MDTypography from '../../../../../../items/MDTypography';
import { CircularProgress, Divider } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MainButton from '../../../../../../components/Items/MainButton/main_button';
import DropdownTextField from '../components/drop_down_textFiled';
import TextFeildForm from '../../../../../../components/Items/Form_TextFeild/text_feild_form';
import colors from '../../../../../../assets/theme/base/colors';
import { useLocation, useParams } from 'react-router-dom';
import { updateBranchManager } from '../../../branches_manage/services/update_branch_manager_service';
import { createNewBranchManager } from '../../../branches_manage/services/create_branch_manager_service';
import { getBranchesManagers } from './../../../branches_manage/services/get_branch_manager';
import { fetchBranches } from './../../services/apis/get_branches_api';

const CreateNewBranchManagerPage = () => {
  const location = useLocation();
  const [managerInfo, setmanagerInfo] = useState({});
  const [isUpdateManagerInfo, setIsUpdateManagerInfo] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const managerInfo = Object.fromEntries(queryParams.entries());
    console.log("Branch Info:", managerInfo);
    setmanagerInfo(managerInfo || '');
    setManagerID(managerInfo.id || '');
    setFulName(managerInfo.username || '');
    setFatherName(managerInfo.father_name || '');
    setMohterName(managerInfo.mother_name || '');
    setPhoneNumber(managerInfo.phone_number || '');
    setEmail(managerInfo.email || '');
    setAddress(managerInfo.address || '');
    setBrithDate(managerInfo.bitrh_date || '');
    setFileName(managerInfo.cv_file || '');
    setDegree(managerInfo.degree || '');
    setGender(managerInfo.gender || '');
    setNational(managerInfo.nationality || '');
    setNationalNumber(managerInfo.id_number || '');
    setSalary(managerInfo.salary || '');

    setIsUpdateManagerInfo(managerInfo.isUpdateInfoManager === 'true');

  }, [location]);

  const [managerID, setManagerID] = useState('');
  const [fulName, setFulName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [mohterName, setMohterName] = useState('');
  const [nationalNumber, setNationalNumber] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [address, setAddress] = useState('');
  const [national, setNational] = useState('');
  const [degree, setDegree] = useState('');
  const [brithDate, setBrithDate] = useState('');
  const [salary, setSalary] = useState('');
  const [gender, setGender] = useState('');
  const [cv, setCv] = useState('');
  const [fileName, setFileName] = useState('');
  const fileInputRef = useRef(null);
  const [validationErrors, setValidationErrors] = useState({
    fulName: '',
    fatherName: '',
    mohterName: '',
    nationalNumber: '',
    phoneNumber: '',
    email: '',
    password: '',
    address: '',
    national: '',
    degree: '',
    salary: '',
    gender: '',
    brithDate: '',
    cv: '',
    fileName: ''
  });

  const loading = useSelector(state => state.createNewBranchManager.loading);
  const updateLoading = useSelector(state => state.updateBranchManager.loading);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    console.log("Selected file:", file);
    if (file) {
      console.log("File type:", file.type);
      setCv(file);
      setFileName(file.name);
      setValidationErrors({ ...validationErrors, cv: '' });
    }
  };

  const handleCvSelected = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleCreateNewBranchManager = async () => {
    const errors = {};

    if (fulName.trim() === '' || fulName.length < 3) {
      errors.fulName = 'Full Name is required and must to be grater than 3 letter';
    }
    if (fatherName.trim() === '') {
      errors.fatherName = 'Father Name is required';
    }
    if (mohterName.trim() === '') {
      errors.mohterName = 'Mother Name is required';
    }
    if (degree.trim() === '') {
      errors.degree = 'degree is required';
    }
    if (phoneNumber.trim() === '' || phoneNumber.length < 10) {
      errors.phoneNumber = 'Phone Number is required and must to be greater than 9 number';
    }
    if (email.trim() === '') {
      errors.email = 'Email is required';
    }
    {
      isUpdateManagerInfo ? '' :
        password === '' ?
          errors.password = 'Password is required' : ''
    }
    
    if (salary.trim() === '') {
      errors.salary = 'Salary is required';
    }
    if (national.trim() === '') {
      errors.national = 'Nationalty is required';
    }
    if (nationalNumber.trim() === '' || nationalNumber.length != 11) {
      errors.nationalNumber = 'National Number is required and must to be 11 Number';
    }
    {
      isUpdateManagerInfo ? fileName === '' ? errors.fileName = 'Cv is required' : '' :
        cv === '' ?
          errors.cv = 'Cv is required' : ''
    }

    if (brithDate.trim() === '') {
      errors.brithDate = 'Brith date is required';
    }
    if (address.trim() === '') {
      errors.address = 'Address is required';
    }
    if (gender.length === 0) {
      errors.gender = 'Gender is required';
    }

    setValidationErrors(errors);

    if (Object.keys(errors).length === 0) {
      try {

        let response;


        //todo here when send update is send only file name no file
        try {
          isUpdateManagerInfo ?
            response = await dispatch(updateBranchManager({
              managerID, payload: {
                username: fulName,
                father_name: fatherName,
                mother_name: mohterName,
                nationality: national,
                phone_number: phoneNumber,
                email: email,
                address: address,
                id_number: nationalNumber,
                degree: degree,
                gender: gender,
                salary: salary,
                bitrh_date: brithDate,
                cv_file: fileName,
              }
            }))
            :
            response = await dispatch(createNewBranchManager({
              payload: {
                username: fulName,
                father_name: fatherName,
                mother_name: mohterName,
                nationality: national,
                phone_number: phoneNumber,
                email: email,
                password: password,
                address: address,
                id_number: nationalNumber,
                degree: degree,
                gender: gender,
                salary: salary,
                bitrh_date: brithDate,
                cv_file: cv,
              }
            }));

          if (response.payload && response.payload.status === 'fail') {
            console.log("Detailed error response:", response.payload);

            if (response.payload.username && response.payload.username.length > 0) {
              setFulName('')
              errors.fulName = response.payload.username[0];
            }
            if (response.payload.father_name && response.payload.father_name.length > 0) {
              setFatherName('')
              errors.father_name = response.payload.father_name[0];
            }
            if (response.payload.mother_name && response.payload.mother_name.length > 0) {
              setMohterName('')
              errors.mother_name = response.payload.mother_name[0];
            }
            if (response.payload.bitrh_date && response.payload.bitrh_date.length > 0) {
              setBrithDate('')
              errors.bitrh_date = response.payload.bitrh_date[0];
            }
            if (response.payload.id_number && response.payload.nationality.length > 0) {
              setNational('')
              errors.national = response.payload.nationality[0];
            }
            if (response.payload.nationality && response.payload.id_number.length > 0) {
              setNationalNumber('')
              errors.nationalNumber = response.payload.id_number[0];
            }
            if (response.payload.address && response.payload.address.length > 0) {
              setAddress('')
              errors.address = response.payload.address[0];
            }
            if (response.payload.degree && response.payload.degree.length > 0) {
              setDegree('')
              errors.degree = response.payload.degree[0];
            }
            if (response.payload.email && response.payload.email.length > 0) {
              setEmail('')
              errors.email = response.payload.email[0];
            }
            if (response.payload.password && response.payload.password.length > 0) {
              setPassword('')
              errors.password = response.payload.password[0];
            }
            if (response.payload.phone_number && response.payload.phone_number.length > 0) {
              setPhoneNumber('')
              errors.phoneNumber = response.payload.phone_number[0];
              console.log(" tttt " + response.payload.phone_number[0])
            }

            if (response.payload.cv_file && response.payload.cv_file.length > 0) {
              setCv('')
              errors.cv_file = response.payload.cv_file[0];
            }

            setValidationErrors(errors);
          }
        } catch (error) {
          console.error("Error:", error);
        }

        if (response.payload && response.payload.status === 'fail') {

        } else {
          window.location.href = '/branch-manage'
          dispatch(fetchBranches());
        }
      }
      catch (error) {
        throw error;
      }
    };
  }

  return (
    <DashboardLayout>
      <MDTypography fontWeight="bold" color="black" fontSize={'18px'} p={1}
        textAlign='center' >{isUpdateManagerInfo ? 'Update Info Branch Manager' : 'Create New Branch Manager'}</MDTypography>
      <Divider sx={{
        color: "#252525",
        backgroundColor: "#252525;"
      }} />

      <>
        {/* //! first row */}
        <MDBox display="flex" justifyContent="space-between"  >
          <TextFeildForm
            value={fulName}
            placeholder={validationErrors.fulName ? validationErrors.fulName : "Full Name"}
            label={"Full Name"}
            validationColor={validationErrors.fulName ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.fulName}
            onChange={(e) => {
              setFulName(e.target.value);
              setValidationErrors({ ...validationErrors, fulName: '' });
            }}
          />
          <TextFeildForm
            value={fatherName}
            placeholder={validationErrors.fatherName ? validationErrors.fatherName : "Father Name"}
            label={"Father Name"}
            validationColor={validationErrors.fatherName ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.fatherName}
            onChange={(e) => {
              setFatherName(e.target.value);
              setValidationErrors({ ...validationErrors, fatherName: '' });
            }}
          />

        </MDBox>

        {/* //! third row */}
        <MDBox display="flex" justifyContent="space-between" >
          <TextFeildForm
            value={mohterName}
            placeholder={validationErrors.mohterName ? validationErrors.mohterName : "Mohter Name"}
            label={"Mother Name"}
            validationColor={validationErrors.mohterName ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.mohterName}
            onChange={(e) => {
              setMohterName(e.target.value);
              setValidationErrors({ ...validationErrors, mohterName: '' });
            }}
          />
          <TextFeildForm
            isDate={true}
            value={brithDate}
            placeholder={validationErrors.brithDate ? validationErrors.brithDate : "Brith Date"}
            // label={"Brith Date"}
            validationColor={validationErrors.brithDate ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.brithDate}
            onChange={(e) => {
              setBrithDate(e.target.value);
              setValidationErrors({ ...validationErrors, brithDate: '' });
            }}
          />

        </MDBox>

        {/* //! fourth row */}
        <MDBox display="flex" justifyContent="space-between" >
          <TextFeildForm
            value={national}
            placeholder={validationErrors.national ? validationErrors.national : "Nationality Employee"}
            label={"Nationality Employee "}
            validationErrors={validationErrors.national}
            validationColor={validationErrors.national ? colors.gradients.error.main : colors.white}
            onChange={(e) => {
              setNational(e.target.value);
              setValidationErrors({ ...validationErrors, national: '' });
            }}
          />
          <TextFeildForm
            isNumaric={true}
            value={nationalNumber}
            placeholder={validationErrors.nationalNumber ? validationErrors.nationalNumber : "National Number"}
            label={"National Number"}
            validationErrors={validationErrors.nationalNumber}
            validationColor={validationErrors.nationalNumber ? colors.gradients.error.main : colors.white}
            onChange={(e) => {
              setNationalNumber(e.target.value);
              setValidationErrors({ ...validationErrors, nationalNumber: '' });
            }}
          />
        </MDBox>

        {/* //! fifth row */}
        <MDBox display="flex" justifyContent="space-between" >
          <TextFeildForm
            value={address}
            placeholder={validationErrors.address ? validationErrors.address : "Address"}
            label={"Address"}
            validationColor={validationErrors.address ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.address}
            onChange={(e) => {
              setAddress(e.target.value);
              setValidationErrors({ ...validationErrors, address: '' });
            }}
          />
          <TextFeildForm
            value={degree}
            placeholder={validationErrors.degree ? validationErrors.degree : "Degree"}
            label={"Degree"}
            validationColor={validationErrors.degree ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.degree}
            onChange={(e) => {
              setDegree(e.target.value);
              setValidationErrors({ ...validationErrors, degree: '' });
            }}
          />
          <TextFeildForm
            value={salary}
            placeholder={validationErrors.salary ? validationErrors.salary : "Salary"}
            label={"Salary"}
            validationColor={validationErrors.salary ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.salary}
            onChange={(e) => {
              setSalary(e.target.value);
              setValidationErrors({ ...validationErrors, salary: '' });
            }}
          />
        </MDBox>

        {/* //! six row */}
        <MDBox display="flex" justifyContent="space-between" >
          <TextFeildForm
            value={email}
            placeholder={validationErrors.email ? validationErrors.email : "Email"}
            label={"Email"}
            validationColor={validationErrors.email ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.email}
            onChange={(e) => {
              setEmail(e.target.value);
              setValidationErrors({ ...validationErrors, email: '' });
            }}
          />
          {isUpdateManagerInfo ?
            <MDBox />
            :
            <TextFeildForm
              value={password}
              placeholder={validationErrors.password ? validationErrors.password : "Password"}
              label={"Password"}
              validationColor={validationErrors.password ? colors.gradients.error.main : colors.white}
              validationErrors={validationErrors.password}
              onChange={(e) => {
                setPassword(e.target.value);
                setValidationErrors({ ...validationErrors, password: '' });
              }}
            />
          }


        </MDBox>

        {/* //! seven row */}
        <MDBox display="flex" justifyContent="space-between" >
          <TextFeildForm
            isNumaric={true}
            value={phoneNumber}
            placeholder={validationErrors.phoneNumber ? validationErrors.phoneNumber : 'Phone Number'}
            label={"Phone Number"}
            validationColor={validationErrors.phoneNumber ? colors.gradients.error.main : colors.white}
            validationErrors={validationErrors.phoneNumber}
            onChange={(e) => {
              setPhoneNumber(e.target.value);
              setValidationErrors({ ...validationErrors, phoneNumber: '' });
            }}
          />

          <DropdownTextField
            value={gender}
            options={["male", "female"]}
            validationErrors={validationErrors.gender}
            validationColor={validationErrors.gender ? colors.gradients.error.main : colors.white}
            placholder={"Gender"}
            label={"Gender"}
            onChange={(newValue) => setGender(newValue)}
          />
        </MDBox>

        {/* Select files cv */}
        <MDBox
          sx={{ width: '95%' }}
          onClick={handleCvSelected}
        >
          <label>
            <input
              type="file"
              style={{ display: 'none' }}
              onChange={handleFileChange}
              accept=".pdf, .doc, .docx"
              // disabled={cv !== ''}
              ref={fileInputRef}
            />
            <TextFeildForm
              value={fileName || ''}
              placeholder={validationErrors.cv ? validationErrors.cv : 'Select a Cv'}
              label={"Cv File"}
              validationColor={validationErrors.cv ? colors.gradients.error.main : colors.white}
              validationErrors={validationErrors.cv}
              readOnly
            />
          </label>
        </MDBox>
      </>


      {/* //! Buttons controll row */}
      <MDBox display="flex" justifyContent="space-around" pt={5}>
        <MainButton
          title={loading || updateLoading ?
            <CircularProgress size={24} sx={{ color: colors.white.main }} />
            : isUpdateManagerInfo ? 'Update' : 'Create'}
          width={"20%"}
          backgroundColor={colors.gradients.info.main}
          hoverBackgroundColor={"#2f4858"}
          colorTitle={colors.white.main}
          onClick={handleCreateNewBranchManager}
        />
        <MainButton
          isLoading={false}
          title='Back'
          width={"20%"}
          backgroundColor={colors.gradients.error.main}
          hoverBackgroundColor={colors.gradients.error.state}
          colorTitle={colors.white.main}
          onClick={() => {
            window.location.href = '/branch-manage'
          }}
        />

      </MDBox>

    </DashboardLayout >
  )
}

export default CreateNewBranchManagerPage;

