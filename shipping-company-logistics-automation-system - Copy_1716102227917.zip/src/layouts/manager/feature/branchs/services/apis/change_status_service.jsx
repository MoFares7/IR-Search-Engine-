import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { getValue } from '../../../../../../core/storage/storage';
import api from '../../../../../../core/network/api.jsx'

export const changeStatusBranch = createAsyncThunk(
        'branch/changeStatus',
        async ({ branch_id }, {  }) => {
                try {
                        const response = await api.post(`branch/change/status?branch_id=${branch_id}`);
                        console.log("changeStatusBranch success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);


const changeStatusBranchSlice = createSlice({
        name: 'changeStatusBranch',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(changeStatusBranch.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(changeStatusBranch.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.status;
                        })
                        .addCase(changeStatusBranch.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default changeStatusBranchSlice.reducer;
