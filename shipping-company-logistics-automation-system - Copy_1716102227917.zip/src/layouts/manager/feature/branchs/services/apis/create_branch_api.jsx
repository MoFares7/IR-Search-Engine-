import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api';

export const createNewBranch = createAsyncThunk(
        'branch/store',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`branch/store`, payload);
                        console.log("createNewBranch success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const createBrnchSlice = createSlice({
        name: 'createNewBranch',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(createNewBranch.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(createNewBranch.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(createNewBranch.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default createBrnchSlice.reducer;
