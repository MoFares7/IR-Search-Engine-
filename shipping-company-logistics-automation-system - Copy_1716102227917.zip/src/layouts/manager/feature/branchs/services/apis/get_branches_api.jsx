import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api.jsx';

export const fetchBranches = createAsyncThunk(
        'branches/fetchBranches',
        async () => {
                const response = await api.get(`branch`);
                console.log("response branch: " + response);
                return response.data;
        }
);

const branchesSlice = createSlice({
        name: 'branches',
        initialState: {
                branches: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(fetchBranches.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(fetchBranches.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.branches = action.payload;
                        })
                        .addCase(fetchBranches.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default branchesSlice.reducer;
