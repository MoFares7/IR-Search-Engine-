import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api';

export const downloadFilesBranchService = createAsyncThunk(
        'branch/downloadFile',
        async ({ branch_id }, { rejectWithValue }) => {
                try {
                        const response = await api.get(`branch/downloadFile/${branch_id}`,{
                                 responseType: 'blob',
                        });
                        const blob = new Blob([response.data], { type: response.headers['content-type'] });

                        const link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);

                        if (response.headers['content-disposition']) {
                                link.download = response.headers['content-disposition'].split('filename=')[1];
                        } else {
                                link.download = 'downloaded_file';
                        }

                        document.body.appendChild(link);
                        link.click();

                        document.body.removeChild(link);

                        return { success: true };

                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const downloadBranchFileSlice = createSlice({
        name: 'downloadFilesBranchService',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(downloadFilesBranchService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(downloadFilesBranchService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(downloadFilesBranchService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default downloadBranchFileSlice.reducer;
