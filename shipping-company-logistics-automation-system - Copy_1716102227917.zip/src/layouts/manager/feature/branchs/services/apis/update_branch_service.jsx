import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api';

export const updateBranchInfo = createAsyncThunk(
        'branch/updateBranch',
        async ({ branch_id, payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`branch/update/${branch_id}`, payload);
                        console.log("updateBranchInfo success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const updateBranchSlice = createSlice({
        name: 'updateBranchInfo',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(updateBranchInfo.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(updateBranchInfo.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(updateBranchInfo.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default updateBranchSlice.reducer;
