import React, { useState, useRef, useEffect } from 'react'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import { useDispatch, useSelector } from 'react-redux';
import MDTypography from '../../../../../../items/MDTypography';
import { CircularProgress, Divider } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MainButton from '../../../../../../components/Items/MainButton/main_button';
import TextFeildForm from '../../../../../../components/Items/Form_TextFeild/text_feild_form';
import colors from '../../../../../../assets/theme/base/colors';
import { Navigate, useLocation, useParams } from 'react-router-dom';
import { createWarehouseBranch } from '../../services/create_warehouse_service';
import { getWarehousesBranch } from '../../services/get_warehouses_service';
import DropdownTextField from '../../../../../manager/feature/branchs/presentitons/components/drop_down_textFiled';
import MainBadgeItem from '../../../../../../components/Items/Badge/badge';
import { updateWarehouseService } from './../../services/update_warehouse_service';

const CreateWarehousePage = () => {
        const location = useLocation();
        const [warehouseInfo, setwarehouseInfo] = useState({});
        const [isUpdatewarehouseInfo, setIsUpdatewarehouseInfo] = useState(false);
        const dispatch = useDispatch();

        useEffect(() => {
                const queryParams = new URLSearchParams(location.search);
                const warehouseInfo = Object.fromEntries(queryParams.entries());
                console.log("Branch Info:", warehouseInfo);
                setwarehouseInfo(warehouseInfo || '');
                setWarehouseID(warehouseInfo.warehouseId || '');
                setname(warehouseInfo.title || '');
                setcapacity(warehouseInfo.capacity || '');
                setPhoneNumber(warehouseInfo.phone_number || '');
                setEmail(warehouseInfo.email || '');
                setAddress(warehouseInfo.address || '');
                setFileName(warehouseInfo.document || '');
                setcosts(warehouseInfo.cost || '');
                setownership(warehouseInfo.Property || '');
                setDescription(warehouseInfo.description || '');
                setImage(warehouseInfo.image || '');

                setIsUpdatewarehouseInfo(warehouseInfo.isUpdateWarehouse === 'true');

        }, [location]);

        const [warehouseID, setWarehouseID] = useState('');
        const [image, setImage] = useState('');
        const [name, setname] = useState('');
        const [capacity, setcapacity] = useState('');
        const [phoneNumber, setPhoneNumber] = useState('');
        const [email, setEmail] = useState('');
        const [address, setAddress] = useState('');
        const [costs, setcosts] = useState('');
        const [description, setDescription] = useState('');
        const [ownership, setownership] = useState('');
        const [document, setdocument] = useState('');
        const [avatarImage, setAvatarImage] = useState(null);
        const [fileName, setFileName] = useState('');
        const fileInputRef = useRef(null);
        const [validationErrors, setValidationErrors] = useState({
                name: '',
                capacity: '',
                phoneNumber: '',
                email: '',
                password: '',
                address: '',
                description: '',
                costs: '',
                ownership: '',
                document: '',
                fileName: ''
        });

        const loading = useSelector(state => state.createWarehouseBranch.loading);
        const updateLoading = useSelector(state => state.updateWarehouseService.loading);


        const handleFileChange = (e) => {
                const file = e.target.files[0];
                console.log("Selected file:", file);
                if (file) {
                        console.log("File type:", file.type);
                        setdocument(file);
                        setFileName(file.name);
                        setValidationErrors({ ...validationErrors, document: '' });
                }
        };

        const handleSelectImage = (event) => {
                const file = event.target.files[0];
                if (file) {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                                console.log("Selected file:", file.type);
                                setImage(e.target.result);
                                setAvatarImage(file);
                        };
                        reader.readAsDataURL(file);
                }
        };

        const handledocumentSelected = () => {
                if (fileInputRef.current) {
                        fileInputRef.current.click();
                }
        };

        //todo here is when update is need to send file from new why
        const handleCreateNewWarehouse = async () => {
                const errors = {};

                if (name.trim() === '' || name.length < 3) {
                        errors.name = 'Warehouse Name is required and must to be greater than 3 letters';
                }
                if (capacity.trim() === '') {
                        errors.capacity = 'Capacity is required';
                }
                if (phoneNumber.trim() === '') {
                        errors.phoneNumber = 'Phone Number is required';
                }
                if (address.trim() === '') {
                        errors.address = 'Address is required';
                }
                if (email.trim() === '') {
                        errors.email = 'Email is required';
                }
                if (ownership.trim() === '') {
                        errors.Property = 'OwnerShip Type is required';
                }
                if (costs.trim() === '') {
                        errors.costs = 'Cost is required';
                }
                if (description.trim() === '') {
                        errors.description = 'Description is required';
                }
                if (!isUpdatewarehouseInfo && document === '') {
                        errors.document = 'Document is required';
                }

                setValidationErrors(errors);

                if (Object.keys(errors).length === 0) {
                        try {
                                let response;

                                if (isUpdatewarehouseInfo) {
                                        response = await dispatch(updateWarehouseService({
                                                warehouseID,
                                                payload: {
                                                        image: avatarImage,
                                                        name: name,
                                                        capacity: capacity,
                                                        phone_number: phoneNumber,
                                                        address: address,
                                                        email: email,
                                                        Property: ownership,
                                                        cost: costs,
                                                        description: description,
                                                        document: document === '' ? fileName : document,
                                                }
                                        }));
                                } else {
                                        response = await dispatch(createWarehouseBranch({
                                                payload: {
                                                        image: avatarImage,
                                                        name: name,
                                                        capacity: capacity,
                                                        phone_number: phoneNumber,
                                                        address: address,
                                                        email: email,
                                                        Property: ownership,
                                                        cost: costs,
                                                        description: description,
                                                        document: document,
                                                }
                                        }));
                                }

                                if (response.payload && response.payload.status === 'fail') {
                                        console.log("Detailed error response:", response.payload);

                                        if (response.payload.name && response.payload.name.length > 0) {
                                                setname('');
                                                errors.name = response.payload.name[0];
                                        }
                                        if (response.payload.email && response.payload.email.length > 0) {
                                                setEmail('');
                                                errors.email = response.payload.email[0];
                                        }
                                        if (response.payload.phone_number && response.payload.phone_number.length > 0) {
                                                setPhoneNumber('');
                                                errors.phone_number = response.payload.phone_number[0];
                                        }
                                        if (response.payload.capacity && response.payload.capacity.length > 0) {
                                                setcapacity('');
                                                errors.capacity = response.payload.capacity[0];
                                        }
                                        if (response.payload.document && response.payload.document.length > 0) {
                                                setdocument('');
                                                errors.document = response.payload.document[0];
                                        }

                                        setValidationErrors(errors);
                                } else {
                                        window.location.href = '/warehousesManagment';
                                        dispatch(getWarehousesBranch());
                                }
                        } catch (error) {
                                console.error("Error:", error);
                        }
                }
        };


        return (
                <DashboardLayout>
                        <MDTypography fontWeight="bold" color="black" fontSize={'18px'} p={1}
                                textAlign='center' >{isUpdatewarehouseInfo ? 'Update Info Warehouse' : 'Create New Warehouse'}</MDTypography>
                        <Divider sx={{
                                color: "#252525",
                                backgroundColor: "#252525;"
                        }} />

                        <>
                                <MDBox display="flex" justifyContent="center" p={2}  >
                                        <MainBadgeItem
                                                avatarImage={image}
                                                handleSelectImage={handleSelectImage} />

                                </MDBox>
                                {/* //! first row */}
                                <MDBox display="flex" justifyContent="space-between"  >
                                        <TextFeildForm
                                                value={name}
                                                placeholder={validationErrors.name ? validationErrors.name : "Warehouse Name"}
                                                label={"Warehouse Name"}
                                                validationColor={validationErrors.name ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.name}
                                                onChange={(e) => {
                                                        setname(e.target.value);
                                                        setValidationErrors({ ...validationErrors, name: '' });
                                                }}
                                        />
                                        <TextFeildForm
                                                isNumaric={true}
                                                value={capacity}
                                                placeholder={validationErrors.capacity ? validationErrors.capacity : "Warehouse Capacity"}
                                                label={"Warehouse Capacity"}
                                                validationColor={validationErrors.capacity ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.capacity}
                                                onChange={(e) => {
                                                        setcapacity(e.target.value);
                                                        setValidationErrors({ ...validationErrors, capacity: '' });
                                                }}
                                        />

                                </MDBox>

                                {/* //! third row */}
                                <MDBox display="flex" justifyContent="space-between" >
                                        <TextFeildForm
                                                isNumaric={true}
                                                value={phoneNumber}
                                                placeholder={validationErrors.phoneNumber ? validationErrors.phoneNumber : "Phone Number"}
                                                label={"Phone Number"}
                                                validationColor={validationErrors.phoneNumber ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.phoneNumber}
                                                onChange={(e) => {
                                                        setPhoneNumber(e.target.value);
                                                        setValidationErrors({ ...validationErrors, phoneNumber: '' });
                                                }}
                                        />
                                        <TextFeildForm
                                                value={email}
                                                placeholder={validationErrors.email ? validationErrors.email : "Email"}
                                                label={"Email"}
                                                validationErrors={validationErrors.email}
                                                validationColor={validationErrors.email ? colors.gradients.error.main : colors.white}
                                                onChange={(e) => {
                                                        setEmail(e.target.value);
                                                        setValidationErrors({ ...validationErrors, email: '' });
                                                }}
                                        />

                                </MDBox>


                                <MDBox display="flex" justifyContent="center" >
                                        <TextFeildForm
                                                value={description}
                                                placeholder={validationErrors.description ? validationErrors.description : "Description"}
                                                label={"Description"}
                                                validationColor={validationErrors.description ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.description}
                                                onChange={(e) => {
                                                        setDescription(e.target.value);
                                                        setValidationErrors({ ...validationErrors, description: '' });
                                                }}
                                        />
                                </MDBox>

                                {/* //! fourth row */}
                                <MDBox display="flex" justifyContent="space-between" >
                                        <TextFeildForm
                                                value={address}
                                                placeholder={validationErrors.address ? validationErrors.address : "Address"}
                                                label={"Address"}
                                                validationColor={validationErrors.address ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.address}
                                                onChange={(e) => {
                                                        setAddress(e.target.value);
                                                        setValidationErrors({ ...validationErrors, address: '' });
                                                }}
                                        />
                                        <TextFeildForm
                                                isNumaric={true}
                                                value={costs}
                                                placeholder={validationErrors.costs ? validationErrors.costs : "Costs in AED"}
                                                label={"Costs in AED"}
                                                validationColor={validationErrors.costs ? colors.gradients.error.main : colors.white}
                                                validationErrors={validationErrors.costs}
                                                onChange={(e) => {
                                                        setcosts(e.target.value);
                                                        setValidationErrors({ ...validationErrors, costs: '' });
                                                }}
                                        />

                                </MDBox>


                                {/* //! seven row */}
                                <MDBox display="flex" justifyContent="space-between" >
                                        <MDBox
                                                sx={{ width: '50%' }}
                                                onClick={handledocumentSelected}
                                        >
                                                <label>
                                                        <input
                                                                type="file"
                                                                style={{ display: 'none' }}
                                                                onChange={handleFileChange}
                                                                accept=".pdf, .doc, .docx"
                                                                disabled={document !== ''}
                                                                ref={fileInputRef}
                                                        />
                                                        <TextFeildForm
                                                                isFulWidth={true}
                                                                value={fileName || ''}
                                                                placeholder={validationErrors.document ? validationErrors.document : 'Select a document'}
                                                                label={"document File"}
                                                                validationColor={validationErrors.document ? colors.gradients.error.main : colors.white}
                                                                validationErrors={validationErrors.document}
                                                                readOnly
                                                        />
                                                </label>
                                        </MDBox>
                                        <MDBox sx={{ width: '50%' }}>
                                                <DropdownTextField
                                                        isFulWidth={true}
                                                        value={ownership}
                                                        options={["rent ", "own"]}
                                                        validationErrors={validationErrors.ownership}
                                                        validationColor={validationErrors.ownership ? colors.gradients.error.main : colors.white}
                                                        placholder={"ownership"}
                                                        label={"ownership"}
                                                        onChange={(newValue) => setownership(newValue)}
                                                />
                                        </MDBox>
                                </MDBox>

                        </>


                        {/* //! Buttons controll row */}
                        <MDBox display="flex" justifyContent="space-around" pt={5}>
                                <MainButton
                                        title={
                                                loading || updateLoading ?
                                                        < CircularProgress size={24} sx={{ color: colors.white.main }} />
                                                        :
                                                        isUpdatewarehouseInfo ? 'Update' : 'Create'}
                                        width={"20%"}
                                        backgroundColor={colors.gradients.info.main}
                                        hoverBackgroundColor={"#2f4858"}
                                        colorTitle={colors.white.main}
                                        onClick={handleCreateNewWarehouse}
                                />
                                <MainButton
                                        title='Back'
                                        width={"20%"}
                                        backgroundColor={colors.gradients.error.main}
                                        hoverBackgroundColor={colors.gradients.error.state}
                                        colorTitle={colors.white.main}
                                        onClick={() => {
                                                window.location.href = '/branch-manage'
                                        }}
                                />

                        </MDBox>

                </DashboardLayout >
        )
}

export default CreateWarehousePage;

