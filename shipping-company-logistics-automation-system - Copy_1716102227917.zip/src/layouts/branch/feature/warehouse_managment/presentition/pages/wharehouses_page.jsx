import React, { useEffect, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import MDBox from '../../../../../../items/MDBox/MDBox';
import "react-circular-progressbar/dist/styles.css";
import colors from '../../../../../../assets/theme/base/colors';
import Grid from "@mui/material/Grid";
import { Box, Menu } from '@mui/material';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import { ArchiveOutlined, CreateNewFolderSharp, DeleteRounded, DownloadOutlined, EditRounded } from '@mui/icons-material';
import { useDispatch, useSelector } from 'react-redux';
import { getWarehousesBranch } from '../../services/get_warehouses_service';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import ErrorCard from '../../../../../../components/handleState/error_card';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import TabsOption from '../../../../../../items/MDTabs/tabs_option';
import WarehouseCard from '../components/warehouse_card';
import { downloadDocumentWarehouseService } from '../../services/download_document_warehouse_service';
import { useNavigate } from 'react-router-dom';
import { changeStatusWarehouseService } from '../../services/change_status_service';
import MainDialog from '../../../../../../components/Dialog/main_dialog';

const WarehousesPage = () => {
        const dispatch = useDispatch();
        const [openMenu, setOpenMenu] = useState(null);
        const [warehouseID, setWarehouseID] = useState(null);
        const [statusWarehouse, setStatusWarehouse] = useState(0);
        const [isOpenDialog, setIsOpenDialog] = useState(false);
        const { data, loading, error } = useSelector(state => state.getWarehousesBranch);
        const navigate = useNavigate();

        useEffect(() => {
                dispatch(getWarehousesBranch());
        }, [dispatch]);

        const handleOnClick = (event, warehouseId) => {
                setWarehouseID(warehouseId);
                setOpenMenu(event.currentTarget);
        };

        const handleCloseMenu = () => {
                setOpenMenu(null);
        };

        const handleCreateNewWarehouse = () => {
                window.location.href = '/create-warehouse-branch';
        };

        const handleDownloadDocumentWarehouse = async () => {
                await dispatch(downloadDocumentWarehouseService({ warehouse_id: warehouseID }));
        };

        const handleEditWarehouse = (isUpdateWarehouse, warehouseInfo) => {
                const queryParams = new URLSearchParams();

                queryParams.append("warehouseId", warehouseInfo.id);
                queryParams.append("isUpdateWarehouse", isUpdateWarehouse);
                queryParams.append("title", warehouseInfo.name);
                queryParams.append("status", warehouseInfo.status);
                queryParams.append("description", `Public warehouse capacity is estimated at: ${warehouseInfo.capacity}, Empty: ${warehouseInfo.empty}`);
                queryParams.append("capacity", warehouseInfo.capacity);
                queryParams.append("email", warehouseInfo.email);
                queryParams.append("phone_number", warehouseInfo.phone_number);
                queryParams.append("cost", warehouseInfo.cost);
                queryParams.append("address", warehouseInfo.address);
                queryParams.append("Property", warehouseInfo.Property);
                queryParams.append("document", warehouseInfo.document);
                queryParams.append("image", `https://prime-shippa-api.point-dev.net/storage/${warehouseInfo.image.replace('public/', '')}`);

                window.location.href = `/create-warehouse-branch?${queryParams.toString()}`;
        };

        const handleDeleteWarehouse = () => {
                setIsOpenDialog(true);
                console.log("Delete button clicked, dialog should open.");
        };

        const handleDeleteWarehouseConfirm = async () => {
                const response = await dispatch(changeStatusWarehouseService({ warehouseID }));
                if (response.payload.status === 'success') {
                        dispatch(getWarehousesBranch());
                }
                setIsOpenDialog(false);
        };

        const handleChangeStatusWarehouse = (event, newStatusWarehouse) => {
                setStatusWarehouse(newStatusWarehouse);
                 };

        return (
                <DashboardLayout>
                        <DashboardNavbar
                                firstOption={
                                        <MenuOptionItem icon={<CreateNewFolderSharp />} title="Create new Warehouse" onClick={handleCreateNewWarehouse} />
                                }
                                secondOption={
                                        <MenuOptionItem icon={<ArchiveOutlined />} title="Display Warehouse Archive" onClick={() => {
                                                navigate('/ArchiveWarehousePage');
                                        }} />
                                }
                        />
                        <MDBox sx={{ py: 1 }} />
                        <Box sx={{
                                p: 2,
                                backgroundColor: colors.white.main,
                                borderRadius: '10px'
                        }}>
                                <TabsOption
                                        isEmployee={false}
                                        value={statusWarehouse}
                                        handleChangeStatus={handleChangeStatusWarehouse}
                                />

                                {loading ? <LoaderCard /> :
                                        error ? <ErrorCard /> :
                                                data.length === 0 ? <EmptyCard /> : (
                                                        <Grid container spacing={6} sx={{ p: 1 }}>
                                                                {data
                                                                        .filter(warehouse => warehouse.status === 'active')
                                                                        .filter(warehouse => statusWarehouse === 0 ? warehouse.type === 'accepted' : warehouse.type === 'pending')
                                                                        .map(warehouse => (
                                                                                <Grid key={warehouse.id} item xs={12} md={6} xl={3}>
                                                                                        <WarehouseCard
                                                                                                isContnetAction={true}
                                                                                                image={`https://prime-shippa-api.point-dev.net/storage/${warehouse.image.replace('public/', '')}`}
                                                                                                label={`warehouse #${warehouse.id}`}
                                                                                                title={warehouse.name}
                                                                                                status={warehouse.status}
                                                                                                description={`Public warehouse capacity is estimated at: ${warehouse.capacity}, Empty: ${warehouse.empty}, and Location of this warehouse is: ${warehouse.address}`}
                                                                                                capacity={warehouse.capacity}
                                                                                                empty={warehouse.empty}
                                                                                                onClick={(event) => handleOnClick(event, warehouse.id)}
                                                                                                action={{
                                                                                                        type: "internal",
                                                                                                        color: "info",
                                                                                                        label: "More Options",
                                                                                                }}
                                                                                        />
                                                                                </Grid>
                                                                        ))}
                                                        </Grid>
                                                )}
                        </Box>

                        <Menu
                                anchorEl={openMenu}
                                open={Boolean(openMenu)}
                                onClose={handleCloseMenu}
                                anchorOrigin={{
                                        vertical: "bottom",
                                        horizontal: "left",
                                }}
                                sx={{ mt: 1 }}
                        >
                                <MenuOptionItem
                                        icon={<DownloadOutlined />}
                                        title="Download Warehosue Document"
                                        onClick={handleDownloadDocumentWarehouse}
                                />
                                <MenuOptionItem
                                        icon={<EditRounded />}
                                        title="Modify Warehouse Information"
                                        onClick={() => {
                                                const warehouse = data.find(warehouse => warehouse.id === warehouseID);
                                                handleEditWarehouse(true, warehouse);
                                        }}
                                />
                                <MenuOptionItem
                                        icon={<DeleteRounded />}
                                        title={`Delete Warehouse #${warehouseID}`}
                                        onClick={handleDeleteWarehouse}
                                />
                        </Menu>
                        <MainDialog
                                isDialogOpen={isOpenDialog}
                                DialogClose={() => setIsOpenDialog(false)}
                                headTitle={'Remove Warehouse From Branch'}
                                subTitle={"Are You Sure From Remove Warehouse?"}
                                confirmEvent={handleDeleteWarehouseConfirm}
                        />
                </DashboardLayout>
        );
};

export default WarehousesPage;
