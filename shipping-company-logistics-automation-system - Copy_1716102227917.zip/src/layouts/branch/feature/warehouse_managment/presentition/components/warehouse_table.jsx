import { IconButton } from "@mui/material";
import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import { DownloadRounded } from "@mui/icons-material";
import MDButton from "../../../../../../items/MDButton";
import { useDispatch } from "react-redux";
import { downloadDocumentWarehouseService } from "../../services/download_document_warehouse_service";

export default function WarehouseTable(warehouseData, handleReWorked) {
        const dispatch = useDispatch();

        if (!warehouseData || !Array.isArray(warehouseData) || warehouseData.length === 0) {
                return { columns: [], rows: [] };
        }

        const filteredData =
                warehouseData.filter(warehouse => warehouse.status === "inActive")

        const rows = filteredData.map(warehouse => {
                return {
                        warehouseName: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {warehouse.name}
                                </MDTypography>
                        ),
                        Address: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {warehouse.address}
                                </MDTypography>
                        ),
                        Capacity: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {warehouse.capacity}
                                </MDTypography>
                        ),
                        Email: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {warehouse.email}
                                </MDTypography>
                        ),
                        PhoneNumber: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {warehouse.phone_number}
                                </MDTypography>
                        ),
                        Property: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {warehouse.Property}
                                </MDTypography>
                        ),
                        status: (
                                <MDTypography component="a" href="#" variant="caption"fontWeight="medium" sx={{color:colors.error.main}}>
                                        {warehouse.status}
                                </MDTypography>
                        ),
                        CV: (
                                <IconButton>
                                        <DownloadRounded sx={{ color: colors.info.main }}
                                                onClick={() => {
                                                        dispatch(downloadDocumentWarehouseService({ warehouse_id: warehouse.id }))
                                                }}
                                        />
                                </IconButton>
                        ),
                        Employement: (
                                <MDBox sx={{ display: 'flex' }} >
                                        <MDButton onClick={() => handleReWorked(warehouse.id)}
                                                variant="caption" fontWeight="medium" sx={{ color: colors.success.main }}>
                                                Get Back To Work
                                        </MDButton>
                                        <MDBox sx={{ pl: 1 }} />
                                </MDBox>
                        ),
                };
        }).filter(Boolean);

        return {
                columns: [
                        { Header: "Warehouse Name", accessor: "warehouseName", align: "center" },
                        { Header: "Address", accessor: "Address", align: "center" },
                        { Header: "Capacity", accessor: "Capacity", align: "center" },
                        { Header: "Email", accessor: "Email", align: "center" },
                        { Header: "Phone Number", accessor: "PhoneNumber", align: "center" },
                        { Header: "Property", accessor: "Property", align: "center" },
                        { Header: "Status", accessor: "status", align: "center" },
                        { Header: "CV", accessor: "CV", align: "center" },
                        { Header: "Employement", accessor: "Employement", align: "center" },
                ],

                rows: rows
        };
}
