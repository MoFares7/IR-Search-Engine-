import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const deleteWarehouseService = createAsyncThunk(
        'warehouse/delete',
        async ({ warehouseID }, { rejectWithValue }) => {
                try {
                        const response = await api.delete(`warehouse/delete/${warehouseID}`);
                        console.log("deleteWarehouseService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const deleteWarehouseSlice = createSlice({
        name: 'deleteWarehouseService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(deleteWarehouseService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(deleteWarehouseService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(deleteWarehouseService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default deleteWarehouseSlice.reducer;
