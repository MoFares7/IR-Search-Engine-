import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const createWarehouseBranch = createAsyncThunk(
        'category/store',
        async ({ payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`warehouse/store`, payload);
                        console.log("createWarehouseBranch success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const createWarehouseBranchSlice = createSlice({
        name: 'createWarehouseBranch',
        initialState: {
                data: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(createWarehouseBranch.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(createWarehouseBranch.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(createWarehouseBranch.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default createWarehouseBranchSlice.reducer;
