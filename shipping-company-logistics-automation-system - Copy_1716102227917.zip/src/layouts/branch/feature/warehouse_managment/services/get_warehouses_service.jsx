import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const getWarehousesBranch = createAsyncThunk(
        'branch/getWarehouses',
        async () => {
                try {
                        const response = await api.get(`warehouse/index`);
                        return response.data;
                } catch (error) {
                        throw Error(error.response.message);
                }
        }
);

const getWarehousesSlice = createSlice({
        name: 'getWarehousesBranch',
        initialState: {
                data: [],
                error: null,
                loading: false,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getWarehousesBranch.pending, (state) => {
                                state.loading = true;
                                state.error = null;
                        })
                        .addCase(getWarehousesBranch.fulfilled, (state, action) => {
                                state.loading = false;
                                state.data = action.payload;
                        })
                        .addCase(getWarehousesBranch.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getWarehousesSlice.reducer;