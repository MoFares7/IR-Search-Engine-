import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const changeStatusWarehouseService = createAsyncThunk(
        'warehouse/changeStatus',
        async ({ warehouseID }, { rejectWithValue }) => {
                try {
                        const response = await api.get(`warehouse/changeStatus/${warehouseID}`);
                        console.log("change Status Warehouse Service success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const changeStatusWarehouseServiceSelice = createSlice({
        name: 'changeStatusWarehouseService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(changeStatusWarehouseService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(changeStatusWarehouseService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(changeStatusWarehouseService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default changeStatusWarehouseServiceSelice.reducer;
