import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx';

export const getEmployeesArchiveService = createAsyncThunk(
        'employee/receptions',
        async () => {
                const response = await api.get(`employee/getUserDismissal`);
                console.log("response Reception employee: " + response.data);
                return response.data;
        }
);

const getEmployeesArchiveServiceSlice = createSlice({
        name: 'getEmployeesArchiveService',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getEmployeesArchiveService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getEmployeesArchiveService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(getEmployeesArchiveService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getEmployeesArchiveServiceSlice.reducer;
