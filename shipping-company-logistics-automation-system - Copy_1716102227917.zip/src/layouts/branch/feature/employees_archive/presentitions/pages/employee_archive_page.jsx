import React, { useEffect, useState } from 'react';
import DashboardLayout from './../../../../../../components/LayoutContainers/DashboardLayout/index';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import { Card, Grid } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MDTypography from '../../../../../../items/MDTypography';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import ErrorCard from '../../../../../../components/handleState/error_card';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import DataTable from '../../../../../../components/Tables';
import EmployeesArchiveTable from '../components/employee_archive_table';
import { useDispatch, useSelector } from 'react-redux';
import { getEmployeesArchiveService } from '../../services/get_employees_archive_service';
import TabsOption from '../../../../../../items/MDTabs/tabs_option';
import ReEmployementDialog from '../../../../../../components/Dialog/re_employement_dialog';

const EmployeeArchivePage = () => {
        const dispatch = useDispatch();
        const [statusEmployee, setStatusEmployee] = useState(0);
        const [isReEmployementDialog, setIsReEmployementDialog] = useState(false);
        const [employeeID, setEmployeeID] = useState('');

        useEffect(() => {
                dispatch(getEmployeesArchiveService());
        }, [dispatch]);

        const employeeArchiveData = useSelector(status => status.getEmployeesArchiveService.data);
        const employeeArchiveLoading = useSelector(status => status.getEmployeesArchiveService.loading);

        const handleChangeStatusEmployee = (event, newStatusEmployee) => {
                setStatusEmployee(newStatusEmployee);
        };

        const handleReEmployement = async (employeeID) => {
                setIsReEmployementDialog(true);
                setEmployeeID(employeeID)
        }

        const { columns, rows } = EmployeesArchiveTable(employeeArchiveData, statusEmployee, handleReEmployement);

        return (
                <DashboardLayout>
                        <DashboardNavbar />
                        <TabsOption
                                isEmployee={true}
                                value={statusEmployee}
                                handleChangeStatus={handleChangeStatusEmployee}
                        />
                        <Grid container spacing={6} pt={5}>
                                <Grid item xs={12}>
                                        <Card>
                                                <MDBox
                                                        display="flex"
                                                        justifyContent="space-between"
                                                        mx={2}
                                                        mt={-3}
                                                        py={3}
                                                        px={2}
                                                        variant="gradient"
                                                        bgColor="info"
                                                        borderRadius="lg"
                                                        coloredShadow="info"
                                                >
                                                        <MDTypography variant="h6" color="white">
                                                                Employees Archive
                                                        </MDTypography>
                                                </MDBox>
                                                <MDBox pt={2}>
                                                        {employeeArchiveLoading ? (
                                                                <LoaderCard />
                                                        ) : employeeArchiveData.length === 0 ? (
                                                                <EmptyCard />
                                                        ) : (
                                                                <DataTable
                                                                        table={{ columns, rows }}
                                                                        isSorted={false}
                                                                        entriesPerPage={false}
                                                                        showTotalEntries={false}
                                                                        noEndBorder
                                                                />
                                                        )}
                                                </MDBox>
                                        </Card>
                                </Grid>
                        </Grid>

                        <ReEmployementDialog
                                isDialogOpen={isReEmployementDialog}
                                DialogClose={() => setIsReEmployementDialog(false)}
                                isManager={false}
                                headTitle={"Re Employenemt For Dismissal The Employee "}
                                employeeID={employeeID}
                        />

                </DashboardLayout>
        );
};
export default EmployeeArchivePage;