import { IconButton } from "@mui/material";
import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import { DownloadRounded } from "@mui/icons-material";
import MDButton from "../../../../../../items/MDButton";
import { useDispatch } from "react-redux";
import { downloadCvEmployeeService } from "../../../employee_managment/services/download_cv_employee_service";

export default function EmployeesArchiveTable(employeeArchiveData, statusEmployee, handleReEmployement) {
        const dispatch = useDispatch();

        if (!employeeArchiveData || !Array.isArray(employeeArchiveData) || employeeArchiveData.length === 0) {
                return { columns: [], rows: [] };
        }

        const filteredData = statusEmployee === 0 ?
                employeeArchiveData.filter(employee => employee.type === "Warehouse_supervisor") :
                statusEmployee === 1 ?
                        employeeArchiveData.filter(employee => employee.type === "receptionist") :
                        employeeArchiveData.filter(employee => employee.type === "driver")

        const rows = filteredData.map(employee => {
                return {
                        EmployeeName: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.username}
                                </MDTypography>
                        ),
                        FatherName: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.father_name}
                                </MDTypography>
                        ),
                        MotherName: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.mother_name}
                                </MDTypography>
                        ),
                        BrithDate: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.bitrh_date}
                                </MDTypography>
                        ),
                        Email: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.email}
                                </MDTypography>
                        ),
                        PhoneNumber: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.phone_number}
                                </MDTypography>
                        ),
                        Address: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.address}
                                </MDTypography>
                        ),
                        Gender: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.gender}
                                </MDTypography>
                        ),
                        Nationality: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.nationality}
                                </MDTypography>
                        ),
                        NationalNumber: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.id_number}
                                </MDTypography>
                        ),
                        Degree: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.degree}
                                </MDTypography>
                        ),
                        Salary: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {employee.salary}
                                </MDTypography>
                        ),
                        CV: (
                                <IconButton>
                                        <DownloadRounded sx={{ color: colors.info.main }}
                                                onClick={() => {
                                                        dispatch(downloadCvEmployeeService({ user_id: employee.id }))
                                                }}
                                        />
                                </IconButton>
                        ),
                        Employement: (
                                <MDBox sx={{ display: 'flex' }} >
                                        <MDButton onClick={() => handleReEmployement(employee.id, employee.type)}
                                                variant="caption" fontWeight="medium" sx={{ color: colors.error.main }}>
                                                Re Employment
                                        </MDButton>
                                        <MDBox sx={{ pl: 1 }} />
                                </MDBox>
                        ),
                };
        }).filter(Boolean);

        return {
                columns: [
                        { Header: "Empolyee Name", accessor: "EmployeeName", align: "center" },
                        { Header: "Father Name", accessor: "FatherName", align: "center" },
                        { Header: "Mother Name", accessor: "MotherName", align: "center" },
                        { Header: "Brith Date", accessor: "BrithDate", align: "center" },
                        { Header: "Email", accessor: "Email", align: "center" },
                        { Header: "Phone Number", accessor: "PhoneNumber", align: "center" },
                        { Header: "Address", accessor: "Address", align: "center" },
                        { Header: "Gender", accessor: "Gender", align: "center" },
                        { Header: "Nationality", accessor: "Nationality", align: "center" },
                        { Header: "National Number", accessor: "NationalNumber", align: "center" },
                        { Header: "Degree Education", accessor: "Degree", align: "center" },
                        { Header: "Salary", accessor: "Salary", align: "center" },
                        { Header: "CV", accessor: "CV", align: "center" },
                        { Header: "Employement", accessor: "Employement", align: "center" },
                ],

                rows: rows
        };
}
