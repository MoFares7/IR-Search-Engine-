import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

const BASE_URL = 'https://prime-shippa-api.point-dev.net/api/';

export const getTruckBranch = createAsyncThunk(
        'truck/getTruckBranch',
        async () => {
                const response = await api.get(`truck/index`);
                console.log("response truck branch:", JSON.stringify(response.data));
                return response.data;
        }
);
const trucksBranchSlice = createSlice({
        name: 'getTrucksBranch',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getTruckBranch.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getTruckBranch.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(getTruckBranch.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});
export default trucksBranchSlice.reducer;
