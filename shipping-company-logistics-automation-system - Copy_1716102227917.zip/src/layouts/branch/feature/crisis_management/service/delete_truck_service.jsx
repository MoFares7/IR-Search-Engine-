import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const deleteTruckService = createAsyncThunk(
        'trueck/delete',
        async ({ truckID }, { rejectWithValue }) => {
                try {
                        const response = await api.delete(`truck/delete/${truckID}`);
                        console.log("deleteTruckService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const deleteWarehouseSlice = createSlice({
        name: 'deleteTruckService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(deleteTruckService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(deleteTruckService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(deleteTruckService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default deleteWarehouseSlice.reducer;
