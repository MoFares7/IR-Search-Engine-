import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const downloadDocumentTruckService = createAsyncThunk(
        'truck/downloadFile',
        async ({ id }, { rejectWithValue }) => {
                try {
                        const response = await api.get(`truck/downloadFile/${id}`, {
                                responseType: 'blob',
                           
                        });

                        const blob = new Blob([response.data], { type: response.headers['content-type'] });

                        const link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);

                        if (response.headers['content-disposition']) {
                                link.download = response.headers['content-disposition'].split('filename=')[1];
                        } else {
                                link.download = 'downloaded_file';
                        }

                        document.body.appendChild(link);
                        link.click();

                        document.body.removeChild(link);

                        return { success: true };
                }
                catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }


);

const downloadBranchFileSlice = createSlice({
        name: 'downloadDocumentTruckService',
        initialState: {
                fileUrl: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(downloadDocumentTruckService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(downloadDocumentTruckService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.fileUrl = action.payload; // Store the Blob URL
                        })
                        .addCase(downloadDocumentTruckService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default downloadBranchFileSlice.reducer;
