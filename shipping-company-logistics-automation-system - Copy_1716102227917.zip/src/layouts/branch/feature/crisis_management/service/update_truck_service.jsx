import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const updateTruckInfoService = createAsyncThunk(
        'user/updatePricing',
        async ({ truckID, payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`truck/update/${truckID}`, payload);

                        console.log("updateTruckInfoService success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);


const updateWarehouseSlice = createSlice({
        name: 'updateTruckInfoService',
        initialState: {
                user: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(updateTruckInfoService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(updateTruckInfoService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(updateTruckInfoService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default updateWarehouseSlice.reducer;
