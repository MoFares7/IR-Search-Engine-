import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api.jsx'

export const changeStatusTruckService = createAsyncThunk(
        'truck/changeStatus',
        async ({ truckID }, { rejectWithValue }) => {
                try {
                        const response = await api.get(`truck/changeStatus/${truckID}`);
                        console.log("change Status truck Service success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);

const changeStatusTruckServiceSelice = createSlice({
        name: 'changeStatusTruckService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(changeStatusTruckService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(changeStatusTruckService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.user = action.payload.user;
                        })
                        .addCase(changeStatusTruckService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default changeStatusTruckServiceSelice.reducer;
