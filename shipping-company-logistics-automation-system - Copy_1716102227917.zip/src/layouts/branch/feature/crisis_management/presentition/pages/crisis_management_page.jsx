import React, { useEffect, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar'
import DefaultProjectCard from '../../../../../../components/Cards/ProjectCards'
import { Grid, Menu } from '@mui/material'
import man from "../../../../assets/images/man.avif";
import Header from '../components/header'
import MenuOptionItem from '../../../../../../components/Items/NotificationItem'
import { Add, ArchiveOutlined, DeleteRounded, DownloadOutlined, EditRounded } from '@mui/icons-material'
import AddTruckDialog from '../components/add_truck_dialog'
import { useDispatch, useSelector } from 'react-redux'
import { getTruckBranch } from './../../service/get_track_service';
import MDBox from '../../../../../../items/MDBox/MDBox'
import EmptyCard from '../../../../../../components/handleState/empty_card'
import colors from '../../../../../../assets/theme/base/colors'
import TabsOption from '../../../../../../items/MDTabs/tabs_option';
import { downloadDocumentTruckService } from '../../service/download_document_truck_service';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import { useNavigate } from 'react-router-dom';
import { changeStatusTruckService } from '../../service/change_status_service';
import MainDialog from '../../../../../../components/Dialog/main_dialog';

const CrisisManagementPage = () => {
        const dispatch = useDispatch();
        const navigate = useNavigate()
        const [openMenu, setOpenMenu] = useState(null);
        const [truckID, setTruckID] = useState(null);
        const [isDialogAddTruckOpen, setIsDialogAddTruckOpen] = useState(false);
        const [selectedTruck, setSelectedTruck] = useState(null);
        const [isUpdateInfoTruck, setIsUpdateInfoTruck] = useState(false);
        const [statusTruck, setStatusTruck] = useState(0);
        const [isDialogRemoveTruckOpen, setIsDialogRemoveTruckOpen] = useState(false);

        const { loading, error } = useSelector(state => state.getTrucksBranch);
        const { loadingDownloadDocs, errorDownloadDocs } = useSelector(state => state.downloadDocumentTruckService);
        const trucks = useSelector(state => state.getTrucksBranch.data);
        const truckName = trucks.find(truck => truck.id === truckID)?.car_number;

        useEffect(() => {
                dispatch(getTruckBranch());
        }, [dispatch]);

        const handleAddTruck = () => {
                setIsUpdateInfoTruck(false);
                setIsDialogAddTruckOpen(true);
        }

        const handleOnClick = (event, truckID) => {
                setTruckID(truckID);
                setOpenMenu(event.currentTarget);
        };


        const handleCloseMenu = () => {
                setOpenMenu(null);
        };

        const handleDownloadDocumentTruck = async () => {
                console.log(truckID);
                const res = await dispatch(downloadDocumentTruckService({ id: truckID }));
        }

        const handleEditTruck = () => {
                const truck = trucks.find(truck => truck.id === truckID);
                console.log("Selected Truck Object:", truck);
                setSelectedTruck(truck);
                setIsDialogAddTruckOpen(true);
                setIsUpdateInfoTruck(true);
                handleCloseMenu();
        };

        const handleDeleteTruck = async () => {
                setIsDialogRemoveTruckOpen(true)
                setTruckID(truckID);
        };

        const handleDeleteTruckConfirm = async () => {
                console.log("Deleting truck with ID:", truckID);
                const response = await dispatch(changeStatusTruckService({ truckID }));
                if (response.payload.status === 'success') {
                        dispatch(getTruckBranch());
                }
        };

        const handleChangeStatusTrucks = (event, newStatusTruck) => {
                setStatusTruck(newStatusTruck);
                console.log("status: " + statusTruck);
        };

        return (
                <DashboardLayout>
                        <DashboardNavbar
                                firstOption={<MenuOptionItem icon={<Add />} title="Add Truck" onClick={handleAddTruck} />}
                                secondOption={<MenuOptionItem icon={<ArchiveOutlined />} title="Display Truck Archive" onClick={() => {
                                        navigate('/CrisisArchive')
                                }} />}
                        />
                        <Header>
                                <MDBox sx={{ p: 2, backgroundColor: colors.white.main, borderRadius: '10px' }}>
                                        <MDBox sx={{ pb: 2, backgroundColor: colors.white.main, borderRadius: '10px' }}>
                                                <TabsOption
                                                        isEmployee={false}
                                                        value={statusTruck}
                                                        handleChangeStatus={handleChangeStatusTrucks} />

                                                {loading ? (
                                                        <LoaderCard />
                                                ) : (
                                                        trucks.length === 0 ? (
                                                                <EmptyCard />
                                                        ) : (
                                                                <Grid container spacing={6} sx={{ pt: 1.5 }}>
                                                                        {trucks.filter(item => statusTruck === 0 ? item.type !== 'pending' : item.type === 'pending')
                                                                                .map(truck => (
                                                                                        <Grid key={truck.id} item xs={12} md={6} xl={3}>
                                                                                                <DefaultProjectCard
                                                                                                        image={`https://prime-shippa-api.point-dev.net/storage/${truck.image.replace('public/', '')}`}
                                                                                                        label={truck.car_number}
                                                                                                        title={truck.name}
                                                                                                        document={truck.document}
                                                                                                        description={"Truck capacity in container is equal to " + truck.capacity}
                                                                                                        onClick={(event) => handleOnClick(event, truck.id)}
                                                                                                        action={{
                                                                                                                type: "internal",
                                                                                                                color: "info",
                                                                                                                label: "More Options",
                                                                                                        }}
                                                                                                        // authors={[{ image: man, name: "Nick Daniel" }]}
                                                                                                />
                                                                                        </Grid>
                                                                                ))}
                                                                </Grid>
                                                        )
                                                )}

                                        </MDBox>


                                </MDBox>
                        </Header>

                        <AddTruckDialog
                                isDialogOpen={isDialogAddTruckOpen}
                                onCloseDialog={() => {
                                        setIsDialogAddTruckOpen(false);
                                        setSelectedTruck(null);
                                }}
                                selectedTruck={selectedTruck}
                                isUpdateInfoTruck={isUpdateInfoTruck}
                        />

                        <Menu
                                anchorEl={openMenu}
                                open={Boolean(openMenu)}
                                onClose={handleCloseMenu}
                                anchorOrigin={{
                                        vertical: "bottom",
                                        horizontal: "left",
                                }}
                                sx={{ mt: 1 }}
                        >
                                <MenuOptionItem
                                        icon={<DownloadOutlined />}
                                        title={loadingDownloadDocs ? "Downloading..." : "Download Document"}
                                        onClick={handleDownloadDocumentTruck}
                                />
                                <MenuOptionItem
                                        icon={<EditRounded />}
                                        title="Modify Truck Information"
                                        onClick={handleEditTruck}
                                />
                                <MenuOptionItem
                                        icon={<DeleteRounded />}
                                        title={`Delete Truck #${truckName}`}
                                        onClick={handleDeleteTruck} />
                        </Menu>

                        <MainDialog
                                isDialogOpen={isDialogRemoveTruckOpen}
                                DialogClose={() => { setIsDialogRemoveTruckOpen(false) }}
                                headTitle={'Remove Truck From This Branch'}
                                subTitle={'Are You Sure From Delete This Truck ?'}
                                confirmEvent={handleDeleteTruckConfirm}
                        />
                </DashboardLayout>
        )
}

export default CrisisManagementPage;
