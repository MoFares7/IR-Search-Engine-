import React, { useEffect, useState } from 'react'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import { Card, Grid } from '@mui/material'
import MDBox from '../../../../../../items/MDBox/MDBox'
import MDTypography from '../../../../../../items/MDTypography'
import LoaderCard from '../../../../../../components/handleState/loader_card'
import EmptyCard from '../../../../../../components/handleState/empty_card'
import DataTable from '../../../../../../components/Tables'
import { useDispatch, useSelector } from 'react-redux'
import MainDialog from './../../../../../../components/Dialog/main_dialog';
import { useNavigate } from 'react-router-dom'
import { getTruckBranch } from '../../service/get_track_service'
import { changeStatusTruckService } from '../../service/change_status_service'
import TrucksArchivrTable from '../components/trucks_archive_table'

const CrisisArchivePage = () => {
        const dispatch = useDispatch();
        const navigator = useNavigate();

        const [isReWorkDialog, setIsReWorkDialog] = useState(false);
        const [truckID, setTruckID] = useState('');

        useEffect(() => {
                dispatch(getTruckBranch());
        }, [dispatch]);

        const truckData = useSelector(status => status.getTrucksBranch.data);
        const truckLoading = useSelector(status => status.getTrucksBranch.loading);
        const changeStatusTruckLoading = useSelector(state => state.changeStatusTruckService.loading);

        const handleReWorked = async (truckID) => {
                setIsReWorkDialog(true)
                setTruckID(truckID)
                console.log('this truck id: ' + truckID);
        }

        const handleReWorkedConfirm = async () => {
                const response = await dispatch(changeStatusTruckService({ truckID }));
                if (response.payload.status === 'success') {
                        navigator('/Crisis-of-management');
                        dispatch(getTruckBranch());

                }
        }

        const { columns, rows } = TrucksArchivrTable(truckData, handleReWorked);
       
        return (
                <DashboardLayout>
                        <Grid container spacing={6} pt={5}>
                                <Grid item xs={12}>
                                        <Card>
                                                <MDBox
                                                        display="flex"
                                                        justifyContent="space-between"
                                                        mx={2}
                                                        mt={-3}
                                                        py={3}
                                                        px={2}
                                                        variant="gradient"
                                                        bgColor="info"
                                                        borderRadius="lg"
                                                        coloredShadow="info"
                                                >
                                                        <MDTypography variant="h6" color="white">
                                                                Trucks Archive
                                                        </MDTypography>
                                                </MDBox>
                                                <MDBox pt={2}>
                                                        {truckLoading ? (
                                                                <LoaderCard />
                                                        ) : truckData.length === 0 ? (
                                                                <EmptyCard />
                                                        ) : (
                                                                <DataTable
                                                                        table={{ columns, rows }}
                                                                        isSorted={false}
                                                                        entriesPerPage={false}
                                                                        showTotalEntries={false}
                                                                        noEndBorder
                                                                />
                                                        )}
                                                </MDBox>
                                        </Card>
                                </Grid>
                        </Grid>

                        <MainDialog
                                isDialogOpen={isReWorkDialog}
                                DialogClose={() => setIsReWorkDialog(false)}
                                headTitle={'Return Warehouse To Work'}
                                subTitle={'Are you sure from return this warehouse to work in your branch ?'}
                                loadingState={changeStatusTruckLoading}
                                confirmEvent={handleReWorkedConfirm}
                        />
                </DashboardLayout>
        )
}

export default CrisisArchivePage
