import { IconButton } from "@mui/material";
import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import { DownloadRounded } from "@mui/icons-material";
import MDButton from "../../../../../../items/MDButton";
import { useDispatch } from "react-redux";
import { downloadDocumentTruckService } from "../../service/download_document_truck_service";

export default function TrucksArchivrTable(truckData, handleReWorked) {
        const dispatch = useDispatch();

        if (!truckData || !Array.isArray(truckData) || truckData.length === 0) {
                return { columns: [], rows: [] };
        }

        const filteredData =
                truckData.filter(truck => truck.status === "inActive")

        const rows = filteredData.map(truck => {
                return {
                        TruckName: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {truck.name}
                                </MDTypography>
                        ),
                        Address: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {truck.address}
                                </MDTypography>
                        ),
                        Capacity: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {truck.capacity}
                                </MDTypography>
                        ),
                        CarNumber: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {truck.car_number}
                                </MDTypography>
                        ),
                        cost: (
                                <MDTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
                                        {truck.cost}
                                </MDTypography>
                        ),
                        status: (
                                <MDTypography component="a" href="#" variant="caption" fontWeight="medium" sx={{ color: colors.error.main }}>
                                        {truck.status}
                                </MDTypography>
                        ),
                        CV: (
                                <IconButton>
                                        <DownloadRounded sx={{ color: colors.info.main }}
                                                onClick={() => {
                                                        dispatch(downloadDocumentTruckService({ truck_id: truck.id }))
                                                }}
                                        />
                                </IconButton>
                        ),
                        Employement: (
                                <MDBox sx={{ display: 'flex' }} >
                                        <MDButton onClick={() => handleReWorked(truck.id)}
                                                variant="caption" fontWeight="medium" sx={{ color: colors.success.main }}>
                                                Get Back To Work
                                        </MDButton>
                                        <MDBox sx={{ pl: 1 }} />
                                </MDBox>
                        ),
                };
        }).filter(Boolean);

        return {
                columns: [
                        { Header: "Truck Name", accessor: "TruckName", align: "center" },
                        { Header: "Truck Number", accessor: "CarNumber", align: "center" },
                        { Header: "Address", accessor: "Address", align: "center" },
                        { Header: "Capacity", accessor: "Capacity", align: "center" },
                        { Header: "Cost", accessor: "cost", align: "center" },
                        { Header: "Status", accessor: "status", align: "center" },
                        { Header: "CV", accessor: "CV", align: "center" },
                        { Header: "Employement", accessor: "Employement", align: "center" },
                ],

                rows: rows
        };
}
