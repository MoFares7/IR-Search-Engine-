import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api.jsx';

export const getReceptionEmployeeService = createAsyncThunk(
        'employee/receptions',
        async () => {
                const response = await api.get(`employee/receptions`);
                console.log("response Reception employee: " + response.data);
                return response.data;
        }
);

const getReceptionEmployeeServiceSlice = createSlice({
        name: 'getReceptionEmployeeService',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getReceptionEmployeeService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getReceptionEmployeeService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(getReceptionEmployeeService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getReceptionEmployeeServiceSlice.reducer;
