import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api';

export const updateEmployeeService = createAsyncThunk(
        'employee/update',
        async ({ employeeID, payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`employee/update/${employeeID}`, payload);

                        console.log("updateEmployeeService success: ", response);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);


const updateEmployeeServiceSlice = createSlice({
        name: 'updateEmployeeService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(updateEmployeeService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(updateEmployeeService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.status = action.payload.status;
                        })
                        .addCase(updateEmployeeService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload.error;
                        });
        },
});

export default updateEmployeeServiceSlice.reducer;
