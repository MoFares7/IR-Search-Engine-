import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api.jsx';

export const getDriverEmployeeService = createAsyncThunk(
        'employee/drivers',
        async () => {
                const response = await api.get(`employee/drivers`);
                console.log("response managers branches: " + response.data);
                return response.data;
        }
);

const getDriverEmployeeServiceSlice = createSlice({
        name: 'getDriverEmployeeService',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getDriverEmployeeService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getDriverEmployeeService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload.data;
                        })
                        .addCase(getDriverEmployeeService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getDriverEmployeeServiceSlice.reducer;
