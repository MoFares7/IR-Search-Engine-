import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../../core/network/api.jsx';

export const getWarehouseEmployeeService = createAsyncThunk(
        'employee/warehouses',
        async () => {
                const response = await api.get(`employee/warehouses`);
                console.log("Employee warehouse managers response: " + response);
                return response.data;
        }
);

const getWarehouseEmployeeServiceSlice = createSlice({
        name: 'getWarehouseEmployeeService',
        initialState: {
                data: [],
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(getWarehouseEmployeeService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(getWarehouseEmployeeService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.data = action.payload;
                        })
                        .addCase(getWarehouseEmployeeService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.error.message;
                        });
        },
});

export default getWarehouseEmployeeServiceSlice.reducer;
