import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../../../../core/network/api';

export const reEmployementService = createAsyncThunk(
        'employee/employment',
        async ({ userId, payload }, { rejectWithValue }) => {
                try {
                        const response = await api.post(`employee/employment/${userId}`, payload);
                        console.log("Re Employement Service success: ", response.data);

                        return response.data;
                } catch (error) {
                        if (error.response) {
                                console.log("Detailed error response: ", error.response.data);
                                return rejectWithValue(error.response.data);
                        } else if (error.request) {
                                throw { error: "Can't connect with the server. Please check your network connection." };
                        } else {
                                throw { error: "Error setting up the request." };
                        }
                }
        }
);


const createBrnchSlice = createSlice({
        name: 'reEmployementService',
        initialState: {
                status: null,
                loading: false,
                error: null,
        },
        reducers: {},
        extraReducers: (builder) => {
                builder
                        .addCase(reEmployementService.pending, (state) => {
                                state.loading = true;
                        })
                        .addCase(reEmployementService.fulfilled, (state, action) => {
                                state.loading = false;
                                state.error = null;
                                state.status = action.payload.status;
                        })
                        .addCase(reEmployementService.rejected, (state, action) => {
                                state.loading = false;
                                state.error = action.payload;
                        });
        },
});

export default createBrnchSlice.reducer;
