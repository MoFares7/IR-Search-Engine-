import React, { useEffect, useState } from 'react';
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout';
import DashboardNavbar from '../../../../../../components/Navbars/DashboardNavbar';
import { Card, Grid, Snackbar } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import DataTable from '../../../../../../components/Tables';
import employeesTableData from '../components/employees_table';
import { AddBusinessRounded } from '@mui/icons-material';
import MenuOptionItem from '../../../../../../components/Items/NotificationItem';
import { useDispatch, useSelector } from 'react-redux';
import LoaderCard from '../../../../../../components/handleState/loader_card';
import TabsOption from '../../../../../../items/MDTabs/tabs_option';
import EmptyCard from '../../../../../../components/handleState/empty_card';
import EquivalentDisoundDialog from '../components/equivalent_discound_dialog';
import { deleteBranchManager } from '../../../../../manager/feature/branches_manage/services/delete_branch_manager';
import MainDialog from '../../../../../../components/Dialog/main_dialog';
import MDTypography from '../../../../../../items/MDTypography';
import { getReceptionEmployeeService } from '../../services/reception_employee_service/get_reseption_emp_Service';
import { getWarehouseEmployeeService } from '../../services/warehouse_employee_service/get_warehouse_emp_service';
import { getDriverEmployeeService } from '../../services/driver_employee_service/get_driver_emp_service';

const EmployeesInsideBranchPage = () => {
        const dispatch = useDispatch();
        const [isDeleteManagerDialog, setIsDeleteManagerDialog] = useState(false);
        const [statusEmployee, setStatusEmployee] = useState(0);
        const [warehouseEmp, setWarehouseEmp] = useState(false);
        const [receptionEmp, setReceptionEmp] = useState(false);
        const [driverEmp, setDriverEmp] = useState(false);
        const [managerID, setManagerID] = useState('');
        const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
        const [percentType, setPercentType] = useState('');
        const [isDialogAddEquivalentDiscountOpen, setIsDialogAddEquivalentDiscountOpen] = useState(false);
        const [errorSnackbarOpen, setErrorSnackbarOpen] = useState(false);
        const [errorMessage, setErrorMessage] = useState('');

        const handleCreateNewEmployeeInsideBranch = () => {
                window.location.href = '/create-new-employee';
        };

        const closeEquivalentDiscountDialog = () => {
                setIsDialogAddEquivalentDiscountOpen(false);
        };

        const handleEditEmployeeInformation = (isUpdateInfoManager, employeeID, employeeInfo) => {
                isUpdateInfoManager = true;
                const queryParams = new URLSearchParams({
                        isUpdateInfoManager: isUpdateInfoManager,
                        employeeID: employeeID,
                        ...employeeInfo
                });

                window.location.href = `/create-new-employee?${queryParams.toString()}`;
        }

        const handleAddEquivalentDiscount = (employeeID, percentType) => {
                console.log("percentType: " + percentType)
                setSelectedEmployeeId(employeeID);
                setPercentType(percentType);
                setIsDialogAddEquivalentDiscountOpen(true);
        };

        const handleDeleteBranchEmployee = (managerID) => {
                setIsDeleteManagerDialog(true);
                setManagerID(managerID);
        }

        const handleDeleteConfirmation = async () => {
                try {
                        console.log("id: " + selectedEmployeeId)
                        const response = await dispatch(deleteBranchManager({ managerId: managerID }));
                        if (response.payload.status === "success") {
                                setIsDeleteManagerDialog(false);
                                dispatch(getReceptionEmployeeService());
                                dispatch(getWarehouseEmployeeService());
                                dispatch(getDriverEmployeeService());
                                setErrorMessage('The Branch Manager is Dissimal');
                                setErrorSnackbarOpen(true);
                        } else {
                                setIsDeleteManagerDialog(false);
                                setErrorMessage('An error occurred dissmial manager');
                                setErrorSnackbarOpen(true);
                        }
                } catch (error) {
                        console.error("Error:", error);
                        setIsDeleteManagerDialog(false);
                        setErrorMessage('An error occurred dissmial manager');
                        setErrorSnackbarOpen(true);
                }
        };

        const handleChangeStatusEmployee = (event, newStatusEmployee) => {
                setStatusEmployee(newStatusEmployee);
        };

        useEffect(() => {
                if (statusEmployee === 0) {
                        setWarehouseEmp(false);
                        setDriverEmp(false);
                        setReceptionEmp(true);
                        dispatch(getReceptionEmployeeService());
                } else if (statusEmployee === 1) {
                        setWarehouseEmp(true);
                        setReceptionEmp(false);
                        setDriverEmp(false);
                        dispatch(getWarehouseEmployeeService());
                } else if (statusEmployee === 2) {
                        setDriverEmp(true);
                        setWarehouseEmp(false);
                        setReceptionEmp(false);
                        dispatch(getDriverEmployeeService());
                }
        }, [statusEmployee, dispatch]);

        const { loading: receptionLoading, data: receptionData } = useSelector(state => state.getReceptionEmployeeService);
        const { loading: warehouseLoading, data: warehouseData } = useSelector(state => state.getWarehouseEmployeeService);
        const { loading: driverLoading, data: driverData } = useSelector(state => state.getDriverEmployeeService);

        const receptionTable = receptionData ? employeesTableData(receptionData, false,  handleEditEmployeeInformation, handleAddEquivalentDiscount, handleDeleteBranchEmployee) : { columns: [], rows: [] };
        const warehouseTable = warehouseData ? employeesTableData(warehouseData, true, handleEditEmployeeInformation, handleAddEquivalentDiscount, handleDeleteBranchEmployee) : { columns: [], rows: [] };
        const driverTable = driverData ? employeesTableData(driverData, false, handleEditEmployeeInformation, handleAddEquivalentDiscount, handleDeleteBranchEmployee) : { columns: [], rows: [] };

        return (
                <DashboardLayout>
                        <DashboardNavbar
                                firstOption={
                                        <MenuOptionItem icon={<AddBusinessRounded />} title="Create new Employee" onClick={handleCreateNewEmployeeInsideBranch} />
                                }
                        />

                        <TabsOption
                                isEmployee={true}
                                value={statusEmployee}
                                handleChangeStatus={handleChangeStatusEmployee}
                        />



                        {statusEmployee === 0 && receptionEmp && (
                                <Grid container spacing={6} pt={5}>
                                        <Grid item xs={12}>
                                                <Card>
                                                        <MDBox pt={2}>
                                                                <MDBox
                                                                        display="flex"
                                                                        justifyContent="space-between"
                                                                        mx={2}
                                                                        mt={-3}
                                                                        py={3}
                                                                        px={2}
                                                                        variant="gradient"
                                                                        bgColor="info"
                                                                        borderRadius="lg"
                                                                        coloredShadow="info"
                                                                >
                                                                        <MDTypography variant="h6" color="white">
                                                                                Reception Employees
                                                                        </MDTypography>
                                                                </MDBox>
                                                                {receptionLoading ? (
                                                                        <LoaderCard />
                                                                ) :
                                                                        receptionData.length === 0 ?
                                                                                <EmptyCard
                                                                                        message={'Not Found Any Employee'} />
                                                                                :
                                                                                (
                                                                                        <DataTable
                                                                                                table={{ columns: receptionTable.columns, rows: receptionTable.rows }}
                                                                                                isSorted={false}
                                                                                                entriesPerPage={false}
                                                                                                showTotalEntries={false}
                                                                                                noEndBorder
                                                                                        />
                                                                                )}
                                                        </MDBox>
                                                </Card>
                                        </Grid>
                                </Grid>
                        )}

                        {statusEmployee === 1 && warehouseEmp && (
                                <Grid container spacing={6} pt={5}>
                                        <Grid item xs={12}>
                                                <Card>
                                                        <MDBox pt={2}>
                                                                <MDBox
                                                                        display="flex"
                                                                        justifyContent="space-between"
                                                                        mx={2}
                                                                        mt={-3}
                                                                        py={3}
                                                                        px={2}
                                                                        variant="gradient"
                                                                        bgColor="info"
                                                                        borderRadius="lg"
                                                                        coloredShadow="info"
                                                                >
                                                                        <MDTypography variant="h6" color="white">
                                                                                Warehouse Employees
                                                                        </MDTypography>
                                                                </MDBox>
                                                                {warehouseLoading ? (
                                                                        <LoaderCard />
                                                                ) :
                                                                        warehouseData.length === 0
                                                                                ?
                                                                                <EmptyCard
                                                                                        message={'Not Found Any Employee'} />
                                                                                :
                                                                                (
                                                                                        <DataTable
                                                                                                table={{ columns: warehouseTable.columns, rows: warehouseTable.rows }}
                                                                                                isSorted={false}
                                                                                                entriesPerPage={false}
                                                                                                showTotalEntries={false}
                                                                                                noEndBorder
                                                                                        />
                                                                                )}
                                                        </MDBox>
                                                </Card>
                                        </Grid>
                                </Grid>
                        )}

                        {statusEmployee === 2 && driverEmp && (
                                <Grid container spacing={6} pt={5}>
                                        <Grid item xs={12}>
                                                <Card>
                                                        <MDBox pt={2}>
                                                                <MDBox
                                                                        display="flex"
                                                                        justifyContent="space-between"
                                                                        mx={2}
                                                                        mt={-3}
                                                                        py={3}
                                                                        px={2}
                                                                        variant="gradient"
                                                                        bgColor="info"
                                                                        borderRadius="lg"
                                                                        coloredShadow="info"
                                                                >
                                                                        <MDTypography variant="h6" color="white">
                                                                                Driver Employees
                                                                        </MDTypography>
                                                                </MDBox>
                                                                {driverLoading ? (
                                                                        <LoaderCard />
                                                                ) :
                                                                        driverData.length === 0 ?
                                                                                <EmptyCard
                                                                                        message={'Not Found Any Employee'} />
                                                                                :
                                                                                (
                                                                                        <DataTable
                                                                                                table={{ columns: driverTable.columns, rows: driverTable.rows }}
                                                                                                isSorted={false}
                                                                                                entriesPerPage={false}
                                                                                                showTotalEntries={false}
                                                                                                noEndBorder
                                                                                        />
                                                                                )}
                                                        </MDBox>
                                                </Card>
                                        </Grid>
                                </Grid>
                        )}

                        <MainDialog
                                isDialogOpen={isDeleteManagerDialog}
                                DialogClose={() => setIsDeleteManagerDialog(false)}
                                headTitle={"Dismissal this Employee "}
                                subTitle={"Are You Sure From Dismissal This Employee ?"}
                                // onClick={handleDeleteBranchManager}
                                confirmEvent={handleDeleteConfirmation}
                        />

                        <EquivalentDisoundDialog
                                isDialogOpen={isDialogAddEquivalentDiscountOpen}
                                onCloseDialog={closeEquivalentDiscountDialog}
                                employeeID={selectedEmployeeId}
                                percentType={percentType}
                                errorMessage={errorMessage}
                                setErrorMessage={setErrorMessage}
                                errorSnackbarOpen={errorSnackbarOpen}
                                setErrorSnackbarOpen={setErrorSnackbarOpen}
                        />

                        <Snackbar
                                open={errorSnackbarOpen}
                                autoHideDuration={4000}
                                onClose={() => { setErrorSnackbarOpen(false); }}
                                message={errorMessage}
                                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                        />

                </DashboardLayout>
        );
}

export default EmployeesInsideBranchPage;