import React, { useState, useRef, useEffect } from 'react'
import DashboardLayout from '../../../../../../components/LayoutContainers/DashboardLayout'
import { useDispatch, useSelector } from 'react-redux';
import MDTypography from '../../../../../../items/MDTypography';
import { Box, CircularProgress, Divider } from '@mui/material';
import MDBox from '../../../../../../items/MDBox/MDBox';
import MainButton from '../../../../../../components/Items/MainButton/main_button';
import colors from '../../../../../../assets/theme/base/colors';
import { useLocation, useParams } from 'react-router-dom';
import EmployeeForm from '../components/employee_form';
import { createNewEmployeeService } from '../../services/create_employee_service';
import { getWarehouseEmployeeService } from '../../services/warehouse_employee_service/get_warehouse_emp_service';
import { updateEmployeeService } from '../../services/reception_employee_service/update_reception_emp_service';
import { getReceptionEmployeeService } from '../../services/reception_employee_service/get_reseption_emp_Service';

const CreateNewEmployeePage = () => {
        const location = useLocation();
        const dispatch = useDispatch();

        useEffect(() => {
                const queryParams = new URLSearchParams(location.search);
                const employeeInfo = Object.fromEntries(queryParams.entries());
                console.log("Employee Info:", employeeInfo);
                setEmployeeInfo(employeeInfo || '');
                setEmployeeID(employeeInfo.id || '');
                setfullName(employeeInfo.username || '');
                setFatherName(employeeInfo.father_name || '');
                setMohterName(employeeInfo.mother_name || '');
                setPhoneNumber(employeeInfo.phone_number || '');
                setEmail(employeeInfo.email || '');
                setAddress(employeeInfo.address || '');
                setBrithDate(employeeInfo.bitrh_date || '');
                setFileName(employeeInfo.cv_file || '');
                setDegree(employeeInfo.degree || '');
                setGender(employeeInfo.gender || '');
                setNational(employeeInfo.nationality || '');
                setNationalNumber(employeeInfo.id_number || '');
                setSalary(employeeInfo.salary || '');
                // setEmployeeType(employeeInfo.type || '');

                setIsUpdateEmployeeInfo(employeeInfo.isUpdateInfoManager === 'true');

        }, [location]);

        const [employeeInfo, setEmployeeInfo] = useState({});
        const [employeeType, setEmployeeType] = useState('');
        const [warehouseName, setwarehouseName] = useState('');
        const [truckID, setTruckID] = useState('');
        const [truckName, setTruckName] = useState('');
        const [warehouseID, setWarehouseID] = useState('');
        const [employeeID, setEmployeeID] = useState('');
        const [isUpdateEmployeeInfo, setIsUpdateEmployeeInfo] = useState(false);
        const [fullName, setfullName] = useState('');
        const [fatherName, setFatherName] = useState('');
        const [mohterName, setMohterName] = useState('');
        const [nationalNumber, setNationalNumber] = useState('');
        const [phoneNumber, setPhoneNumber] = useState('');
        const [salary, setSalary] = useState('');
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');
        const [address, setAddress] = useState('');
        const [national, setNational] = useState('');
        const [degree, setDegree] = useState('');
        const [brithDate, setBrithDate] = useState('');
        const [gender, setGender] = useState('');
        const [cv, setCv] = useState('');
        const [fileName, setFileName] = useState('');
        const [driverLicenseImage, setDriverLicenseImage] = useState('');
        const [driverLicenseImageFile, setDriverLicenseImageFile] = useState(null);
        const fileInputRef = useRef(null);
        const [validationErrors, setValidationErrors] = useState({
                fullName: '',
                fatherName: '',
                mohterName: '',
                nationalNumber: '',
                phoneNumber: '',
                salary: '',
                email: '',
                password: '',
                address: '',
                national: '',
                degree: '',
                gender: '',
                employeeType: '',
                brithDate: '',
                cv: '',
                driverLicenseImage: ''
        });

        const loading = useSelector(state => state.createNewEmployeeService.loading);
        const updateLoading = useSelector(state => state.updateEmployeeService.loading);

        const handleFileChange = (e) => {
                const file = e.target.files[0];
                console.log("Selected file:", file);
                if (file) {
                        setCv(file);
                        setFileName(file.name);
                        setValidationErrors({ ...validationErrors, cv: '' });
                }
        };

        const handledriverLicenseImageFileChange = (e) => {
                const file = e.target.files[0];
                console.log("Selected file:", file);
                if (file) {
                        setDriverLicenseImage(file);
                        setDriverLicenseImageFile(file.name);
                        setValidationErrors({ ...validationErrors, driverLicenseImage: '' });
                }
        };


        const handleCvSelected = () => {
                if (fileInputRef.current) {
                        fileInputRef.current.click();
                }
        };

        const handleCreateNewBranchManager = async () => {
                const errors = {};

                if (fullName.trim() === '' || fullName.length < 3) {
                        errors.fullName = 'Full Name is required and must to be grater than 3 letter';
                }
                if (fatherName.trim() === '') {
                        errors.fatherName = 'Father Name is required';
                }
                if (mohterName.trim() === '') {
                        errors.mohterName = 'Mother Name is required';
                }
                if (degree.trim() === '') {
                        errors.degree = 'degree is required';
                }
                if (phoneNumber.trim() === '' || phoneNumber.length < 10) {
                        errors.phoneNumber = 'Phone Number is required and must to be greater than 9 number';
                }
                if (!salary) {
                        errors.salary = 'Salary Employee is required';
                }
                if (email.trim() === '') {
                        errors.email = 'Email is required';
                }
                if (!isUpdateEmployeeInfo && password.trim() === '') {
                        errors.password = 'Password is required';
                }
                if (national.trim() === '') {
                        errors.national = 'Nationalty is required';
                }
                if (nationalNumber.trim() === '' || nationalNumber.length != 11) {
                        errors.nationalNumber = 'National Number is required and must to be 11 Number';
                }
                if (!isUpdateEmployeeInfo && !cv) {
                        errors.cv = 'Cv is required';
                }
                if (brithDate.trim() === '') {
                        errors.brithDate = 'Brith date is required';
                }
                if (address.trim() === '') {
                        errors.address = 'Address is required';
                }
                if (gender.trim() === '') {
                        errors.gender = 'Gender is required';
                }
                if (!isUpdateEmployeeInfo && employeeType.trim() === '') {
                        errors.employeeType = 'Employee Type is required';
                }
                if (!isUpdateEmployeeInfo && employeeType === 'Warehouse_supervisor') {
                        if (warehouseName.trim() === '') {
                                errors.warehouseName = 'Warehouse is required';
                        }
                }
                if (!isUpdateEmployeeInfo && employeeType === 'driver') {
                        // if (truckName.trim() === '') {
                        //         errors.truckName = 'Truck is required';
                        // }
                }

                setValidationErrors(errors);

                if (Object.keys(errors).length === 0) {
                        try {
                                let response;
                                {
                                        isUpdateEmployeeInfo ?
                                                response = await dispatch(updateEmployeeService({
                                                        employeeID: employeeID,
                                                        payload: {
                                                                warehouse_id: warehouseID === '' ? null : warehouseID,
                                                                driver_license: driverLicenseImageFile === '' ? null : driverLicenseImageFile,
                                                                truck_id: truckID === '' ? null : truckID,
                                                                username: fullName,
                                                                father_name: fatherName,
                                                                mother_name: mohterName,
                                                                nationality: national,
                                                                phone_number: phoneNumber,
                                                                email: email,
                                                                address: address,
                                                                id_number: nationalNumber,
                                                                degree: degree,
                                                                gender: gender,
                                                                salary: salary,
                                                                bitrh_date: brithDate,
                                                                cv_file: cv === '' ? fileName : cv,
                                                        }
                                                }))
                                                :
                                                response = await dispatch(createNewEmployeeService({
                                                        payload: {
                                                                warehouse_id: warehouseID === '' ? null : warehouseID,
                                                                driver_license: driverLicenseImageFile === '' ? null : driverLicenseImageFile,
                                                                truck_id: truckID === '' ? null : truckID,
                                                                username: fullName,
                                                                father_name: fatherName,
                                                                mother_name: mohterName,
                                                                nationality: national,
                                                                phone_number: phoneNumber,
                                                                email: email,
                                                                address: address,
                                                                password: password,
                                                                type: employeeType,
                                                                id_number: nationalNumber,
                                                                degree: degree,
                                                                gender: gender,
                                                                salary: salary,
                                                                bitrh_date: brithDate,
                                                                cv_file: cv,
                                                        }
                                                }))
                                }
                                try {

                                        if (response.payload && response.payload.status === 'fail') {
                                                console.log("Detailed error response:", response.payload);

                                                if (response.payload.username && response.payload.username.length > 0) {
                                                        setfullName('')
                                                        errors.fullName = response.payload.username[0];
                                                }
                                                if (response.payload.father_name && response.payload.father_name.length > 0) {
                                                        setFatherName('')
                                                        errors.father_name = response.payload.father_name[0];
                                                }
                                                if (response.payload.mother_name && response.payload.mother_name.length > 0) {
                                                        setMohterName('')
                                                        errors.mother_name = response.payload.mother_name[0];
                                                }
                                                if (response.payload.bitrh_date && response.payload.bitrh_date.length > 0) {
                                                        setBrithDate('')
                                                        errors.bitrh_date = response.payload.bitrh_date[0];
                                                }
                                                if (response.payload.id_number && response.payload.id_number.length > 0) {
                                                        setNationalNumber('')
                                                        errors.nationalNumber = response.payload.id_number[0];
                                                }
                                                if (response.payload.address && response.payload.address.length > 0) {
                                                        setAddress('')
                                                        errors.address = response.payload.address[0];
                                                }
                                                if (response.payload.degree && response.payload.degree.length > 0) {
                                                        setDegree('')
                                                        errors.degree = response.payload.degree[0];
                                                }
                                                if (response.payload.email && response.payload.email.length > 0) {
                                                        setEmail('');
                                                        errors.email = response.payload.email[0];
                                                }
                                                if (response.payload.password && response.payload.password.length > 0) {
                                                        setPassword('')
                                                        errors.password = response.payload.password[0];
                                                }
                                                if (response.payload.phone_number && response.payload.phone_number.length > 0) {
                                                        setPhoneNumber('')
                                                        errors.numberPhone = response.payload.phone_number[0];
                                                }

                                                if (response.payload.cv_file && response.payload.cv_file.length > 0) {
                                                        setCv('')
                                                        errors.cv_file = response.payload.cv_file[0];
                                                }

                                                setValidationErrors(errors);
                                        }
                                } catch (error) {
                                        console.error("Error:", error);
                                }

                                if (response.payload && response.payload.status === 'fail') {

                                } else {
                                        window.location.href = '/Employees-in-branch'
                                        // dispatch(getReceptionEmployeeService());
                                }
                        }
                        catch (error) {
                                throw error;
                        }
                };
        }

        return (

                <DashboardLayout>
                        <Box sx={{ borderRadius: 2, backgroundColor: colors.gradients.info.state, p: 1 }}>
                                <MDTypography fontWeight="bold" color="white" fontSize={'18px'} p={1}
                                        textAlign='center' >
                                        {isUpdateEmployeeInfo ? ' Update Employee in Branch' : 'Create New Employee in Branch'}
                                </MDTypography>

                        </Box>

                        <EmployeeForm
                                fullName={fullName}
                                setFullName={setfullName}
                                fatherName={fatherName}
                                setFatherName={setFatherName}
                                mohterName={mohterName}
                                setMohterName={setMohterName}
                                brithDate={brithDate}
                                setBrithDate={setBrithDate}
                                employeeType={employeeType}
                                setEmployeeType={setEmployeeType}
                                gender={gender}
                                setGender={setGender}
                                national={national}
                                setNational={setNational}
                                nationalNumber={nationalNumber}
                                setNationalNumber={setNationalNumber}
                                phoneNumber={phoneNumber}
                                setPhoneNumber={setPhoneNumber}
                                salary={salary}
                                setSalary={setSalary}
                                warehouseName={warehouseName}
                                setWarehouseID={setWarehouseID}
                                email={email}
                                setEmail={setEmail}
                                password={password}
                                setPassword={setPassword}
                                address={address}
                                setAddress={setAddress}
                                degree={degree}
                                setDegree={setDegree}
                                cv={cv}
                                fileName={fileName}
                                handleCvSelected={handleCvSelected}
                                driverLicenseImage={driverLicenseImage}
                                setDriverLicenseImageFile={setDriverLicenseImageFile}
                                truckName={truckName}
                                setTruckID={setTruckID}
                                fileInputRef={fileInputRef}
                                driverLicense={driverLicenseImage}
                                setDriverLicense={setDriverLicenseImage}
                                handleFileChange={handleFileChange}
                                handledriverLicenseImageFileChange={handledriverLicenseImageFileChange}
                                validationErrors={validationErrors}
                                setValidationErrors={setValidationErrors}
                                isUpdateEmployeeInfo={isUpdateEmployeeInfo}
                        />

                        {/* //! Buttons controll row */}
                        <MDBox display="flex" justifyContent="space-around" pt={5}>
                                <MainButton
                                        title={loading || updateLoading ? <CircularProgress size={24} sx={{ color: colors.white.main }} />
                                                : isUpdateEmployeeInfo ? 'Update' : 'Create'}
                                        width={"20%"}
                                        backgroundColor={colors.gradients.info.state}
                                        hoverBackgroundColor={colors.gradients.info.main}
                                        colorTitle={colors.white.main}
                                        onClick={handleCreateNewBranchManager}
                                />
                                <MainButton
                                        title='Back'
                                        width={"20%"}
                                        backgroundColor={colors.gradients.error.main}
                                        hoverBackgroundColor={colors.gradients.error.state}
                                        colorTitle={colors.white.main}
                                        onClick={() => {
                                                window.location.href = '/branch-manage'
                                        }}
                                />

                        </MDBox>

                </DashboardLayout >
        )
}

export default CreateNewEmployeePage;

