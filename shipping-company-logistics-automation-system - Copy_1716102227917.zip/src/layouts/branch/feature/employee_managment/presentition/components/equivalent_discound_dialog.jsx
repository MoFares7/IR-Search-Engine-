import React, { useState } from 'react';
import MDBox from '../../../../../../items/MDBox/MDBox';
import { Dialog, DialogContent, DialogActions, Button, Divider, CircularProgress, Snackbar, Box } from '@mui/material';
import MDTypography from '../../../../../../items/MDTypography';
import MDButton from './../../../../../../items/MDButton/index';
import TextFeildForm from '../../../../../../components/Items/Form_TextFeild/text_feild_form.jsx';
import colors from '../../../../../../assets/theme/base/colors.jsx';
import { useDispatch, useSelector } from 'react-redux';
import equlavante from '../../../../assets/lottie/equlavante.json';
import Lottie from 'lottie-react';
import { EquivalentAndDiscoundService } from './../../services/equivalent_discound_service';
import { useNavigate } from 'react-router-dom';

const EquivalentDisoundDialog = ({ isDialogOpen, onCloseDialog, employeeID, percentType,
         setErrorSnackbarOpen, errorMessage, setErrorMessage
}) => {
        const dispatch = useDispatch();
        const navigate = useNavigate();
        const [percent, setPercent] = useState('');
        const [validationErrors, setValidationErrors] = useState({
                percent: '',
        });
        const loading = useSelector(state => state.EquivalentAndDiscoundService.loading);

        const handleDialogClose = () => {
                onCloseDialog();
                setPercent('');

                setValidationErrors({
                        percent: '',

                });
        };

        const handleAddEquivalentDiscoundAction = async () => {
                const errors = {};

                if (percent.trim() === '' || percent >= 100) {
                        errors.percent = 'Percent is required and must be between 0 and 100';
                }

                setValidationErrors(errors);

                if (Object.keys(errors).length === 0) {
                        try {
                                const res = await dispatch(EquivalentAndDiscoundService({
                                        user_id: employeeID,
                                        payload: {
                                                percent: percent,
                                                percent_type: percentType
                                        }
                                }));

                                if (res.payload && res.payload.username != '') {
                                        handleDialogClose();
                                        navigate('/Equivalents-And-Discounts');

                                } else {
                                        setErrorMessage('This operation is Failure.');
                                        setErrorSnackbarOpen(true);
                                }
                        } catch (error) {
                                console.error("Error:", error);
                        }
                }
        };


        return (
                <div>
                        <Dialog open={isDialogOpen} onClose={handleDialogClose}>
                                <DialogContent>
                                        <MDTypography fontWeight="bold" color="black" fontSize={'18px'} p={1}
                                                textAlign='center' >
                                                {percentType === 'bonus'
                                                        ? 'Add Equivalent To This Employee'
                                                        :
                                                        "Deduction From This Employee's Salary"}
                                        </MDTypography>
                                        <Divider sx={{
                                                color: "#252525",
                                                backgroundColor: "#252525;"
                                        }} />

                                        <MDBox
                                                sx={{
                                                        display: 'flex',
                                                        flexDirection: 'column',
                                                        alignItems: 'center',
                                                }}
                                        >

                                                <Lottie animationData={equlavante} autoplay loop style={{ alignItems: 'center', width: 150, height: 150 }} />

                                                <TextFeildForm
                                                        isNumaric={true}
                                                        isFulWidth={true}
                                                        value={percent}
                                                        placeholder={validationErrors.percent ? validationErrors.percent : "Precent"}
                                                        label={"Precent"}
                                                        validationColor={validationErrors.percent ? colors.gradients.error.main : colors.white}
                                                        validationErrors={validationErrors.percent}
                                                        onChange={(e) => {
                                                                setPercent(e.target.value);
                                                                setValidationErrors({ ...validationErrors, percent: '' });
                                                        }}
                                                />

                                        </MDBox>



                                </DialogContent>
                                <DialogActions>
                                        <MDBox display="flex" justifyContent="space-between">
                                                <MDButton onClick={handleAddEquivalentDiscoundAction}
                                                        sx={{
                                                                backgroundColor: percentType === 'bonus' ?
                                                                        colors.gradients.info.main : colors.error.main,
                                                                color: '#fff',
                                                                '&:hover': {
                                                                        backgroundColor: percentType === 'bonus' ?
                                                                                colors.gradients.info.state : colors.error.focus,
                                                                }
                                                        }}>{loading ?
                                                                < CircularProgress size={24}
                                                                        sx={{ color: colors.white.main }} />
                                                                :
                                                                percentType === 'bonus' ? 'Add' : 'Discount'}
                                                </MDButton>
                                                <Button onClick={handleDialogClose}>Close</Button>
                                        </MDBox>
                                </DialogActions>


                        </Dialog>
                </div>
        )
}

export default EquivalentDisoundDialog;
