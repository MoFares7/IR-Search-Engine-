import { IconButton } from "@mui/material";
import colors from "../../../../../../assets/theme/base/colors";
import MDBox from "../../../../../../items/MDBox/MDBox";
import MDTypography from "../../../../../../items/MDTypography";
import { AddCircleOutline, AddOutlined, DownloadRounded, RemoveCircleOutlineOutlined } from "@mui/icons-material";
import MDButton from "../../../../../../items/MDButton";
import { useDispatch } from "react-redux";
import { downloadCvEmployeeService } from "../../services/download_cv_employee_service";
import employee from '../../../../assets/images/man.avif'
import MDAvatar from "../../../../../../items/MDAvatar";

export default function EmployeesTable(data, isWarehouseEmployee, handleEditEmployeeInformation, handleAddEquivalentDiscount, handleDeleteBranchEmployee) {
        const dispatch = useDispatch();

        if (!data || !Array.isArray(data) || data.length === 0) {
                return { columns: [], rows: [] };
        }

        const handleEditEmployees = (isUpdateInfoManager, managerID, managerInfo) => {
                handleEditEmployeeInformation(isUpdateInfoManager, managerID, managerInfo);
        }

        const Employee = ({ name, email }) => (
                <MDBox display="flex" alignItems="center" lineHeight={1}>
                        <MDAvatar src={employee} name={name} size="sm" />
                        <MDBox ml={2} lineHeight={1}>
                                <MDTypography display="block" variant="button" fontWeight="medium">
                                        {name}
                                </MDTypography>
                                <MDTypography variant="caption">{email}</MDTypography>
                        </MDBox>
                </MDBox>
        );

        const rows = data.map(employee => {
                const employeeUser = isWarehouseEmployee ? employee.warehouse_manager?.user : employee.user;
                if (!employeeUser) return null;

                const row = {
                        employee: (
                                <Employee
                                        name={employee.name}
                                        email={employee.email}
                                />
                        ),
                        EmployeeName: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.username}
                                </MDTypography>
                        ),
                        FatherName: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.father_name}
                                </MDTypography>
                        ),
                        MotherName: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.mother_name}
                                </MDTypography>
                        ),
                        BrithDate: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.bitrh_date}
                                </MDTypography>
                        ),
                        Email: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.email}
                                </MDTypography>
                        ),
                        PhoneNumber: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.phone_number}
                                </MDTypography>
                        ),
                        Address: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.address}
                                </MDTypography>
                        ),
                        Gender: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.gender}
                                </MDTypography>
                        ),
                        Nationality: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.nationality}
                                </MDTypography>
                        ),
                        NationalNumber: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.id_number}
                                </MDTypography>
                        ),
                        Degree: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.degree}
                                </MDTypography>
                        ),
                        Salary: (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employeeUser.salary}
                                </MDTypography>
                        ),
                        CV: (
                                <IconButton>
                                        <DownloadRounded sx={{ color: colors.info.main }}
                                                onClick={() => {
                                                        dispatch(downloadCvEmployeeService({ user_id: employeeUser.id }))
                                                }}
                                        />
                                </IconButton>
                        ),
                        EquivalentsAndDiscounts: (
                                <MDBox sx={{ display: 'flex' }} >
                                        <IconButton onClick={() => handleAddEquivalentDiscount(employeeUser.id, 'bonus')}>
                                                <AddCircleOutline sx={{ color: colors.info.main }} />
                                        </IconButton>
                                        <IconButton onClick={() => handleAddEquivalentDiscount(employeeUser.id, 'deduction')}>
                                                <RemoveCircleOutlineOutlined sx={{ color: colors.error.main }} />
                                        </IconButton>
                                        <MDBox sx={{ pl: 1 }} />
                                </MDBox>
                        ),
                        actions: (
                                <MDBox sx={{ display: 'flex' }} >
                                        <MDButton onClick={() => handleEditEmployees(true, employeeUser.id, employeeUser)}
                                                variant="caption" fontWeight="medium" sx={{ color: colors.success.main }}>
                                                Edit
                                        </MDButton>
                                        <MDButton onClick={() => handleDeleteBranchEmployee(employeeUser.id)}
                                                variant="caption" fontWeight="medium" sx={{ color: colors.error.main }}>
                                                Dismissal
                                        </MDButton>

                                        <MDBox sx={{ pl: 1 }} />
                                </MDBox>
                        ),
                };

                if (employeeUser.type === 'driver') {
                        row.Availability = (
                                <MDTypography variant="caption" color="text" fontWeight="medium">
                                        {employee.avalibility}
                                </MDTypography>
                        );
                }

                return row;
        }).filter(Boolean);

        const columns = [
                { Header: 'Employee', accessor: 'employee', width: '15%', align: 'center' },
                { Header: "Employee Name", accessor: "EmployeeName", align: "center" },
                { Header: "Father Name", accessor: "FatherName", align: "center" },
                { Header: "Mother Name", accessor: "MotherName", align: "center" },
                { Header: "Birth Date", accessor: "BrithDate", align: "center" },
                { Header: "Email", accessor: "Email", align: "center" },
                { Header: "Phone Number", accessor: "PhoneNumber", align: "center" },
                { Header: "Address", accessor: "Address", align: "center" },
                { Header: "Gender", accessor: "Gender", align: "center" },
                { Header: "Nationality", accessor: "Nationality", align: "center" },
                { Header: "National Number", accessor: "NationalNumber", align: "center" },
                { Header: "Degree Education", accessor: "Degree", align: "center" },
                { Header: "Salary", accessor: "Salary", align: "center" },
                { Header: "CV", accessor: "CV", align: "center" },
                { Header: "Equivalents and Discounts", accessor: "EquivalentsAndDiscounts", align: "center" },
                { Header: "Actions", accessor: "actions", align: "center" },
        ];

        if (data.some(employee => employee.user && employee.user.type === 'driver')) {
                columns.splice(12, 0, { Header: "Availability", accessor: "Availability", align: "center" });
        }

        return {
                columns: columns,
                rows: rows
        };
}
