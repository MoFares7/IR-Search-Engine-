import { configureStore } from '@reduxjs/toolkit';
import loginReducer from './layouts/authentication/services/apis/login';
import branchesReducer from './layouts/manager/feature/branchs/services/apis/get_branches_api'
import createNewBranchReducer from './layouts/manager/feature/branchs/services/apis/create_branch_api';
import changeStatusBranchReducer from './layouts/manager/feature/branchs/services/apis/change_status_service';
import updateBranchInfoReducer from './layouts/manager/feature/branchs/services/apis/update_branch_service';
import downloadFilesBranchServiceReducer from './layouts/manager/feature/branchs/services/apis/download_file_branch_service';
import getBranchesManagersRaducer from './layouts/manager/feature/branches_manage/services/get_branch_manager';
import createNewBranchManagerReducer from './layouts/manager/feature/branches_manage/services/create_branch_manager_service';
import updateBranchManagerReducer from './layouts/manager/feature/branches_manage/services/update_branch_manager_service';
import deleteBranchManagerReducer from './layouts/manager/feature/branches_manage/services/delete_branch_manager';
import downloadFilesManagerServiceReducer from './layouts/manager/feature/branches_manage/services/download_file_manager_service';
import getPricingManagementReducer from './layouts/manager/feature/Pricing/service/get_pricing_service';
import createNewPricingOperationReducer from './layouts/manager/feature/Pricing/service/create_pricing_service';
import updatePricingServiceReducer from './layouts/manager/feature/Pricing/service/update_pricing_service';
import deletePricingOperationReducer from './layouts/manager/feature/Pricing/service/delete_pricing_service';
import getSalaryServiceReducer from './layouts/manager/feature/payroll/services/get_salary_service';
import updateSalaryServiceReducer from './layouts/manager/feature/payroll/services/update_salary_service';
import getPermissinsTruckReducer from './layouts/manager/feature/permission_requests/services/get_permission_truck';
import getPermissionWarehouseReducer from './layouts/manager/feature/permission_requests/services/get_permission_warehouse';
import changeStatusPermissionReducer from './layouts/manager/feature/permission_requests/services/detect_status_permission';
import getEquivalentDiscontManagerServiceReducer from './layouts/manager/feature/equivalents_and_discounts/services/get_equivalents_discont_manager_service';
import updateEquivDiscountServiceReducer from './layouts/manager/feature/equivalents_and_discounts/services/update_equivalents_discont_service';
import deleteEquivDiscountServiceReducer from './layouts/manager/feature/equivalents_and_discounts/services/delete_equivalent_discont';
import getWarehousesBranchReducer from './layouts/branch/feature/warehouse_managment/services/get_warehouses_service';
import createWarehouseBranchReducer from './layouts/branch/feature/warehouse_managment/services/create_warehouse_service';
import updateWarehouseServiceReducer from './layouts/branch/feature/warehouse_managment/services/update_warehouse_service';
import deleteWarehouseServiceReducer from './layouts/branch/feature/warehouse_managment/services/delete_warehouse_service';
import downloadDocumentWarehouseServiceReducer from './layouts/branch/feature/warehouse_managment/services/download_document_warehouse_service';
import getTrucksBranchReducer from './layouts/branch/feature/crisis_management/service/get_track_service';
import createNewTruckServiceReducer from './layouts/branch/feature/crisis_management/service/create_new_truck_service';
import updateTruckInfoServiceReducer from './layouts/branch/feature/crisis_management/service/update_truck_service';
import deleteTruckServiceReducer from './layouts/branch/feature/crisis_management/service/delete_truck_service';
import changeStatusTruckServiceReducer from './layouts/branch/feature/crisis_management/service/change_status_service';
import downloadDocumentTruckServiceReducer from './layouts/branch/feature/crisis_management/service/download_document_truck_service';
import createNewEmployeeServiceReducer from './layouts/branch/feature/employee_managment/services/create_employee_service';
import updateEmployeeServiceReducer from './layouts/branch/feature/employee_managment/services/reception_employee_service/update_reception_emp_service';
import getReceptionEmployeeServiceReducer from './layouts/branch/feature/employee_managment/services/reception_employee_service/get_reseption_emp_Service';
import getDriverEmployeeServiceReducer from './layouts/branch/feature/employee_managment/services/driver_employee_service/get_driver_emp_service';
import getWarehouseEmployeeServiceReducer from './layouts/branch/feature/employee_managment/services/warehouse_employee_service/get_warehouse_emp_service';
import changeStatusWarehouseServiceReducer from './layouts/branch/feature/warehouse_managment/services/change_status_service';
import downloadCvEmployeeServiceReducer from './layouts/branch/feature/employee_managment/services/download_cv_employee_service';
import EquivalentAndDiscoundServiceReducer from './layouts/branch/feature/employee_managment/services/equivalent_discound_service';
import getEmployeesArchiveServiceReducer from './layouts/branch/feature/employees_archive/services/get_employees_archive_service';
import ReEmployementServiceReducer from './layouts/branch/feature/employee_managment/services/re_employement_service';
import getEquivalentDiscontBranchServiceReducer from './layouts/manager/feature/equivalents_and_discounts/services/get_equivalents_discont_branch_service';
import getQuestionsReducer from './layouts/manager/feature/chat_config/services/get_question';
import getAnswersReducer from './layouts/manager/feature/chat_config/services/get_answers';
import createNewQuestionServiceReducer from './layouts/manager/feature/chat_config/services/create_question_service';
import deleteQuestionReducer from './layouts/manager/feature/chat_config/services/delete_question_service';
import calaculateCostTranslatorReducer from './layouts/reciptions/feature/receipt_of_shipment/services/calaculate_cost_service';
import fastShipmentServiceReducer from './layouts/reciptions/feature/receipt_of_shipment/services/fast_shipment_service';
import normalShipmentServiceReducer from './layouts/reciptions/feature/receipt_of_shipment/services/normal_shipment_service';
import getShipmentWillEnterServiceReducer from './layouts/reciptions/feature/shipment_management/services/get_shipment_will_enter_service';
import deleteShipmentWillEnterServiceReducer from './layouts/reciptions/feature/shipment_management/services/delete_shipment_will_enter_service';
import getProfileServiceReducer from './layouts/profile/services/get_profile_service';
import sendCodeVerificationServiceReducer from './layouts/authentication/services/apis/send_code_service';
import verifyCodeServiceReducer from './layouts/authentication/services/apis/verfiy_code_service';
import resetPasswordServiceReducer from './layouts/authentication/services/apis/reset_password_service';

const store = configureStore({
        reducer: {
                auth: loginReducer,
                branches: branchesReducer,
                createNewBranch: createNewBranchReducer,
                changeStatusBranch: changeStatusBranchReducer,
                updateBranchInfo: updateBranchInfoReducer,
                downloadFilesBranchService: downloadFilesBranchServiceReducer,
                getBranchesManagers: getBranchesManagersRaducer,
                createNewBranchManager: createNewBranchManagerReducer,
                updateBranchManager: updateBranchManagerReducer,
                deleteBranchManager: deleteBranchManagerReducer,
                downloadFilesManagerService: downloadFilesManagerServiceReducer,
                getPricingManagement: getPricingManagementReducer,
                createNewPricingOperation: createNewPricingOperationReducer,
                updatePricingService: updatePricingServiceReducer,
                deletePricingOperation: deletePricingOperationReducer,
                getSalaryService: getSalaryServiceReducer,
                updateSalaryService: updateSalaryServiceReducer,
                getPermissionTruck: getPermissinsTruckReducer,
                getPermissionWarehouse: getPermissionWarehouseReducer,
                changeStatusPermission: changeStatusPermissionReducer,
                getEquivalentDiscontManagerService: getEquivalentDiscontManagerServiceReducer,
                //! branch apis
                getWarehousesBranch: getWarehousesBranchReducer,
                createWarehouseBranch: createWarehouseBranchReducer,
                updateWarehouseService: updateWarehouseServiceReducer,
                deleteWarehouseService: deleteWarehouseServiceReducer,
                downloadDocumentWarehouseService: downloadDocumentWarehouseServiceReducer,
                getTrucksBranch: getTrucksBranchReducer,
                createNewTruckService: createNewTruckServiceReducer,
                updateTruckInfoService: updateTruckInfoServiceReducer,
                deleteTruckService: deleteTruckServiceReducer,
                downloadDocumentTruckService: downloadDocumentTruckServiceReducer,
                createNewEmployeeService: createNewEmployeeServiceReducer,
                getReceptionEmployeeService: getReceptionEmployeeServiceReducer,
                getDriverEmployeeService: getDriverEmployeeServiceReducer,
                getWarehouseEmployeeService: getWarehouseEmployeeServiceReducer,
                updateEmployeeService: updateEmployeeServiceReducer,
                downloadCvEmployeeService: downloadCvEmployeeServiceReducer,
                EquivalentAndDiscoundService: EquivalentAndDiscoundServiceReducer,
                getEmployeesArchiveService: getEmployeesArchiveServiceReducer,
                reEmployementService: ReEmployementServiceReducer,
                getEquivalentDiscontBranchService: getEquivalentDiscontBranchServiceReducer,
                changeStatusWarehouseService: changeStatusWarehouseServiceReducer,
                changeStatusTruckService: changeStatusTruckServiceReducer,
                deleteEquivDiscountService: deleteEquivDiscountServiceReducer,
                updateEquivDiscountService: updateEquivDiscountServiceReducer,
                //! chatbot
                getQuestions: getQuestionsReducer,
                getAnswers: getAnswersReducer,
                createNewQuestionService: createNewQuestionServiceReducer,
                deleteQuestion: deleteQuestionReducer,
                //! Reception
                calaculateCostTranslator: calaculateCostTranslatorReducer,
                fastShipmentService: fastShipmentServiceReducer,
                normalShipmentService: normalShipmentServiceReducer,
                getShipmentWillEnterService: getShipmentWillEnterServiceReducer,
                deleteShipmentWillEnterService: deleteShipmentWillEnterServiceReducer,
                //! profile 
                getProfileService: getProfileServiceReducer,
                sendCodeVerificationService: sendCodeVerificationServiceReducer,
                verifyCodeService: verifyCodeServiceReducer,
                resetPasswordService: resetPasswordServiceReducer
        }
});

export default store;