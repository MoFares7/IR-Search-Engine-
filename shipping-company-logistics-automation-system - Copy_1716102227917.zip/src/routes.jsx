import SignIn from "./layouts/authentication/presentation/pages/login_page";
import { AccountCircleRounded, ApprovalRounded, ArchiveRounded, AttachMoneyRounded, BroadcastOnHomeOutlined, ChatBubble, ChatRounded, CrisisAlertRounded, DashboardRounded, EqualizerRounded, LogoutRounded, ManageAccountsRounded, Money, MoneyOffCsredRounded, PriceChangeRounded, ReceiptLongRounded, SensorOccupiedRounded, StoreRounded, SupportAgentRounded, TableChartRounded, WarehouseRounded, WorkspacePremiumRounded } from "@mui/icons-material";
import HomePageManager from "./layouts/manager/feature/home/presentitons/pages/manager_home_page";
import BranchesPage from "./layouts/manager/feature/branchs/presentitons/pages/branches_page";
import BranchManagerPage from "./layouts/manager/feature/branches_manage/presentitons/pages/branch_manager_page";
import SupportPage from "./layouts/manager/feature/support/presentitons/pages/support_page";
import PricingManagementPage from "./layouts/manager/feature/Pricing/presentition/pages/pricing_management";
import BranchHomePage from "./layouts/branch/feature/home/presentition/pages/branch_home_page";
import WarehousesPage from "./layouts/branch/feature/warehouse_managment/presentition/pages/wharehouses_page";
import EmployeesInsideBranchPage from "./layouts/branch/feature/employee_managment/presentition/pages/employees_page";
import CrisisManagementPage from "./layouts/branch/feature/crisis_management/presentition/pages/crisis_management_page";
import AddNewBranchPage from "./layouts/manager/feature/branchs/presentitons/pages/add_new_branch_page";
import CreateNewBranchManagerPage from "./layouts/manager/feature/branchs/presentitons/pages/create_new_branch_manager_page";
import PayrollRangManagement from "./layouts/manager/feature/payroll/presentition/pages/payroll_rang_management";
import CreateNewEmployeePage from "./layouts/branch/feature/employee_managment/presentition/pages/create_new_employee_page";
import Logout from "./layouts/authentication/presentation/pages/logout";
import CreateWarehousePage from "./layouts/branch/feature/warehouse_managment/presentition/pages/create_warehouse_page";
import PermissionRequestPage from "./layouts/manager/feature/permission_requests/presintitions/pages/permission_request_page";
import ReceiptOfShipmentPage from './layouts/reciptions/feature/receipt_of_shipment/presintions/pages/receipt_of_shipment_page';
import ChatBotConfigPage from "./layouts/manager/feature/chat_config/presentitons/pages/chatbot_config_page";
import HomePageReception from "./layouts/reciptions/feature/home/presentistion/pages/home_reception_page";
import ComingOfShipmentsPage from "./layouts/reciptions/feature/coming_of_shipment/presentition/pages/coming_of_shipments_page";
import EmployeeArchivePage from "./layouts/branch/feature/employees_archive/presentitions/pages/employee_archive_page";
import ProfilePage from "./layouts/profile/presentition/pages/profile_page";
import ShipmentsEnteredPage from "./layouts/reciptions/feature/shipment_management/presentiton/pages/shipments_entered_pages";
import VerificationCodePage from "./layouts/authentication/presentation/pages/verification_code_page";
import EquivalentsAndDiscountsPage from "./layouts/manager/feature/equivalents_and_discounts/presentition/pages/equivalents_and_discounts_page";
import ArchiveWarehousePage from "./layouts/branch/feature/warehouse_managment/presentition/pages/archive_warehouse_page";
import CrisisArchivePage from "./layouts/branch/feature/crisis_management/presentition/pages/crisis_archive_page";
import BranchManagerArchive from "./layouts/manager/feature/branches_manage/presentitons/pages/branch_manager_archive";

export const companyManagerRoutes = [
  {
    type: "collapse",
    name: "Home",
    key: "home",
    icon: <DashboardRounded />,
    route: "/home",
    component: <HomePageManager />
  },
  {
    type: "collapse",
    name: "Branches",
    key: "branch",
    icon: <BroadcastOnHomeOutlined />,
    route: "/branch",
    component: <BranchesPage />
  },
  {
    type: "collapse",
    name: "Branches Manager",
    key: "branch-manage",
    icon: <ManageAccountsRounded />,
    route: "/branch-manage",
    component: <BranchManagerPage />
  },
  {
    type: "collapse",
    name: "Salary Management",
    key: "payroll-management",
    icon: <AttachMoneyRounded />,
    route: "/payroll-management",
    component: <PayrollRangManagement />
  },
  {
    type: "collapse",
    name: "Pricing Management",
    key: "pricing-managment",
    icon: <PriceChangeRounded />,
    route: "/pricing-managment",
    component: <PricingManagementPage />
  },
  {
    type: "collapse",
    name: "Permission Requests",
    key: "permission-management",
    icon: <ApprovalRounded />,
    route: "/permission-management",
    component: <PermissionRequestPage />
  },
  {
    type: "collapse",
    name: "Equivalents And Discounts",
    key: "Equivalents-And-Discounts",
    icon: <EqualizerRounded />,
    route: "/Equivalents-And-Discounts",
    component: <EquivalentsAndDiscountsPage />
  },
  {
    type: "collapse",
    name: "Support",
    key: "support",
    icon: <SupportAgentRounded />,
    route: "/support",
    component: <SupportPage />
  },
  {
    type: "collapse",
    name: "Chatbot Cofiguration",
    key: "chatbot",
    icon: <ChatRounded />,
    route: "/chatbot",
    component: <ChatBotConfigPage />
  },
  {
    type: "collapse",
    name: "My Profile",
    key: "My-Profile",
    icon: <AccountCircleRounded />,
    route: "/My-Profile",
    component: <ProfilePage />,
  },
  {
    type: "collapse",
    name: "Logout",
    key: "logout",
    icon: <LogoutRounded />,
    route: "/logout",
    component: <Logout />,
  },
  {
    route: "/add-branch",
    component: <AddNewBranchPage />
  },
  {
    route: "/add-branch/:branchId",
    component: (props) => <AddNewBranchPage {...props} />
  },
  {
    route: "/create-new-branch-manager",
    component: <CreateNewBranchManagerPage />
  },
  {
    route: "/create-new-branch-manager/:managerId",
    component: (props) => <CreateNewBranchManagerPage {...props} />
  },
  {
    route: "/signin",
    component: <SignIn />,
  },
  {
    route: "/verification-code",
    component: <VerificationCodePage />
  },
  {
    route: "/branch-Manage-Archive",
    component: <BranchManagerArchive />
  },
];

//! Routes for branch Manager
export const branchManagerRoutes = [
  {
    type: "collapse",
    name: "Home",
    key: "home",
    icon: <DashboardRounded />,
    route: "/home",
    component: <BranchHomePage />
  },
  {
    type: "collapse",
    name: "Warehouses Management",
    key: "warehousesManagment",
    icon: <WarehouseRounded />,
    route: "/warehousesManagment",
    component: <WarehousesPage />
  },
  {
    type: "collapse",
    name: "Employees Management",
    key: "Employees-in-branch",
    icon: <WorkspacePremiumRounded />,
    route: "/Employees-in-branch",
    component: <EmployeesInsideBranchPage />
  },
  {
    type: "collapse",
    name: "Crisis Management",
    key: "Crisis-of-management",
    icon: <CrisisAlertRounded />,
    route: "/Crisis-of-management",
    component: <CrisisManagementPage />
  },
  {
    type: "collapse",
    name: "Employees Archive",
    key: "Employees-Archive",
    icon: <ArchiveRounded />,
    route: "/Employees-Archive",
    component: <EmployeeArchivePage />
  },
  {
    type: "collapse",
    name: "Equivalents And Discounts",
    key: "Equivalents-And-Discounts",
    icon: <EqualizerRounded />,
    route: "/Equivalents-And-Discounts",
    component: <EquivalentsAndDiscountsPage />
  },
  {
    type: "collapse",
    name: "Support",
    key: "support",
    icon: <SupportAgentRounded />,
    route: "/support",
    component: <SupportPage />
  },
  {
    type: "collapse",
    name: "My Profile",
    key: "My-Profile",
    icon: <AccountCircleRounded />,
    route: "/My-Profile",
    component: <ProfilePage />,
  },
  {
    type: "collapse",
    name: "Logout",
    key: "logout",
    icon: <LogoutRounded />,
    route: "/logout",
    component: <Logout />,
  },
  {
    route: "/signin",
    component: <SignIn />,
  },
  {
    route: "/create-new-employee",
    component: <CreateNewEmployeePage />
  },
  {
    route: "/create-new-employee/:employeeId",
    component: (props) => <CreateNewEmployeePage {...props} />
  },
  {
    route: "/create-warehouse-branch",
    component: <CreateWarehousePage />
  },
  {
    route: "/create-warehouse-branch/:warehouseID",
    component: (props) => <CreateWarehousePage {...props} />
  },
  {
    route: "/verification-code",
    component: <VerificationCodePage />
  },
  {
    route: "/ArchiveWarehousePage",
    component: <ArchiveWarehousePage />
  },
  {
    route: "/CrisisArchive",
    component: <CrisisArchivePage />
  },
];


//! Routes for reception employee
export const receptionsRoutes = [
  {
    type: "collapse",
    name: "Home",
    key: "home",
    icon: <DashboardRounded />,
    route: "/home",
    component: <HomePageReception />
  },
  {
    type: "collapse",
    name: "Receipt Shipment",
    key: "ReceiptShipment",
    icon: <ReceiptLongRounded />,
    route: "/ReceiptShipment",
    component: <ReceiptOfShipmentPage />
  },
  {
    type: "collapse",
    name: "Coming Of Shipments",
    key: "ComingOfShipmentsPage",
    icon: <SensorOccupiedRounded />,
    route: "/ComingOfShipmentsPage",
    component: <ComingOfShipmentsPage />
  },
  {
    type: "collapse",
    name: "Shipments Need To Store",
    key: "ShipmentsEnteredPage",
    icon: <StoreRounded />,
    route: "/ShipmentsEnteredPage",
    component: <ShipmentsEnteredPage />
  },
  {
    type: "collapse",
    name: "My Profile",
    key: "My-Profile",
    icon: <AccountCircleRounded />,
    route: "/My-Profile",
    component: <ProfilePage />,
  },
  {
    type: "collapse",
    name: "Logout",
    key: "logout",
    icon: <LogoutRounded />,
    route: "/logout",
    component: <Logout />,
  },
  {
    route: "/signin",
    component: <SignIn />,
  },
  {
    route: "/verification-code",
    component: <VerificationCodePage />
  },
];
